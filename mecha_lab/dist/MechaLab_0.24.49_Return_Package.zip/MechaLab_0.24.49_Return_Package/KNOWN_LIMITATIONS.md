# KNOWN LIMITATIONS — Mecha Lab 0.18.0

## 0.24.49 UI
- Blender 패널 버튼 안 아이콘은 크기를 키울 수 없어 Modeler보다 아이콘이 작음(툴팁으로 이름 확인).
- Quick HUD는 실제 화면에서 위치·겹침을 확인하지 못함. 손잡이로 옮긴 위치는 Blender를 닫으면 초기화됨.
- Select / Move에서 RMB가 Blender 오브젝트 메뉴 대신 팝업을 엶(MECHA LAB 안). 원래대로: Preferences > RMB Actions Menu 끄기.
- 수정키 동작 자체는 통일하지 않음(손 기억 유지) — 화면 안내만 추가.

## 0.24.48 Quad Remesh
- 닫힌 부품만 됨(열린 메쉬는 거부).
- Flow: 컷이 남긴 가는 조각 주변에서 쿼드가 꼬이고 모서리를 놓칠 수 있음(경고는 뜸). 큰 메쉬는 수 초~수십 초 동안 멈춘 듯 보임.
- Patch: 평평한 면 조각만 고른 격자가 됨. 외곽 가까이에는 불규칙한 사각형 띠가 생김. 곡면 부분은 원래 면을 사각형으로 쪼갤 뿐이라 면 흐름이 정리되지 않음(곡면은 Flow 권장).
- UV / 재질 번호 / 속성은 옮겨지지 않음(재질 슬롯만 복사).

## 0.24.47 Ramp Resolution
- 해상도를 올리면 다시 팔 때마다 몇 초 걸릴 수 있음(슬라이더를 움직이는 동안 반응이 느림). 크고 기울어진 모양은 점 수 상한에 걸려 더 이상 촘촘해지지 않음.

## 0.24.46 Cut Ramp
- 실제 화면에서 써 보지 않음. Through All 모드여도 Cut Depth만큼 팜. Split · 반전(Alt) · Live 컷에는 Ramp 없음.
- 둥근 면 위의 바닥 깊이는 그 자리 표면 방향 기준이라 베벨 위에서는 조금 들쭉날쭉할 수 있음(조각은 안 남음).

## 0.24.45 Ramp live
- Pick Edge 클릭 · 변 표시는 실제 화면에서 확인 안 함.
- live 상태에서 Ctrl+Z를 쓰면 메쉬만 돌아가고 live 기록은 어긋날 수 있음(◀ ▶ / Remove 권장).
- 한 번에 하나만 live. 여러 대상에 걸친 Ramp(대상 2개 이상)는 live가 아님.
- Profile(Flat / Chamfer / Bevel)을 바꾸는 것은 자동으로 다시 파지 않음(◀ ▶를 한 번 누르면 반영).

## 0.24.44 Alt: Ramp
- 실제 화면에서 써 보지 않음. Free Draw로 그리면 "처음 변" = 처음 두 점(2px 이상)이라 짧은 시작 획이 방향을 정함 — 다각형 클릭이 정확함.
- Soft를 많이 올리면 얕은 쪽 절반이 거의 표면 높이라 파인 부분이 작아 보임(Carve Depth를 올리면 됨).
- Path Move: 작은 브러시로 큰 판을 Extend하면 다시 판 단면 전체가 늘어남(자동 Stretch 전환은 크래시로 제거).

## 0.24.43
- 실제 화면에서 써 보지 않음.
- Edge Finish 밖으로 나간 점을 표면으로 되돌리는 처리는 그 자리 베벨 모양을 조금 납작하게 만들 수 있음(GN Edge 권장).
- 0.24.41~0.24.42에서 GN Edge로 자른 오브젝트에는 남은 컷 표시 속성이 그대로 있을 수 있음: 다음 컷 전에 그 오브젝트의 `mch_cutter_face` 속성을 지우거나 이 버전에서 한 번 Edge Finish 없이 자르면 정리됨.

## 0.24.42 Armor Plate Alt 파기
- 실제 화면에서 써 보지 않음.
- Through 모드 · Mech Ridge 프로파일은 반전 파기 없음(Mech Ridge는 Chamfer로 팜).
- 많이 휜 표면에서는 뒤집은 모양이 조금 일그러질 수 있음(가장 가까운 표면 기준 대칭).
- Path Move: 단면이 브러시보다 크면 Stretch로 바뀌어 Extend의 깨끗한 단면 쓸기는 안 됨(브러시를 키우면 Extend). 경로를 펴는 만큼 급한 꺾임은 둥글게 바뀜.

## 0.24.41 GN Edge
- 실제 화면에서 써 보지 않음.
- 베벨 둥근 모양은 컷 벽이 표면과 직각일 때 가장 정확(비스듬한 벽은 타원 호).
- 그은 모양의 뾰족한 모서리에서는 스윕이 겹쳐 모양이 덜 깔끔할 수 있음. 면 수가 기존 Edge Finish보다 늘어남.
- Live(Auto Apply OFF) 컷에는 적용 안 됨.
- 나사 둘레 평면: 메쉬 가장자리라 둘레가 5곳 미만으로 맞으면 클릭한 면 방향 그대로.

## 0.24.40 Path Move Hardness
- 실제 화면에서 써 보지 않음.
- 부드러운 휨이 끝나는 곳 바깥쪽에 작은 단차가 살짝 보일 수 있음(경로 점 간격 때문).
- 일자로 곧게 끌면 Hardness 차이가 없음(꺾일 때만 둥글어짐). Move처럼 주변 표면을 끌어당기는 방식은 아님.
- 프리미티브 Remember Turn: 표면이 바뀔 때 표면 법선 둘레의 기준 방향은 최소 회전으로 정해져서, 아주 다른 방향의 면으로 옮기면 법선 둘레 돌림이 예상과 조금 다를 수 있음.
- Stamp Face: 휜 면(구 · 원통 옆)을 찍으면 그 점의 면 방향 기준, Stamp Depth 0이어도 겹침 방지로 1%는 들어감.

## 0.24.39 Alt 파기
- 실제 화면에서 써 보지 않음.
- Resolution을 아주 높이면 라인 끝 둥근 마개에서 표면과 만나는 곳에 아주 작은(눈에 안 보이는) 삼각형이 몇 개 생길 수 있음.
- 라이브 Base Mesh 위에 Alt로 판 홈은 슬라이더로 그 Base Mesh를 다시 만들면 사라짐(Apply 후 파기 권장).

## 0.24.38 표면 따라 파기
- 실제 화면에서 써 보지 않음.
- 표면 위 점 개수 = Resolution(15~60): 아주 큰 모양 + 많이 굽은 면이면 바닥이 살짝 각질 수 있음(Resolution을 올리면 매끈해짐).
- 메쉬 가장자리를 넘어가는 부분(표면이 없는 곳)은 가장 가까운 표면에 붙어서 모양이 늘어날 수 있음.

## 0.24.37 Invert / Alt 파기
- 실제 화면에서 써 보지 않음.
- Base Mesh Alt Carve Height는 Dome / Cushion 프로파일에서는 안내만(평평한 면이 없어서). 파는 깊이는 Height − 1 %(입구가 표면과 겹치지 않게).
- Surface Draw 홈은 Boolean(Exact)이라 큰 메쉬에서 느릴 수 있음. 홈은 그 자리에서 바로 적용(라이브 아님, Ctrl+Z로 되돌림).
- Invert는 만들 때만: 이미 만든 Base Mesh를 Invert로 뒤집지는 않음.
- ZBrush-safe Faces는 n-gon만 삼각형으로 나눔: ZBrush에서 다시 가져오면 그 삼각형들이 그대로 옴(원래 n-gon으로 합쳐지지 않음). 실제 ZBrush에서 열어 보는 확인은 미검증.

## 0.24.36 컷 깊이 / Slow Line
- 실제 화면에서 써 보지 않음.
- From Surface 2점 직선 컷은 Boolean이라 Through All의 평면 컷보다 느림.
- Slow Line은 누르고 끌며 그릴 때만(Free Draw 모양, Line 선, Path Move 길): Lasso처럼 점을 클릭해 찍는 방식에는 적용 안 됨. Mask 브러시는 제외.
- Shift 직선은 화면 기준 0 / 45 / 90°(3D 축 기준 아님). Path Move 길에는 Shift 스냅 없음.

## 0.24.35 Knife Mesh / Ctrl+Z 크기 유지
- 실제 화면에서 써 보지 않음.
- Knife Mesh는 오브젝트 자기 축(X / Y / Z) 방향으로만 자름: 비스듬히 돌아간 메쉬(메쉬 데이터 자체가 기울어진 경우)는 슬라이스도 그 축 기준. 면이 많이 늘어나니(Cuts 12 큐브 ≈ 864면) 큰 메쉬는 Cuts를 낮게.
- Ctrl+Z가 크기를 되돌리지 않으므로, 크기를 실수로 바꿨으면 F / 슬라이더로 다시 맞춰야 함.

## 0.24.34 대상 선택 / Scarf Cape
- 실제 화면에서 써 보지 않음.
- 대상 선택은 Cut과 같은 설정 하나: Cut에서 Selected Only로 두면 다른 그리기 툴도 Selected Only.
- 버튼으로 동작하는 툴(Perforate, Boolean, Mirror, Radial 등)은 원래 선택한 메쉬에만 작동해서 줄이 없음. Through All / From Surface · Auto Apply는 Cut · Split에만.
- 툴 안에서는 F가 브러시 크기라 Select / Move로 가려면 Q(또는 Esc)를 씀. 원 미리보기는 마우스 아래 표면 기준 크기(표면이 없으면 3D 커서 깊이).
- Scarf Cape는 선을 왼쪽↔오른쪽으로 그어야 함(거의 세로로 그으면 안내만 나옴). 크게 구불거리는 선은 윗단이 화면 가로 기준으로 정리됨.
- 마지막 렌더 이후 주름 높이 · 가장자리 페이드를 바꿈: 새 모양은 렌더로 확인하지 않음(자동 테스트만).

## 0.24.33 Path Move 방식 / Perforate / Surface Draw / Radial Symmetry
- 실제 화면에서 써 보지 않음: 모든 새 기능의 조작감 · 속도 미검증.
- Path Move Separate Tube: 시작 부분이 원래 메쉬와 겹치는 곳에 어두운 띠가 보일 수 있음(Merge Union 하면 사라짐).
- Path Move Extend: 잡은 곳의 단면이 닫힌 루프로 잘리지 않는 메쉬(또는 라이브 오브젝트)에서는 Separate Tube로 대신 만듦(경고 표시).
- Perforate: Exact Boolean이라 면이 많은 메쉬 + 작은 구멍이면 느릴 수 있음(Solver = Fast 선택 가능).
- Surface Draw Alt 컷: 자른 영역은 그릴 때의 화면 시점으로 고정됨(나중에 시점을 돌려도 같은 자리).
- Radial Symmetry: 복사본은 Array 모디파이어라 Apply 전까지 실제 메쉬가 아님.

## 0.24.32 Path Move / 무브 패널 옵션
- 실제 화면에서 써 보지 않음: 드래그 느낌, 미리보기 속도 미검증. 0.24.31 항목 중 Jungle Gym 내용은 툴을 지웠으므로 해당 없음.
- 잡은 부분이 단단하게 따라가는 방식이라(Hardness 높을수록 단면 유지) 아주 급하게 꺾으면 꺾인 안쪽 면이 겹칠 수 있음.
- 경로는 최대 48 스텝으로 나눔: 아주 긴 경로는 스텝 간격이 넓어져 몸통이 조금 울퉁불퉁할 수 있음.
- Through All은 오브젝트 상자(바운딩 박스)로 대상을 고름: 브러시 근처에 상자만 걸쳐도 대상에 들어가지만, 실제로 브러시 밖 점은 안 움직임.
- Auto Apply 끔은 무브 전 메쉬를 숨은 메쉬 데이터로 하나 더 저장함(파일 크기 늘어남). Apply나 Clear하면 지워짐.
- 놓을 때 스텝마다 면을 새로 만들어서, 큰 메쉬 + 긴 경로는 몇 초 걸릴 수 있음.

## 0.24.31 Concept Move / Jungle Gym
- 실제 화면에서 한 번도 써 보지 않음: 드래그 손맛, 브러시 원, 격자 · 주황 막대 표시, D 홀드, F 크기, 3D 마우스(Follow View) 모두 미검증.
- Jungle Gym 격자를 마우스만 올려도 보이게 하는 부분(툴 키맵 MOUSEMOVE)이 Blender에서 동작하는지 확신 없음. 안 되면 드래그 중에만 보임.
- MECHA LAB 작업공간에서는 D + 드래그가 Concept Move라서 Blender 주석(Annotate, D + 드래그)이 안 됨. 다른 작업공간에서는 그대로. Hotkeys 박스에서 키를 바꿀 수 있음.
- Concept Move는 일반 메쉬 방식이라 VR 찰흙(복셀)처럼 붙이기 · 빼기가 자유롭지 않음. Fuse(합치기)는 복셀 리메쉬라 느리고 잔 디테일이 뭉개짐.
- Follow Body는 가장 가까운 표면점을 쓰기 때문에, 몸이 얇거나 오목한 곳(겨드랑이 등)에서는 선이 반대편 면으로 튈 수 있음.
- Jungle Gym 결과의 베이스 메쉬는 평평하게 닫힌 선만. 몸을 감은 닫힌 선은 닫힌 튜브.

## 0.18.0 Mirror HUD
- Mirror 도구의 "기울여서 고르기"(모달) 중에는 HUD를 누를 수 없음: 클릭으로 라이브 유지한 뒤에 HUD가 동작. 실제 창 미확인.

## 0.17.0 Random Panels
- 판 하나하나가 라이브 파트라 판이 많으면(수십 개) 값을 바꿀 때마다 다시 만드는 데 시간이 걸림(테스트: 판 30개 약 1–2초).
- 모양이 너무 가늘거나 꼬인 칸은 건너뜀(보고에 "cell(s) skipped"로 표시).
- 판 경계는 칸을 다각형으로 단순화한 모양: 곡면에서 크게 휜 칸은 판이 평평하게 펴지며 조금 늘어날 수 있음.
- HUD·슬라이더는 실제 창에서 본 적 없음.

## 0.16.0 Armor Plate
- 새 면은 **보는 방향으로** 표면에 투영: 옆에서 비스듬히 본 면에 그리면 면이 늘어남. 판을 붙일 면을 정면에 가깝게 보고 그리는 것이 좋음.
- 표면에 깊은 홈·돌기가 있으면 판 바닥도 그 모양을 따라감(새 면이 표면 위에 붙기 때문). Surface Offset으로 띄울 수 있음.
- 테두리 단면 몰딩(Raised Rail 등)·끊어진 테두리 조각·무작위 패널·대칭 짝짓기는 다음 단계(아직 없음).
- 휠로 프로필을 바꾸는 동안에는 휠 확대/축소가 안 됨(그리기를 끝내면 다시 됨). Ctrl+휠·Shift+휠은 그대로 뷰 조작.
- 실제 창에서 그려 본 적 없음(가짜 이벤트로 획·휠·생성만 확인).

## 0.15.0
- 왼쪽 떠 있는 툴 목록, HUD 버튼·슬라이더, 새 핸들, 빨간 점선 경고는 실제 창에서 본 적 없음(배치 계산·동작만 headless 확인).
- HUD 슬라이더는 직접 만든 화면 핸들(Python Gizmo)이라 Blender 버전에 따라 모양이 단순한 막대로 보일 수 있음. 값은 막대 위 글자로 표시.
- 겹치는 면 검사는 면의 가운데와 모서리 근처 점으로 판단(허용 거리 = 도형 크기의 0.4 %). 아주 작은 겹침은 놓칠 수 있음.
- Polygon Prism은 전용 단면이라 지점마다 다른 단면(Profile Here)으로 바꾸는 기능은 없음.
- 툴 목록이 길어 두 줄이 되면 뷰포트 왼쪽을 더 가림. Preferences / Icon Size 패널에서 Side Tool List를 끌 수 있음.

## 0.14.3
- 새 핸들(네모·화살표·다이얼·점)은 실제 창에서 드래그해 본 적 없음. 네모와 화살표가 같은 축에 있어 겹치면 네모가 우선 선택되게 함.
- 아이콘 버튼: 큰 아이콘을 버튼으로 만들었는데, Blender 버전에 따라 버튼 안 아이콘이 작게 그려질 수 있음(그래도 클릭은 됨). 화면 확인 필요.
- 도형 되돌리기는 Mecha Lab 자체 기록(최대 64단계). Blender 실행 취소와는 별도.
- Station 핸들 실행 취소 단계는 드래그가 0.35초 멈추면 기록. 드래그 중 오래 멈추면 한 드래그가 두 단계가 될 수 있음.
- Stick to Surface는 판을 표면 방향으로 세우고 바닥을 묻는 방식이라, 크게 휜 곡면에서는 윗면이 곡면을 따라 휘지 않음(평평한 판).

## 0.14.2 아이콘 크기
- 버튼 안의 작은 아이콘(텍스트 옆 16px 아이콘)은 Blender가 크기를 정해서 바꿀 수 없음. 바뀌는 것은 큰 썸네일, 아래 툴바, 뷰포트 핸들.
  전체 Blender UI를 키우려면 Preferences > Interface > Resolution Scale.
- 실제 창에서 크기를 바꿔 본 적 없음(값 계산과 패널 그리기 호출만 확인).

## 0.14.1 Base Mesh 스케치
- 주황색 스케치 표시(선·면)는 실제 창에서 본 적 없음. 합치기/빼기 계산, 메시 만들기, 키 등록만 headless로 확인.
- 스케치는 Base Mesh 도구일 때만 보임. 다른 도구로 가도 지워지지 않고, 돌아오면 다시 보임. 스케치는 씬에 저장되므로 파일을 저장하면 같이 저장됨.
- 두 모양이 한 점에서만 닿으면(꼭짓점끼리) 외곽선이 한 점에서 꼬일 수 있음. 이때 Enter가 "닫히지 않음"을 알리면 조금 더 겹쳐 그리기.
- Sketch First가 켜져 있으면 Alt+드래그는 커터가 아니라 "스케치에서 빼기". 커터는 Alt+Enter.

## 0.14.0 도형 찍기
- 반투명 도형 그리기, 화살표·다이얼·링 드래그, 클릭 이동, Alt 빨간색 전환은 실제 창에서 해 본 적 없음. 형상 계산, 합치기/빼기,
  키 등록만 headless로 확인. 핸들 크기나 방향이 화면에서 어색할 수 있음.
- Alt 빨간색은 Alt를 누르고 떼는 키 이벤트로 바뀜. 창 밖에서 Alt를 떼면 빨간색이 남을 수 있음(Enter 한 번이면 초기화).
- Primitive 도구에서 그냥 클릭은 "도형 이동"이라 오브젝트 선택은 Shift+클릭, 드래그(박스 선택), 또는 F(Select/Move).
- 말랑한 SDF 블렌드(Substance식 부드러운 합치기)는 이번에 넣지 않음. 이음새 Chamfer/Smooth만 있음.
- 합치기는 Boolean이라 닿은 메시가 열린(구멍 난) 메시면 Exact로 재시도하고, 그래도 안 되면 아무것도 바꾸지 않고 메시지를 띄움.

## 0.13.2 아머 프리셋
- 헬멧은 크라운 쉘(이마-정수리-뒤)만: 얼굴 구멍·볼 가리개·목 가리개는 아직 없음(Phase 2 헬멧 전용 옵션 예정). Cut으로 뚫을 수 있음.
- 어깨·무릎 등은 판 하나: 여러 장 겹친 판(lames)은 같은 프리셋을 여러 번 만들어 배치.
- 아머 크기는 사람 크기 기준(미터). 메카 크기는 오브젝트 스케일로.

## 0.13.1
- 뷰포트 핸들은 실제 창에서 드래그해 본 적 없음(배치 계산과 값 변환만 테스트). 다이얼/화살표 크기·방향이 화면에서 어색할 수 있음.
- Tight 꺾임에서 옆으로(판 평면 안) 꺾으면 반경 = 판의 절반 폭(겹치지 않는 최소값)이라 위아래 Tight보다 크게 둥금.
- 구간 + 삽입은 Linear 보간일 때 모양이 정확히 유지(Smooth/Step 구간은 약간 달라질 수 있음).

## 0.13.0 Station Primitive
- 뷰포트 핸들 없음: 패널(지점 목록 + 값)로만 편집. GUI에서 실행해 본 적 없음.
- 단면 종류는 프리미티브 전체에 하나(지점마다 값은 다름). 릿지는 전체 길이에 걸침(시작/끝 지점 지정은 Phase 2).
- Cut/Boolean 하면 파라미터 동결(비파괴 연산 쌓기는 아님). Apply는 파라미터 삭제.
- 접힘 각도가 170° 이상이면 마이터 제한 경고. 아주 큰 비틀림 + 접힘 조합의 자가 교차는 검사하지 않음.

## 0.12.0 (먼저 읽기)
- **하단 툴바·Q 파이·툴팁은 실제 창에서 한 번도 그려 보지 못했습니다** (headless에는 화면이 없음). 등록, 키맵, 아이콘 이름,
  배치 계산만 테스트. 툴팁이 Blender 기본 방식으로 뜨는지, 버튼 위치가 Windows UI 배율에서 맞는지 확인 필요.
- 툴바에는 지금 애드온에 있는 도구만 있음(Smart Cleanup은 프로토타입에만 있음, 미구현). Box Hide는 0.23.16에 들어감.
- 옵션 카드(뷰포트 위 떠 있는 패널)는 아직 없음: 대신 도구 헤더에 도형 + 대상 토글. 사이드바(N)는 그대로.
- 그룹 진입(Scope), Mecha Layers, 미러 평면 기즈모, Quick Place는 프로토타입에만 있음.
- 자동 대상은 관통(Through) 깊이와 같이 화면에서 덮인 메시를 자름: 앞에 가려진 뒤쪽 메시도 도형이 덮으면 잘림.
- 기본값이 Selected → Auto Target으로 바뀜. 예전처럼 쓰려면 헤더에서 "Selected Only" 또는 T.

## 00000. 0.11.3
- Radial Array 충돌: headless에서 재현 안 됨(속성 40회 변경, Boolean 연결·미리보기·적용). 원인 후보(단축키 편집 행의 오래된
  KeyMapItem 참조)를 고쳤지만 확정 아님 → `C:\Users\<이름>\AppData\Local\Temp\blender.crash.txt` 내용 필요.
- MECHA LAB Workspace의 Object Mode에서 N = Quick Menu → 사이드바는 View 메뉴 > Sidebar 또는 단축키 편집 행에서 N을 다른 키로.
- Lean Mirror: 도구 목록(왼쪽 편집기)에서 고르면 마우스가 뷰포트 밖에 있어 첫 이동 때 축이 바로 바뀔 수 있음. 실제 GUI 미검증.
- "기울어진 알약 3개"는 서로 떨어진 3개(환풍구 모양)로 만듦. 서로 붙은 모양이 필요하면 알려 주세요.

## 0000. 0.11.2
- 일반 Cube "whole object" 오류는 여전히 headless에서 재현되지 않음(가짜 투영, 실제 RegionView3D 원근/직교, 모달 경로, Edit Mode 모두
  시도). 0.11.2의 오류 메시지 대괄호 부분과 Self Test의 "real 3D View projection" 줄이 원인 판단에 필요.

## 000. 0.11.1 (먼저 읽기)
- **일반 Cube에서 "would delete the whole object" 오류는 headless에서 재현되지 않았습니다.** MCH_Box(Live Primitive)는 재현·수정.
  Cube에서 아직 나오면 오류 메시지 끝의 `[대상: 연산, solvers tried: ...]` 부분과 **Run Mecha Lab Self Test** 결과를 보내 주세요.
  연산이 "Keep inside"로 나오면 Alt가 눌린 것으로 판정된 것입니다.
- Live Primitive를 Cut/Split/Boolean하면 Live 상태가 해제되고 일반 메쉬가 됩니다(Primitive 슬라이더로 다시 편집 불가).
- Select / Move 단축키 W는 MECHA LAB Workspace의 Object Mode에서만 동작(다른 Workspace의 W = Blender 기본 선택 순환 그대로).
  실제 GUI에서 W 입력·기즈모 표시·모달 취소는 **미검증**(headless는 툴 변경 시 모달 취소 로직만 확인).
- 0.10.0 항목 중 "Alt+짧은 클릭", "직선 Cut Ctrl+클릭"은 0.11.1에서 없어졌습니다(아래 0절은 기록용).

## 00. 0.11.0 Mechanical Toolkit 한계 (먼저 읽기)
- **Windows / Blender 5.0.2·5.3 GUI 미검증.** 기하·로직은 headless 테스트(99항목)로 확인.
- Face Extract / Armor: 파츠는 선택 영역 사본으로 만듦(원본이 나중에 바뀌어도 파츠는 그대로). Armor의 능선 선명도는
  **Resolution**(선택 면 세분) 에 좌우됨 — 능선이 메시 엣지와 정렬되는 것은 아님. 선택 3,000면·Resolution 1에서 슬라이더 1회
  약 0.35초(이 컨테이너 CPU), 큰 선택은 Resolution 0 권장.
- Armor 방향별 값은 경계 정점의 방향 각도로 섞임(N/E/S/W cos² 분할). Bevel Segments는 방향마다 다르게 줄 수 있지만 한 파츠의
  링 수는 최댓값으로 통일(적은 방향은 같은 선 위에 점이 놓여 보이는 모양은 동일). 날카로운 방향(폭 0)은 아주 작은 챔퍼(크기의
  0.2%)를 가짐.
- Armor는 챔퍼 방향 Inward만(Outward는 Basic). Split 능선은 실제 분리가 아니라 깊고 좁은 V홈.
- 엣지 폭이 파츠 높이/크기보다 크면 자동 축소되고 패널에 메모가 뜸. 선택이 한 점에서만 맞닿는 경우 거부.
- Bevel Angle은 Basic의 측면 세로 엣지(Bevel 모디파이어, 가중치)에만. Armor 측면 엣지는 방향별 Bevel로.
- Edge Molding: 코너는 마이터(최대 1/0.3배). 매우 날카로운 코너는 겹칠 수 있음. Armor 중앙선 몰딩은 파츠 윗면에 레이캐스트.
- Hollow: Rim Thickness / 개구부는 원본 오브젝트에 Vertex Group·면 속성(`mch_opening`)을 추가함(형상은 불변, Reset 시 제거).
  자기교차 검사는 겹치는 삼각형 + 안쪽 공간보다 두꺼운 정점 수(대략적).
- Mesh Along Curve: Curve Deform은 슬라이더가 메쉬 오브젝트 위치를 커브 기준으로 설정(메쉬를 직접 옮기면 다음 슬라이더 변경 시
  되돌아감). Curve Array Rigid는 편집 중 인스턴스, Apply 때 실제 메쉬로 변환.
- Cable: 경로 슬라이더를 바꾸면 Edit Mode에서 직접 옮긴 점은 다시 계산됨(두께·단면 슬라이더는 경로를 건드리지 않음).
  처짐은 월드 -Z 방향.
- Undo/Redo는 각 연산자(REGISTER/UNDO)와 슬라이더 변경 단위 — headless에서는 Undo 스택을 실행할 수 없어 GUI 확인 필요.
- 미구현: Custom Guide Mode(표면에 직접 능선 그리기), 메쉬 프로파일(커브만) 케이블, 몰딩/케이블 공유 일괄 편집 UI.


## 0. 0.10.0에서 먼저 알아야 할 것
- **사용자 보고 B01 Mirror / B02 Loft / B03 Smart Fuse는 headless에서 재현되지 않았습니다.** 0.10.0의 수정은 GUI에서만 생길 수
  있는 원인(등록 중단 B09, 도구 목록에서의 툴 전환 실패, 미확정 Fuse 미리보기의 패널 점유, Undo 후 남은 상태)을 고친 것이며
  실제 원인과 같다고 단정할 수 없습니다. 아직 문제가 있으면 **Workspace & Hotkeys > Run Mecha Lab Self Test** 결과(클립보드에
  복사됨)와 Blender 시스템 콘솔 로그를 보내 주세요.
- Alt+짧은 클릭 판정: 0.5초 이내, 5px×UI Scale 이내 이동. Object Mode의 Alt+클릭 복귀는 Blender의 `CLICK` 이벤트 사용
  (Blender 기본 Alt+클릭 = 오브젝트 목록 선택은, 오브젝트가 없는 곳에서는 그대로 동작).
- 직선 Cut의 "남길 쪽 클릭"은 Alt+클릭에서 **Ctrl+클릭**으로 바뀜(Alt+클릭은 도구 종료).
- Base Mesh Alt+드래그 커터: Flat/Chamfer/Bevel만(Dome은 거부). 깊이 = Height, 표면 바로 위 1% 높이에서 시작(동일 평면 회피).
  대상은 선택된 메쉬(Live Base Mesh 제외), 없으면 도형 중심 아래 메쉬.
- Base Mesh 세션 Auto Apply = Live 해제(Freeze)이며 형상은 그대로. "세션"은 마지막으로 도구를 떠난 뒤 만든 Base Mesh.
- Stabilizer: 드로잉 중 60Hz 타이머. Strength 100%의 시간 상수 0.35초. 마우스를 놓으면 커서까지 따라와 끝남(ZBrush처럼 지연
  위치에서 멈추는 옵션은 없음). Mask(숨김)에는 연결하지 않음.
- Deform: Falloff 거리는 직선(유클리드) 거리 — 굽은 Bend Curve에서는 곡선을 따라 잰 거리가 아님. Mecha 기즈모는 선택 중심에
  표시(Each Point 피벗일 때도 위치는 중심). Bend Curve Scale = 반지름(두께)만, 점 위치는 그대로. Lattice 해상도 변경은 Blender가
  기존 변형을 재샘플(B-Spline에서는 근사). Rigid Pose는 여전히 미구현.
- Mask는 숨김만 했습니다(코드·데이터 유지). 완전 삭제는 승인 후.


## A. 검증되지 않은 것 (가장 중요)
**Windows 11 + Blender 5.0.2 GUI에서 실행된 적이 없습니다.** 모든 자동 테스트는 Linux headless `bpy 5.0.1`입니다.
headless에는 창·실제 이벤트가 없으므로 아래는 **GUI 미검증**입니다:
- Workspace 생성(`workspace.duplicate`) 및 타이머 기반 왼쪽 영역 분할, 왼쪽 Properties(Tool 탭) 도구 목록 표시.
- Tool Header의 공통 Shape 팔레트 표시·클릭, 팝업(`wm.call_panel`) 위치·크기.
- 실제 이벤트 순서: Esc, 더블클릭(OS가 PRESS+DOUBLE_CLICK을 함께 보내는 경우 포함), 트리플 클릭 시간창(최대 0.72초,
  12px), RMB 단일/더블 타이밍, Free Draw 중 MOUSEMOVE 빈도, Lasso 드래그 그리기.
  → 상태기계 자체는 같은 클래스에 가짜 이벤트를 넣는 테스트(68개)로 검증했지만 GUI 이벤트 우선순위를 증명하지는 않습니다.
- WorkSpaceTool 키맵(LMB/RMB/Esc/Space)이 Object Mode 기본 키보다 우선하는지.
- Loft의 Live 갱신은 depsgraph 핸들러로 headless에서 동작 확인(커브 점/오브젝트 이동). GUI에서 편집 모드로 커브를 고칠 때의
  갱신 빈도/성능은 미측정.
- ZBrush: 실제 ZBrush가 없어 **ZBrush가 쓴 OBJ 파일로는 테스트하지 않았습니다**(파일 내용을 바꿔 ZBrush 수정을 흉내 냄).
  ZBrush의 OBJ 축/스케일 관례(위아래 뒤집힘 등)는 사용자 환경에서 Forward/Up/Scale로 맞춰야 할 수 있습니다.

## B. 구현됐지만 범위가 좁은 것 (부분 구현)
- **Base Mesh**: 뷰에 수직인 평면 위 독립 솔리드만. Surface Follow / Project(곡면을 따라 휘는 장갑판)는 미구현.
  Dome의 Edge Height는 최소 Height의 1% (0이면 닫힌 솔리드를 만들 수 없음). Dome 해상도 상한(내부 점 12,000개).
  Bevel/Chamfer 폭이 너무 크면 Blender bevel clamp로 줄어듦. 원근 뷰에서는 윤곽이 평면에 원근 투영됨(그 뷰에서 보면 일치).
- **Curve Lasso**: 핸들은 정렬된 대칭 핸들(좌우 길이/방향 독립 아님). 첫 점 클릭은 '닫기'라서 첫 점을 각진 점으로 바꾸려면
  다른 점을 먼저 찍은 뒤 조정해야 함. 급한 곡선은 자기교차할 수 있음(이때는 획을 유지하고 경고).
- **Loft/Surface**: 열린/닫힌 커브 혼합 불가. 각 커브의 첫 스플라인만 사용. 섹션 순서는 활성 커브부터 가까운 순서(또는 이름).
  연속성(G1/G2), 트리밍, 진짜 NURBS 패치 없음. Cap은 n-gon(비평면일 수 있음).
- **ZBrush Bridge**: OBJ만, GoZ 아님. 다시 가져오면 UV·셰이프 키·커스텀 속성은 OBJ에 담긴 것만 남음. 머티리얼은 슬롯 목록만 복사.
  OBJ 그룹이 여러 개면 하나의 메쉬로 합쳐 원래 오브젝트에 넣음(사용자 오브젝트끼리 Join하는 것은 아님).
- **Esc 동작 변경**: 이제 Esc는 항상 선택 도구로 돌아갑니다. 그리던 획만 지우고 도구에 남고 싶으면 Backspace/Ctrl+Z로 점을 지우세요.
- Mecha 도구 4개(Cut/Split/Mask/Base Mesh)는 모든 Workspace의 Object Mode T툴바에 보입니다(Blender 도구 등록이 전역).
  단축키(Space/B/C)는 MECHA LAB 탭에서만.
- 우클릭 선택(Right-Click Select) 키맵 사용자는 Mecha 도구 중 RMB가 선택 대신 팝업/종료로 동작.
- Mask: **면 단위**, Cut/Boolean 보호 없음, Weight/Pose 없음. Live Cut(Auto Apply OFF)에서는 Edge Finish 미적용.
  Smart Fuse는 실제로 겹친 닫힌 메쉬만.

## B-2. 0.9.0 기능의 범위
- Mesh Curve: Twist는 시작→끝 선형 누적(구간별 제어 없음). 경로에 기존 tilt가 있으면 더해짐. Rotation은 단면/복제본 기준.
  Edit Mode 점 더블클릭 키맵은 Blender의 다른 Curve 더블클릭 동작보다 먼저 받음(Mecha 경로가 아니면 통과) — GUI 미검증.
- SubD Plane: Crease는 선택 엣지에 값 쓰기만(전용 시각화 없음). Apply All은 Simple→CC→Solidify 순서만 적용하고 그 밖의
  사용자 모디파이어는 남김.
- Radial: Ring Rotation은 링 중심(3D 커서 위치에 놓인 캐리어 원점) 기준. 오브젝트 회전과 함께 쓰면 둘 다 적용됨.
- Gap Split: Gap Width는 대상 중심 깊이에서 화면 픽셀로 환산 → **직교 뷰에서는 정확, 원근 뷰에서는 깊이에 따라 약간 다름**.
  오목한 도형에서 Gap이 오목부보다 크면 거부. Live(Auto Apply OFF) 미지원.
- Split 양쪽 마감은 Cap Split ON일 때만(캡 면이 없으면 '새 엣지'가 없음).

## C. 미구현
- Base Mesh의 Surface Follow / Project.
- GoZ 프로토콜, ZBrush 자동 작업(DynaMesh 등은 사용자가 ZBrush에서 직접).
- Mask Protect / 정확 윤곽 / Weight Extract, Pose(Rigid/Soft), FBX/Asset Browser 커터, 사용자 키 설정 전용 UI,
  Workspace 템플릿 .blend. (Radial Array 개별 방향은 0.9.0에서 Copy Rotation / Rotate Each Copy로 구현.)
