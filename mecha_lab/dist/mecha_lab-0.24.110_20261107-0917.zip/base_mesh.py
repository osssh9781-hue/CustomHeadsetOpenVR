"""Base Mesh from Shape: create a NEW closed solid from a drawn screen outline.

This is a generator, not a cut and not a mask extract: the scene is never
modified except for the new object.  Outline -> plane -> profile:

* The outline is projected through the view onto a plane perpendicular to the
  view, placed at the surface under the shape (if any) or at the 3D cursor.
  The object's local XY is that plane and local +Z points toward the viewer,
  so the silhouette seen from the drawing view is exactly the drawn outline.
* FLAT     straight walls, flat top.
* CHAMFER  flat solid + one-segment bevel on the TOP rim only.
* BEVEL    flat solid + rounded (N-segment) bevel on the TOP rim only.
* DOME     the whole top surface bulges: height = Edge Height + Height *
           f(d / R), where d is the distance to the outline (holes included)
           and R the largest such distance.  The top is a constrained Delaunay
           triangulation of the densified outline plus interior grid points,
           so concave outlines never produce the flipped faces of a
           centre-fan.  This is a real height field, not a bevel.
* PUFF     0.24.20 an inflated lump: the same kind of point set (denser, extra rows along the outline), a
           height field on BOTH sides meeting at the outline (no wall) - a thin part (arm) gets a thin tube, a
           wide part a fat one: height = Puff * sqrt(f), -laplace(f) = PUFF_C inside, f = 0 on the outline
           ("Teddy" inflation, cotangent Laplacian + conjugate gradients), then a light relax.

The outline and settings are stored on the object (``Object.mch_base``), so
changing the profile / height / resolution later rebuilds the mesh (Live).
"""
from __future__ import annotations

import json
import math

import bmesh
import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty, StringProperty
from mathutils import Matrix, Vector
from mathutils.geometry import delaunay_2d_cdt

from . import target_rules
from . import core_geometry as cg
from . import tool_state as ts
from . import facet_carve as fc

PROFILES = (
    ('FLAT', 'Flat', 'Flat top and straight side walls', 'profile_flat', 'MESH_PLANE'),
    ('CHAMFER', 'Chamfer', 'Straight angled cut along the top border', 'profile_chamfer', 'MOD_BEVEL'),
    ('BEVEL', 'Bevel', 'Rounded top border only (width / segments)', 'profile_bevel', 'MOD_SUBSURF'),
    ('DOME', 'Rounded / Dome', 'The whole top bulges smoothly from the border inward '
     '(height field, not a bevel)', 'profile_dome', 'MESH_UVSPHERE'),
    ('PUFF', 'Puff', 'Inflated lump: round on both sides, every part as thick as it is wide '
     '(arm-like outlines become tubes) - a sculpting base', 'profile_puff', 'META_BALL'),
    ('RIDGE', 'Ridge', 'Rounded edge rising to a sharp ridge along the middle of the shape '
     '(diamond cross-section)', 'profile_ridge', 'MESH_ICOSPHERE'),
    ('PILLOW', 'Pillow', 'Flat in the middle, only the outer edge rounded (cushion / pill)', 'profile_pillow',
     'MESH_CYLINDER'),
    # 0.24.20 a Base Mesh profile (listed after the creature ones so saved enum numbers stay)
    ('CUSHION', 'Cushion', 'Soft cushion along the drawn outline: puffy on both sides, pinched to a seam around '
     'the edge (Height = total thickness, Edge Round = how puffy the rim is)', 'profile_cushion', 'MOD_CLOTH'),
)
PROFILE_ITEMS = [(p[0], p[1], p[2], p[4], i) for i, p in enumerate(PROFILES)]
SIDE_ITEMS = [
    ('TOP', 'Top Only', 'Bevel / Chamfer on the top rim; bottom flat and sharp', 'TRIA_UP', 0),
    ('BOTTOM', 'Bottom Only', 'Bevel / Chamfer on the bottom rim; top flat and sharp', 'TRIA_DOWN', 1),
    ('BOTH', 'Both Sides', 'Top and bottom rims (separate width / segments possible)', 'ARROW_LEFTRIGHT', 2),
    ('NONE', 'None', 'No bevel: flat and sharp', 'X', 3),
]
FLIP_SIDES = {'TOP': 'BOTTOM', 'BOTTOM': 'TOP', 'BOTH': 'BOTH', 'NONE': 'NONE'}
SETTING_KEYS = ('height', 'wall', 'bevel_width', 'bevel_segments', 'roundness', 'resolution', 'offset',
                'bottom_too', 'bevel_sides', 'bevel_width_bottom', 'bevel_segments_bottom', 'bevel_link', 'puff',
                'outline_smooth', 'edge_round', 'peak', 'attach_curve', 'profile_sweep', 'section_width',
                'section_rotation', 'section_twist', 'section_taper')
SWEEP_KEY = 'mch_base_line_sweep'  # 0.24.103 serialized path + alpha loops for live rebuild
DEPTH_KEY = 'mch_base_depth_guide'   # side-view polyline reshapes the base depth, kept live
ATTACH_KEY = 'mch_base_attach'          # 0.24.57 Line: the ends stuck to the meshes where the line began / ended
MAX_DOME_POINTS = 12000
MAX_PUFF_POINTS = 60000
PUFF_RINGS = (0.12, 0.3, 0.55, 0.85)      # rows just inside the outline (in point spacings): an even round rim


CARRY_KEYS = ('profile', 'height', 'wall', 'bevel_width', 'bevel_segments', 'roundness', 'resolution', 'offset',
              'bevel_sides', 'bevel_width_bottom', 'bevel_segments_bottom', 'bevel_link', 'puff', 'outline_smooth',
              'edge_round', 'section_rotation', 'section_twist', 'section_taper')
# 0.24.107 'profile_sweep' / 'section_width' are not carried: a Press Cut Alt+draw part (always a shape sweep) had
# every later plain Base Mesh line turned into a shape sweep once one of its sliders was touched.


def _rebuild_now(name):
    ob = bpy.data.objects.get(name)
    st = getattr(ob, 'mch_base', None) if ob is not None else None
    if st is None or not st.live or not st.outline:
        return
    try:
        rebuild(ob)
        st.last_error = ''
    except (cg.CutError, ValueError, RuntimeError) as ex:
        st.last_error = str(ex)


def _rebuild_update(self, context):
    ob = self.id_data
    if isinstance(ob, bpy.types.Object) and self.live and self.outline:
        from . import live_queue                 # 0.24.73 at a steady pace while a slider is dragged (R10)
        name = ob.name
        live_queue.queue(('base_mesh', name), lambda: _rebuild_now(name))
        # 0.24.5 what you set on the live shape is used for the next one too (it reset to the old defaults)
        # 0.24.20 creature shapes carry into the Creature Base Mesh defaults, the others into Base Mesh
        st = getattr(getattr(context, 'scene', None), 'mch_cbase' if self.profile in CREATURE_PROFILES else 'mch_base',
                     None)
        if st is not None:
            for k in CARRY_KEYS:
                try:
                    if getattr(st, k) != getattr(self, k):
                        setattr(st, k, getattr(self, k))
                except (AttributeError, TypeError):
                    pass


def _ramp_live_update(self, context):
    """0.24.45 a Ramp slider moved: the live ramp (if any) is carved again."""
    try:
        from . import ramp_edit
        ramp_edit.refresh_later(context, 'base')     # 0.24.83 from a timer, not in the update
    except Exception:          # a slider must never fail
        pass


class MCH_PG_BaseMesh(bpy.types.PropertyGroup):
    """Scene.mch_base = defaults for new shapes; Object.mch_base = live settings."""
    profile: EnumProperty(name='Profile', items=PROFILE_ITEMS, default='FLAT', update=_rebuild_update)
    height: FloatProperty(name='Height', default=0.2, min=0.0001, soft_max=10.0, precision=4,
                          unit='LENGTH', update=_rebuild_update,
                          description='Flat/Chamfer/Bevel: total thickness. Dome: bulge above the edge height')
    wall: FloatProperty(name='Edge Height', default=0.03, min=0.0, soft_max=5.0, precision=4,
                        unit='LENGTH', update=_rebuild_update,
                        description='Dome: straight side wall below the bulge (minimum 1% of Height)')
    bevel_width: FloatProperty(name='Border Width', default=0.05, min=0.0, soft_max=2.0, precision=4,
                               unit='LENGTH', update=_rebuild_update)
    bevel_segments: IntProperty(name='Segments', default=4, min=1, max=32, update=_rebuild_update)
    roundness: FloatProperty(name='Roundness', default=0.34, min=0.0, max=1.0, update=_rebuild_update,
                             description='Dome profile: 0 = straight roof, ~0.33 = circular, 1 = full / boxy')
    resolution: IntProperty(name='Resolution', default=28, min=4, max=128, update=_rebuild_update,
                            description='Dome / Puff samples across the shape (higher = smoother, heavier)')
    puff: FloatProperty(name='Puff', default=1.0, min=0.05, soft_max=2.5, update=_rebuild_update,
                        description='Puff: thickness against width - 1 = round cross-sections, '
                                    '0.5 = flattened, 2 = taller than wide')
    outline_smooth: FloatProperty(name='Soft Outline', default=0.5, min=0.0, max=1.0, update=_rebuild_update,
                                  description='Puff: round off the corners of the drawn outline (0 = exactly as '
                                              'drawn, 1 = very soft)')
    peak: FloatProperty(name='Height', default=0.0, min=0.0, soft_max=10.0, precision=4, unit='LENGTH',
                        update=_rebuild_update,
                        description='Creature shapes: height of the top (0 = Auto, the shape\'s own height; '
                                    'set to the real value when the shape is made)')
    edge_round: FloatProperty(name='Edge Round', default=0.15, min=0.0, max=1.0, update=_rebuild_update,
                              description='Ridge: how round the outer edge is before the straight faces '
                                          'climb to the ridge (0 = sharp edge)')
    offset: FloatProperty(name='Offset', default=0.0, soft_min=-5.0, soft_max=5.0, precision=4,
                          unit='LENGTH', update=_rebuild_update,
                          description='Move the solid along its normal (toward the viewer is positive)')
    bottom_too: BoolProperty(name='Bevel Bottom Too (old)', default=False, update=_rebuild_update,
                             description='v0.8-0.9 option, migrated to Bevel Sides = Both')
    bevel_sides: EnumProperty(name='Bevel Sides', items=SIDE_ITEMS, default='TOP', update=_rebuild_update,
                              description='Where the Bevel / Chamfer profile goes (Alt + draw cutter flips Top/Bottom)')
    bevel_width_bottom: FloatProperty(name='Bottom Width', default=0.05, min=0.0, soft_max=2.0, precision=4,
                                      unit='LENGTH', update=_rebuild_update)
    bevel_segments_bottom: IntProperty(name='Bottom Segments', default=4, min=1, max=32, update=_rebuild_update)
    bevel_link: BoolProperty(name='Same Top / Bottom', default=True, update=_rebuild_update,
                             description='Both Sides: bottom uses the top Width / Segments')
    sketch: BoolProperty(name='Sketch First', default=True,
                         description='Draw = add to an orange sketch, Alt+draw = subtract from it; '
                                     'Enter makes the mesh (Alt+Enter cuts it into the mesh below). '
                                     'Off: every outline becomes a mesh at once (Alt+draw = cutter)')
    # 0.24.103 Cross-section sweep for Base Mesh Line and Unified Press Alt+Draw.
    # OFF is intentionally backward-compatible with the existing band / profile engine.
    profile_sweep: EnumProperty(name='Line Cross Section', items=(
        ('OFF', 'Normal Line', 'Use the usual Base Mesh line / silhouette'),
        ('CIRCLE', 'Circle', 'Sweep a circular cross section along the drawn line'),
        ('SQUARE', 'Square', 'Sweep a square cross section along the drawn line'),
        ('ALPHA', 'Press Cut Shape', 'Sweep the selected saved Press Cut stamp outline as a cross section')),
        default='OFF', update=_rebuild_update)
    section_width: FloatProperty(name='Section Width', default=0.2, min=0.001, soft_max=10.0,
                                 unit='LENGTH', precision=4, update=_rebuild_update)
    section_rotation: FloatProperty(name='Section Rotation', default=0.0, min=-math.pi*2,
                                    max=math.pi*2, subtype='ANGLE', update=_rebuild_update)
    section_twist: FloatProperty(name='Twist Along Line', default=0.0, min=-math.pi*8,
                                 max=math.pi*8, subtype='ANGLE', update=_rebuild_update)
    section_taper: FloatProperty(name='End Taper', default=0.0, min=0.0, max=0.95,
                                 subtype='FACTOR', update=_rebuild_update,
                                 description='Shrink the cross-section at the start and end of the path')
    depth_mode: BoolProperty(name='Depth Guide Mode', default=False,
                             description='Draw front silhouette first, then draw a side-view depth guide on its live mesh')
    line_attach: BoolProperty(name='Attach Ends', default=False,
                              description='Line mode: the start of the line sticks to the mesh where you began drawing, '
                                          'the end to the mesh where you let go (the line runs between them in 3D)')
    attach_curve: EnumProperty(name='Between', default='SMOOTH', update=_rebuild_update, items=(
        ('SMOOTH', 'Smooth', 'The line in between is smoothed and leaves each mesh gently (eases in and out)'),
        ('DRAWN', 'As Drawn', 'The line in between is exactly what you drew, rising / falling evenly from one end to '
                              'the other')),
        description='Attach Ends: how the line runs between its two ends')
    surface_align: BoolProperty(name='Stick to Surface', default=True,
                                description='Drawn over a mesh: the new solid sits ON that surface (turned to the '
                                            'surface normal, its bottom sunk just enough to leave no gap). '
                                            'Off: the solid faces the view (old behaviour)')
    alt_mode: EnumProperty(name='Alt', default='HEIGHT', items=[
        ('HEIGHT', 'Alt: Carve Height', 'Alt + draw carves the drawn shape into the mesh, as deep as Height'),
        ('THROUGH', 'Alt: Through', 'Alt + draw cuts a window right through the part, following its surface (it '
                                    'measures how thick the part is) - the rest stays as a frame'),
        ('RAMP', 'Alt: Ramp', 'Alt + draw carves the shape on a slope: deepest at the FIRST edge you drew '
                              '(Carve Depth), rising back to the surface across the shape (Ramp Length) - a facet '
                              'pressed into the surface'),
        ('INSIDE', 'Alt: Inside', 'Alt + draw carves a channel in the MIDDLE of the part (the drawn face and the '
                                  'back stay): it shows as windows where the drawing crosses the side walls - an '
                                  'inner frame'),
        ('CUT', 'Alt: Like Cut', 'Alt + draw cuts like the Cut tool (its Through All / From Surface depth)')],
        description='What Alt + draw does')
    carve_depth: FloatProperty(name='Carve Depth', default=0.0, min=0.0, soft_max=1.0, precision=4, unit='LENGTH',
                               update=_ramp_live_update,
                               description='Alt + draw carves this deep (0 = Height). Keep it less than the part is '
                                           'thick, or the carve goes right through to the other side')
    carve_steep: EnumProperty(name='Steep Edges', items=fc.STEEP_ITEMS, default='EVEN', update=_ramp_live_update,
                              description='Alt: Height / Ramp over a bent edge (each flat face gets its own floor): '
                                          'Even = every face the full depth across it, Limit = the same depth along '
                                          'your view (shallower down a steep side, like before)')
    ramp_length: FloatProperty(name='Ramp Length', default=1.0, min=0.05, max=1.0, subtype='FACTOR',
                               update=_ramp_live_update,
                               description='Alt: Ramp - how far across the shape the slope goes (1 = it meets the '
                                           'surface at the far side; less = deep and flat first, then the slope)')
    ramp_soft: FloatProperty(name='Ramp Soft', default=0.5, min=0.0, max=1.0, subtype='FACTOR',
                             update=_ramp_live_update,
                             description='Alt: Ramp - how softly the slope runs into the surface and the side walls '
                                         'round off toward the shallow end (0 = straight slope, sharp sides; the deep '
                                         'edge stays crisp)')
    inside_skin: FloatProperty(name='Skin', default=0.25, min=0.02, max=0.45, subtype='FACTOR',
                               description='Alt: Inside - how much of the thickness stays on each side (front and back)')
    invert_height: BoolProperty(name='Invert', default=False,
                                description='The height grows back, away from you (into the mesh) from where you draw, '
                                            'instead of toward you')
    embed: FloatProperty(name='Sink Into Surface', default=0.0, min=0.0, soft_max=1.0, precision=4,
                         unit='LENGTH', update=_rebuild_update,
                         description='How far the bottom reaches into the surface it was drawn on '
                                     '(set automatically so a curved surface leaves no gap)')
    # 0.24.20 bend the made shape (live object only; new shapes start straight)
    bend_up: FloatProperty(name='Bend Up / Down', default=0.0, min=math.radians(-300), max=math.radians(300),
                           subtype='ANGLE', update=_rebuild_update,
                           description='Bend along its length: + both ends rise, - both ends drop')
    bend_side: FloatProperty(name='Bend Sideways', default=0.0, min=math.radians(-300), max=math.radians(300),
                             subtype='ANGLE', update=_rebuild_update,
                             description='Bend along its length to the left / right (like a banana seen from above)')
    bend_style: EnumProperty(name='Bend Style', default='SMOOTH', update=_rebuild_update,
                             items=(('SMOOTH', 'Band', 'Bends evenly along the whole length, like a band'),
                                    ('ANGLE', 'Angle', 'A sharp fold at one spot, the two sides stay straight')))
    bend_round: FloatProperty(name='Outer Round', default=0.3, min=0.0, max=1.0, subtype='FACTOR',
                              update=_rebuild_update,
                              description='Angle: round off the outer tip of the fold (x thickness; 0 = sharp)')
    bend_round_in: FloatProperty(name='Inner Round', default=0.3, min=0.0, max=1.0, subtype='FACTOR',
                                 update=_rebuild_update,
                                 description='Angle: round the inside of the fold (x thickness; 0 = sharp crease)')
    bend_pos: FloatProperty(name='Bend Position', default=0.0, min=-0.9, max=0.9, subtype='FACTOR',
                            update=_rebuild_update,
                            description='Where along the length it bends (0 = the middle; Angle: where the fold is)')
    bend_axis: FloatProperty(name='Bend Direction', default=0.0, min=math.radians(-90), max=math.radians(90),
                             subtype='ANGLE', update=_rebuild_update,
                             description='Turn the bend direction (0 = along the longest side of the shape)')
    live: BoolProperty(name='Live', default=False,
                       description='Settings rebuild this object (outline stored on the object)')
    outline: StringProperty(default='', options={'HIDDEN'})
    last_error: StringProperty(default='', options={'HIDDEN', 'SKIP_SAVE'})


# -----------------------------------------------------------------------------
# 2D helpers
# -----------------------------------------------------------------------------


def _densify(loop, spacing):
    out = []
    n = len(loop)
    for i in range(n):
        a, b = loop[i], loop[(i + 1) % n]
        steps = max(1, int(math.ceil(math.dist(a, b) / spacing))) if spacing > 0 else 1
        for k in range(steps):
            t = k / steps
            out.append((a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t))
    return out


def _inside_many(points, loops):
    """0.24.20 even-odd inside test for many points at once (numpy); same answer as cg.point_in_loops."""
    try:
        import numpy as np
    except ImportError:   # pragma: no cover
        return [cg.point_in_loops(q, loops) for q in points]
    if not points:
        return []
    A = np.asarray([lp[i] for lp in loops for i in range(len(lp))], dtype=np.float64)
    B = np.asarray([lp[(i + 1) % len(lp)] for lp in loops for i in range(len(lp))], dtype=np.float64)
    P = np.asarray(points, dtype=np.float64)
    out = np.zeros(len(P), dtype=bool)
    ay, by, ax, bx = A[:, 1], B[:, 1], A[:, 0], B[:, 0]
    dy = np.where(by == ay, 1e-300, by - ay)
    for start in range(0, len(P), 1024):
        x = P[start:start + 1024, 0:1]
        y = P[start:start + 1024, 1:2]
        crosses = (ay > y) != (by > y)
        xi = ax + (bx - ax) * (y - ay) / dy
        out[start:start + 1024] = ((crosses & (x < xi)).sum(1) % 2) == 1
    return out.tolist()


def _distances(points, loops):
    """Distance of each point to the nearest outline segment (numpy if present)."""
    segs = [(lp[i], lp[(i + 1) % len(lp)]) for lp in loops for i in range(len(lp))]
    if len(points) * len(segs) > 2_000_000:
        # 0.24.20 many points: only the segments near each point (k nearest segment middles)
        from mathutils.kdtree import KDTree
        kd = KDTree(len(segs))
        for k, (a, b) in enumerate(segs):
            kd.insert(((a[0] + b[0]) / 2.0, (a[1] + b[1]) / 2.0, 0.0), k)
        kd.balance()
        res = []
        for p in points:
            best = 1e30
            for _co, k, _d in kd.find_n((p[0], p[1], 0.0), 8):
                a, b = segs[k]
                dx, dy = b[0] - a[0], b[1] - a[1]
                ll = dx * dx + dy * dy
                t = 0.0 if ll < 1e-18 else max(0.0, min(1.0, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / ll))
                best = min(best, math.hypot(p[0] - a[0] - t * dx, p[1] - a[1] - t * dy))
            res.append(best)
        return res
    try:
        import numpy as np
        P = np.asarray(points, dtype=np.float64)
        A = np.asarray([s[0] for s in segs], dtype=np.float64)
        B = np.asarray([s[1] for s in segs], dtype=np.float64)
        AB = B - A
        L2 = np.maximum((AB * AB).sum(1), 1e-18)
        out = np.empty(len(P))
        for start in range(0, len(P), 2048):
            p = P[start:start + 2048, None, :]
            t = np.clip(((p - A) * AB).sum(2) / L2, 0.0, 1.0)
            d = p - (A + t[..., None] * AB)
            out[start:start + 2048] = np.sqrt((d * d).sum(2)).min(1)
        return out.tolist()
    except ImportError:   # pragma: no cover
        res = []
        for p in points:
            best = 1e30
            for a, b in segs:
                dx, dy = b[0] - a[0], b[1] - a[1]
                ll = dx * dx + dy * dy
                t = 0.0 if ll < 1e-18 else max(0.0, min(1.0, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / ll))
                best = min(best, math.hypot(p[0] - a[0] - t * dx, p[1] - a[1] - t * dy))
            res.append(best)
        return res


def dome_profile(t, roundness):
    """0 at the border, 1 at the deepest interior point; superellipse family."""
    t = max(0.0, min(1.0, t))
    q = 1.0 + 3.0 * max(0.0, min(1.0, roundness))
    return (1.0 - (1.0 - t) ** q) ** (1.0 / q)


def _triangulate(points, n_boundary, loops_for_test, edges):
    """Constrained Delaunay; keep the triangles inside the outline.

    Triangles are grouped into regions separated by the constraint (outline)
    edges; each region is classified once by its largest triangle.  A per-
    triangle centroid test is unreliable for slivers along nearly collinear
    outline points (seen in oblique views).
    """
    res = delaunay_2d_cdt([Vector(p) for p in points], edges, [], 0, 1e-9, True)
    out_verts, out_edges, faces, orig_verts, orig_edges = res[0], res[1], res[2], res[3], res[4]
    mapping = []
    for orig in orig_verts:
        if not orig:
            raise cg.CutError('Outline intersects itself or touches a hole; redraw it.')
        mapping.append(orig[0])
    n_in = len(edges)
    constraint = set()
    for (a, b), orig in zip(out_edges, orig_edges):
        if any(o < n_in for o in orig):
            constraint.add((min(a, b), max(a, b)))
    edge_faces = {}
    for fi, f in enumerate(faces):
        for k in range(len(f)):
            key = (min(f[k], f[(k + 1) % len(f)]), max(f[k], f[(k + 1) % len(f)]))
            edge_faces.setdefault(key, []).append(fi)
    # Flood regions bounded by outline edges, then classify them by crossing
    # parity from the outside (beyond the convex hull): inside = odd number
    # of outline edges crossed.  Exact for holes and islands; no centroid
    # tests on slivers.
    region = [-1] * len(faces)
    n_regions = 0
    for seed in range(len(faces)):
        if region[seed] != -1:
            continue
        stack = [seed]
        region[seed] = n_regions
        while stack:
            fi = stack.pop()
            f = faces[fi]
            for k in range(len(f)):
                key = (min(f[k], f[(k + 1) % len(f)]), max(f[k], f[(k + 1) % len(f)]))
                if key in constraint:
                    continue
                for nb in edge_faces.get(key, ()):
                    if region[nb] == -1:
                        region[nb] = n_regions
                        stack.append(nb)
        n_regions += 1
    OUT = n_regions                      # virtual region beyond the hull
    links = {}
    for key, fl in edge_faces.items():
        regs = [region[fi] for fi in fl] + ([OUT] if len(fl) == 1 else [])
        if len(regs) != 2 or regs[0] == regs[1]:
            continue
        w = 1 if key in constraint else 0
        links.setdefault(regs[0], set()).add((regs[1], w))
        links.setdefault(regs[1], set()).add((regs[0], w))
    parity = {OUT: 0}
    queue = [OUT]
    while queue:
        r = queue.pop()
        for other, w in links.get(r, ()):
            if other not in parity:
                parity[other] = parity[r] ^ w
                queue.append(other)
    keep = []
    for fi in range(len(faces)):
        par = parity.get(region[fi])
        if par is None:      # disconnected (should not happen): fall back to a point test
            f = faces[fi]
            cx = sum(out_verts[i].x for i in f) / len(f)
            cy = sum(out_verts[i].y for i in f) / len(f)
            par = 1 if cg.point_in_loops((cx, cy), loops_for_test) else 0
        if par == 1:
            keep.append(fi)
    tris = []
    for fi in keep:
        idx = [mapping[i] for i in faces[fi]]
        if len(set(idx)) == len(idx):
            tris.append(idx)
    if not tris:
        raise cg.CutError('Outline could not be triangulated.')
    return tris


# -----------------------------------------------------------------------------
# Solid builders (local plane space: outline in XY, +Z = up)
# -----------------------------------------------------------------------------


def _orient_ccw(tri, pts):
    a, b, c = (pts[i] for i in tri)
    area = (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])
    return tri if area > 0 else [tri[0], tri[2], tri[1]]


def _add_prism(bm, outer, holes, height):
    loops = [outer] + list(holes)
    flat = [p for lp in loops for p in lp]
    bottom = [bm.verts.new((x, y, 0.0)) for x, y in flat]
    top = [bm.verts.new((x, y, height)) for x, y in flat]
    if not holes:
        bm.faces.new([bottom[i] for i in reversed(range(len(outer)))])
        bm.faces.new(top[:len(outer)])
    else:
        edges = []
        off = 0
        for lp in loops:
            n = len(lp)
            edges += [(off + i, off + (i + 1) % n) for i in range(n)]
            off += n
        for tri in _triangulate(flat, len(flat), loops, edges):
            tri = _orient_ccw(tri, flat)
            bm.faces.new([top[i] for i in tri])
            bm.faces.new([bottom[i] for i in reversed(tri)])
    rim_top, rim_bottom = [], []
    off = 0
    for lp in loops:
        n = len(lp)
        for i in range(n):
            a, b = off + i, off + (i + 1) % n
            bm.faces.new((bottom[a], bottom[b], top[b], top[a]))
            rim_top.append((top[a], top[b]))
            rim_bottom.append((bottom[a], bottom[b]))
        off += n
    return rim_top, rim_bottom


def _dome_points(outer, holes, p, rings=(), density=1.0, rim=1.0, cap=MAX_DOME_POINTS):
    """(dense loops, boundary points, interior points, distance of every point, spacing) for Dome / Puff.
    ``rings`` (fractions of the spacing): rows of points that far inside the outline (Puff: an even round rim)."""
    loops = [outer] + list(holes)
    xs = [q[0] for lp in loops for q in lp]
    ys = [q[1] for lp in loops for q in lp]
    extent = max(max(xs) - min(xs), max(ys) - min(ys))
    if extent <= 1e-9:
        raise cg.CutError('Outline has no size.')
    spacing = extent / max(4, p.resolution * density * ts.res_scale())     # (x Resolution, 0.24.95)
    if ts.res_scale() > 1.0:          # (a raised Resolution never makes a working shape fail: held at the point budget)
        bw, bh = max(xs) - min(xs), max(ys) - min(ys)
        spacing = max(spacing, math.sqrt(max(bw * bh, 1e-18) / (cap * 1.8)))
    dense = [cg.dedupe_loop(_densify(lp, spacing * rim), spacing * 1e-3) for lp in loops]
    boundary = [q for lp in dense for q in lp]
    interior = []
    nx = int(math.ceil((max(xs) - min(xs)) / spacing))
    ny = int(math.ceil((max(ys) - min(ys)) / spacing))
    if nx * ny > cap * 2:
        raise cg.CutError('Resolution too high for this outline; lower Resolution.')
    grid = [(min(xs) + i * spacing + (0.5 * spacing if j % 2 else 0.0), min(ys) + j * spacing)
            for i in range(nx + 1) for j in range(ny + 1)]
    cand = [q for q, inside in zip(grid, _inside_many(grid, dense)) if inside]
    if cand:
        dist = _distances(cand, dense)
        keep = (max(rings) + 0.4) * spacing if rings else 0.45 * spacing
        interior = [q for q, d in zip(cand, dist) if d > keep]
    for r in rings:
        ring = []
        for lp in dense:
            n = len(lp)
            for i in range(n):
                a, b, c = lp[i - 1], lp[i], lp[(i + 1) % n]
                # left of the walking direction is inside (outer CCW, holes CW)
                nx_, ny_ = -(c[1] - a[1]), c[0] - a[0]
                ln = math.hypot(nx_, ny_)
                if ln < 1e-12:
                    continue
                ring.append((b[0] + nx_ / ln * r * spacing, b[1] + ny_ / ln * r * spacing))
        ring = [q for q, inside in zip(ring, _inside_many(ring, dense)) if inside]
        if ring:
            dist = _distances(ring, dense)
            interior += [q for q, d in zip(ring, dist) if 0.6 * r * spacing < d < 1.4 * r * spacing]
    if len(interior) > cap:
        raise cg.CutError('Resolution too high for this outline; lower Resolution.')
    d_all = [0.0] * len(boundary) + (_distances(interior, dense) if interior else [])
    return dense, boundary, interior, d_all, spacing


def _loop_edges(dense):
    edges = []
    off = 0
    for lp in dense:
        n = len(lp)
        edges += [(off + i, off + (i + 1) % n) for i in range(n)]
        off += n
    return edges


def _add_dome(bm, outer, holes, p):
    dense, boundary, interior, d_all, spacing = _dome_points(outer, holes, p)
    pts = boundary + interior
    radius = max(max(d_all), spacing)
    nb = len(boundary)
    edges = _loop_edges(dense)
    # A zero edge height would make border-only top triangles coincide with the
    # bottom cap; keep a minimal wall (1% of the height) so the solid stays valid.
    wall = max(p.wall, p.height * 0.01, 1e-5)
    top = [bm.verts.new((x, y, wall + p.height * dome_profile(d / radius, p.roundness)))
           for (x, y), d in zip(pts, d_all)]
    bottom = [bm.verts.new((x, y, 0.0)) for x, y in boundary]
    top_faces = []
    for tri in _triangulate(pts, nb, dense, edges):
        tri = _orient_ccw(tri, pts)
        top_faces.append(bm.faces.new([top[i] for i in tri]))
    for tri in _triangulate(boundary, nb, dense, edges):
        tri = _orient_ccw(tri, boundary)
        bm.faces.new([bottom[i] for i in reversed(tri)])
    off = 0
    for lp in dense:
        n = len(lp)
        for i in range(n):
            a, b = off + i, off + (i + 1) % n
            bm.faces.new((bottom[a], bottom[b], top[b], top[a]))
        off += n
    for f in top_faces:
        f.smooth = True


PUFF_C = 2.5      # Poisson source: a disc of radius R gets 0.79 R, a long strip of half width w gets 1.12 w


def puff_heights(pts, tris, nb, puff=1.0):
    """0.24.20 heights of an inflated lump (the "Teddy" inflation): f solves -laplace(f) = C inside, f = 0 on the
    outline (cotangent Laplacian on the triangulation, conjugate gradients), height = Puff * sqrt(f).  Smooth
    everywhere, no ridge search: a wide part gets thick, a thin part thin, a taper tapers.  Boundary points
    (the first ``nb``) stay 0."""
    import numpy as np
    n = len(pts)
    m = n - nb
    if m <= 0:
        return [0.0] * n
    P = np.asarray(pts, dtype=np.float64)
    T = np.asarray(tris, dtype=np.int64)
    I, J, W = [], [], []
    area = np.zeros(n)
    for k in range(3):
        a, b, c = T[:, k], T[:, (k + 1) % 3], T[:, (k + 2) % 3]
        u, v = P[a] - P[c], P[b] - P[c]                    # the angle at c faces the edge a-b
        if P.shape[1] == 2:
            cross = np.abs(u[:, 0] * v[:, 1] - u[:, 1] * v[:, 0])
        else:                                              # 0.24.20 a surface in 3D (Creature Plate Through)
            cross = np.linalg.norm(np.cross(u, v), axis=1)
        cot = (u * v).sum(1) / np.maximum(cross, 1e-300)
        I.append(a); J.append(b); W.append(0.5 * cot)
        np.add.at(area, a, cross / 6.0)
    I, J, W = np.concatenate(I), np.concatenate(J), np.concatenate(W)
    # K = -L restricted to inside points (index - nb)
    inside_e = (I >= nb) & (J >= nb)
    ii, jj, ww = I[inside_e] - nb, J[inside_e] - nb, W[inside_e]
    diag = np.zeros(n)
    np.add.at(diag, I, W)
    np.add.at(diag, J, W)
    D = diag[nb:]

    def K(x):
        y = D * x
        np.subtract.at(y, ii, ww * x[jj])
        np.subtract.at(y, jj, ww * x[ii])
        return y

    rhs = PUFF_C * area[nb:]
    x = np.zeros(m)
    r = rhs - K(x)
    pdir = r.copy()
    rr = r @ r
    tol = 1e-16 * max(rhs @ rhs, 1e-300)
    for _ in range(4 * int(math.sqrt(m)) + 200):
        if rr <= tol:
            break
        Kp = K(pdir)
        alpha = rr / max(pdir @ Kp, 1e-300)
        x += alpha * pdir
        r -= alpha * Kp
        rr_new = r @ r
        pdir = r + (rr_new / rr) * pdir
        rr = rr_new
    out = [0.0] * nb + (puff * np.sqrt(np.maximum(x, 0.0))).tolist()
    return out


def ridge_heights(d_all, nb, slope=1.0, edge_round=0.3):
    """0.24.20 Ridge: height grows with the distance to the outline, so the two sides meet in a sharp ridge
    along the middle line of the shape (a diamond cross-section; corners get roof-like ridges toward them).
    height = slope * sqrt(d^2 + 2 a d): round (vertical) at the outline, straight faces further in;
    a = Edge Round * the deepest distance."""
    a = max(0.0, edge_round) * max(max(d_all), 1e-9)
    return [0.0 if i < nb else slope * math.sqrt(d * d + 2.0 * a * d) for i, d in enumerate(d_all)]


def chaikin(loop, iterations):
    """0.24.20 corner cutting: every pass replaces each corner by two points at 1/4 and 3/4 of its edges."""
    for _ in range(iterations):
        n = len(loop)
        out = []
        for i in range(n):
            a, b = loop[i], loop[(i + 1) % n]
            out.append((0.75 * a[0] + 0.25 * b[0], 0.75 * a[1] + 0.25 * b[1]))
            out.append((0.25 * a[0] + 0.75 * b[0], 0.25 * a[1] + 0.75 * b[1]))
        loop = out
    return loop


def pillow_heights(d_all, nb, edge_round=0.15):
    """0.24.20 Pillow: flat in the middle, a quarter-round edge of radius r = 2 * Edge Round * the deepest
    distance (round rim, flat top)."""
    r = max(0.02, 2.0 * max(0.0, edge_round)) * max(max(d_all), 1e-9)
    return [0.0 if i < nb else r * math.sqrt(max(0.0, 1.0 - (1.0 - min(d / r, 1.0)) ** 2))
            for i, d in enumerate(d_all)]


CREATURE_PROFILES = ('PUFF', 'RIDGE', 'PILLOW')
PUFF_BUILT = CREATURE_PROFILES + ('CUSHION',)      # built as a two-sided lump around the plane (_add_puff)


def cushion_heights(d_all, nb, edge_round=0.15):
    """0.24.20 Cushion: a puffy round rim of radius 3 * Edge Round of the deepest distance, pinched to a seam
    on the outline, the middle a little fuller (a stuffed cushion)."""
    dmax = max(max(d_all), 1e-9)
    r = max(0.05, 3.0 * max(0.0, edge_round)) * dmax
    return [0.0 if i < nb else math.sqrt(max(0.0, 1.0 - (1.0 - min(d / r, 1.0)) ** 2)) * (0.85 + 0.15 * math.sqrt(d / dmax))
            for i, d in enumerate(d_all)]


def scale_heights(d_all, nb, edge_round=0.15):
    """0.24.20 Creature Plate Scale: a knife-thin edge (a gentle wedge, no round rim) growing into a low
    dome; the wedge reaches the dome at 3 * Edge Round of the deepest distance."""
    r = max(0.05, 3.0 * max(0.0, edge_round)) * max(max(d_all), 1e-9)
    return [0.0 if i < nb else (1.0 - (1.0 - min(d / r, 1.0)) ** 2) * (1.0 + 0.25 * min(d / r, 3.0))
            for i, d in enumerate(d_all)]


def profile_field(outer, holes, p):
    """0.24.20 the creature shape of an outline (any 2D units): (boundary, pts, tris, nb, shape, natural, spacing).
    ``pts`` = boundary points (the first ``nb``, on the outline) + inside points, ``tris`` index them,
    ``shape`` = height of every point scaled to 1 at the top, ``natural`` = the top height the profile has by
    itself (Puff: about as thick as wide).  Shared by Creature Base Mesh and Creature Plate."""
    k = int(round(4 * max(0.0, min(1.0, getattr(p, 'outline_smooth', 0.0)))))
    if k and p.profile == 'CUSHION':
        k += 2                              # a cushion's rim is soft: no corner facets along the seam
    if k:
        outer, holes = chaikin(outer, k), [chaikin(h, k) for h in holes]
    dense, boundary, interior, d_all, spacing = _dome_points(outer, holes, p, rings=getattr(p, 'rings', PUFF_RINGS),
                                                             density=1.5, rim=getattr(p, 'rim', 0.5),
                                                             cap=MAX_PUFF_POINTS)
    pts = boundary + interior
    nb = len(boundary)
    edges = _loop_edges(dense)
    tris = [list(_orient_ccw(t, pts)) for t in _triangulate(pts, nb, dense, edges)]
    # an edge across the shape between two outline points (narrow spots) would be shared by the top AND the
    # bottom: split it at its middle (a new inside point)
    outline = {(min(e), max(e)) for e in edges}
    chords = {}
    for t in tris:
        for k in range(3):
            e = (min(t[k], t[(k + 1) % 3]), max(t[k], t[(k + 1) % 3]))
            if e[1] < nb and e not in outline and e not in chords:
                chords[e] = len(pts) + len(chords)
    if chords:
        extra = [None] * len(chords)
        for (i, j), m in chords.items():
            extra[m - len(pts)] = ((pts[i][0] + pts[j][0]) / 2.0, (pts[i][1] + pts[j][1]) / 2.0)
        split = True
        while split:                       # a triangle can carry up to three chords
            split = False
            out = []
            for t in tris:
                for k in range(3):
                    a, b, c = t[k], t[(k + 1) % 3], t[(k + 2) % 3]
                    m = chords.get((min(a, b), max(a, b)))
                    if m is not None:
                        out += [[a, m, c], [m, b, c]]
                        split = True
                        break
                else:
                    out.append(t)
            tris = out
        pts = pts + extra
        d_all = list(d_all) + _distances(extra, dense)
    if len(pts) == nb:
        raise cg.CutError('Outline too small for this shape; draw it bigger or raise Resolution.')
    edge_round = getattr(p, 'edge_round', 0.15)
    if p.profile == 'RIDGE':
        h = ridge_heights(d_all, nb, 1.0, edge_round)
    elif p.profile == 'PILLOW':
        h = pillow_heights(d_all, nb, edge_round)
    elif p.profile == 'SCALE':
        h = scale_heights(d_all, nb, edge_round)
    elif p.profile == 'CUSHION':
        h = cushion_heights(d_all, nb, edge_round)
    else:
        h = puff_heights(pts, tris, nb, 1.0)
    top = max(max(h), 1e-12)
    natural = top * getattr(p, 'puff', 1.0)
    if p.profile == 'SCALE':            # its own height is a unit curve: size it like a Puff of that width
        natural = max(d_all) * 0.8
    return boundary, pts, tris, nb, [x / top for x in h], natural, spacing


def peak_height(p, natural):
    """Height slider: 0 = Auto (the profile's own height)."""
    peak = getattr(p, 'peak', 0.0)
    return peak if peak > 0 else natural


def _add_puff(bm, outer, holes, p):
    boundary, pts, tris, nb, shape, natural, spacing = profile_field(outer, holes, p)
    LAST_NATURAL[:] = [natural]
    peak = p.height / 2.0 if p.profile == 'CUSHION' else peak_height(p, natural)   # Cushion: Height = total
    floor = min(spacing * 0.02, peak * 0.01)  # top and bottom never meet inside (they would be merged as doubles)
    h = [0.0 if i < nb else max(peak * x, floor) for i, x in enumerate(shape)]
    rim = [bm.verts.new((x, y, 0.0)) for x, y in boundary]
    inner = pts[nb:]
    top = rim + [bm.verts.new((x, y, hh)) for (x, y), hh in zip(inner, h[nb:])]
    bottom = rim + [bm.verts.new((x, y, -hh)) for (x, y), hh in zip(inner, h[nb:])]
    for tri in tris:
        bm.faces.new([top[i] for i in tri]).smooth = True
        bm.faces.new([bottom[i] for i in reversed(tri)]).smooth = True
    # a light relax of the whole lump: no beads along the round edge, no small dents
    mine = list(set(rim + top[nb:] + bottom[nb:]))
    for _ in range(1 if p.profile == 'RIDGE' else 2):          # Ridge: keep the middle crisp
        bmesh.ops.smooth_vert(bm, verts=mine, factor=0.5, use_axis_x=True, use_axis_y=True, use_axis_z=True)


LAST_NATURAL = []


def side_values(p, flip=False):
    """(sides, top (width, segments), bottom (width, segments)).  ``flip`` =
    Alt cutter: Top<->Bottom, Both swaps the two settings, None unchanged."""
    sides = getattr(p, 'bevel_sides', 'TOP')
    top = (p.bevel_width, ts.res_n(p.bevel_segments))                   # (segments x Resolution, 0.24.95)
    bottom = top if getattr(p, 'bevel_link', True) else (p.bevel_width_bottom, ts.res_n(p.bevel_segments_bottom))
    if flip:
        sides = FLIP_SIDES[sides]
        if sides == 'BOTH':
            top, bottom = bottom, top
    return sides, top, bottom


LAST_NOTES = []


def _bevel_rims(bm, p, rim_top, rim_bottom, flip=False):
    sides, top, bottom = side_values(p, flip)
    jobs = []
    if sides in {'TOP', 'BOTH'}:
        jobs.append(('top', rim_top, top))
    if sides in {'BOTTOM', 'BOTH'}:
        jobs.append(('bottom', rim_bottom, bottom))
    notes = []
    both = len(jobs) == 2
    for name, pairs, (width, segs) in jobs:
        limit = p.height * (0.48 if both else 0.95)     # rims never meet / pass the other side
        if width > limit:
            notes.append(f'{name} width limited to {limit:.4g} by the height')
            width = limit
        if width <= 0:
            continue
        edges = []
        for a, b in pairs:
            if a.is_valid and b.is_valid:
                e = bm.edges.get((a, b))
                if e is not None:
                    edges.append(e)
        if edges:
            verts = list({v for e in edges for v in e.verts})
            bmesh.ops.bevel(bm, geom=edges + verts, offset=width, offset_type='OFFSET',
                            segments=1 if p.profile == 'CHAMFER' else max(1, segs),
                            profile=0.5, affect='EDGES', clamp_overlap=True)
    return notes


def _region_ok(faces, up):
    for f in faces:
        if not f.is_valid or f.calc_area() <= 1e-12:
            return False
        f.normal_update()
        if (f.normal.z <= 0.0) if up else (f.normal.z >= 0.0):
            return False
    return True


BAND_LAYER = '.mch_pband'      # face: a row of a Bevel / Chamfer profile (until the part is marked)
ROW_LAYER = '.mch_prow'        # edge: between two rows of one profile, along the outline (a round's row edge)


def _flag_rows(bm, h, turn=math.radians(30.0)):
    """0.24.95 (user's bevel.fbx: "베벨로 된 거 디바이드 하면 옆면이 떠") the profile's edges between two of its rows
    flagged while the rings are still level (before Bend): 1 = a ROW (both ends at one height: it runs along the
    outline - one round, soft); between rings it is a MITER: 2 where the outline turns more than ``turn`` there (a
    sharp corner: the round swept round it has a sharp seam from the wall's corner up to the cap's - one line all
    the way, else the line stopped half way up and Divide folded the corner), 3 where it turns less (a curved
    outline: soft, like the wall's own edges there)."""
    band = bm.faces.layers.int.get(BAND_LAYER)
    if band is None:
        return
    row = bm.edges.layers.int.get(ROW_LAYER) or bm.edges.layers.int.new(ROW_LAYER)
    band = bm.faces.layers.int.get(BAND_LAYER)            # (looked up again: a new layer moves the data)
    eps = max(1e-6, 1e-5 * h)
    inside = []
    for e in bm.edges:
        lf = e.link_faces
        if len(lf) == 2 and lf[0][band] and lf[1][band]:
            if abs(e.verts[0].co.z - e.verts[1].co.z) <= eps:
                e[row] = 1
            else:
                inside.append(e)

    def ring_turn(v):
        # (the ring's own edges at v: level, on a band face - its rows, or its borders with the cap / the wall: a
        # 1-segment Chamfer has no rows)
        rs = [e for e in v.link_edges if abs(e.verts[0].co.z - e.verts[1].co.z) <= eps
              and any(f[band] for f in e.link_faces)]
        if len(rs) != 2:
            return 0.0
        a = rs[0].other_vert(v).co - v.co
        b = rs[1].other_vert(v).co - v.co
        a.z = b.z = 0.0
        if a.length <= 0.0 or b.length <= 0.0:
            return 0.0
        return math.pi - a.angle(b)
    for e in inside:
        e[row] = 2 if max(ring_turn(e.verts[0]), ring_turn(e.verts[1])) > turn else 3


def _profile_one(bm, faces, width, drop, segs, round_, up):
    """0.23.17 Bevel / Chamfer by insets: the rim drops by ``drop`` and the profile runs ``width`` across the
    flat side (the old bevel could not be wider than the thickness).  Returns False if the insets overlap."""
    if not faces:
        return True
    sign = 1.0 if up else -1.0
    verts = list({v for f in faces for v in f.verts})
    bmesh.ops.translate(bm, verts=verts, vec=(0.0, 0.0, -sign * drop))     # the outer rim goes down first
    n = 1 if not round_ else max(1, segs)
    xs, zs = [0.0], [0.0]
    for j in range(1, n + 1):
        if round_:
            phi = 0.5 * math.pi * j / n
            xs.append(width * (1.0 - math.cos(phi)))
            zs.append(drop * math.sin(phi))
        else:
            xs.append(width)
            zs.append(drop)
    region = list(faces)
    x0 = min(v.co.x for v in verts)
    x1 = max(v.co.x for v in verts)
    y0 = min(v.co.y for v in verts)
    y1 = max(v.co.y for v in verts)
    tol = 1e-6 * max(x1 - x0, y1 - y0, 1e-9)
    area = sum(f.calc_area() for f in region)
    for j in range(1, n + 1):
        dx, dz = xs[j] - xs[j - 1], zs[j] - zs[j - 1]
        if dx <= 1e-9 and dz <= 1e-9:
            continue
        res = bmesh.ops.inset_region(bm, faces=region, thickness=dx, depth=dz, use_even_offset=True,
                                     use_boundary=True, use_relative_offset=False)
        band = bm.faces.layers.int.get(BAND_LAYER)  # (made by _profile_rims before the copies: a new layer here
        if band is not None:                        # would drop every face reference held)
            for f in res.get('faces', []):          # 0.24.95 the profile's rows (Edge Memory: borders hard, rows soft)
                f[band] = 1
        if not _region_ok(region, up):
            return False
        # an inset wider than the shape folds over itself: the slope faces flip or points leave the outline
        for f in res.get('faces', []):
            f.normal_update()
            if f.calc_area() > 1e-12 and ((f.normal.z <= 0.0) if up else (f.normal.z >= 0.0)):
                return False
        for f in region:
            for v in f.verts:
                if not (x0 - tol <= v.co.x <= x1 + tol and y0 - tol <= v.co.y <= y1 + tol):
                    return False
        new_area = sum(f.calc_area() for f in region)
        if dx > 1e-9 and new_area >= area:
            return False
        area = new_area
    return True


def _profile_rims(bm, p, flip=False):
    """Bevel / Chamfer on the top and / or bottom of a prism.  Returns (bmesh, notes) - the bmesh may be a
    new one (the given one is freed then)."""
    sides, top, bottom = side_values(p, flip)
    jobs = []
    if sides in {'TOP', 'BOTH'}:
        jobs.append(('top', True, top))
    if sides in {'BOTTOM', 'BOTH'}:
        jobs.append(('bottom', False, bottom))
    notes = []
    h = p.height
    eps = max(h * 1e-4, 1e-7)
    if jobs and bm.faces.layers.int.get(BAND_LAYER) is None:
        bm.faces.layers.int.new(BAND_LAYER)           # 0.24.95 the rows the insets make get flagged (_flag_rows)
    for name, up, (width, segs) in jobs:
        if width <= 0:
            continue
        limit = h * (0.48 if len(jobs) == 2 else 0.95)       # the drop never reaches the other side
        w = width
        for _try in range(8):
            trial = bm.copy()
            zf = h if up else 0.0
            faces = [f for f in trial.faces if all(abs(v.co.z - zf) <= eps for v in f.verts)]
            ok = _profile_one(trial, faces, w, min(w, limit), segs, p.profile == 'BEVEL', up)
            if ok:
                bm.free()
                bm = trial
                break
            trial.free()
            w *= 0.7
        else:
            notes.append(f'{name}: no room for a bevel on this shape')
            continue
        if w < width - 1e-9:
            notes.append(f'{name} width limited to {w:.4g} by the shape')
    return bm, notes


def build_bmesh(groups, p, flip=False):
    """groups: [(outer CCW, [holes CW])] in local plane units. Returns a validated BMesh."""
    bm = bmesh.new()
    try:
        rim_top, rim_bottom = [], []
        for outer, holes in groups:
            if p.profile == 'DOME':
                _add_dome(bm, outer, holes, p)
            elif p.profile in PUFF_BUILT:
                _add_puff(bm, outer, holes, p)
            else:
                rt, rb = _add_prism(bm, outer, holes, p.height)
                rim_top += rt
                rim_bottom += rb
        bmesh.ops.remove_doubles(bm, verts=bm.verts[:], dist=1e-7)
        LAST_NOTES.clear()
        if p.profile in {'BEVEL', 'CHAMFER'}:
            bm, notes = _profile_rims(bm, p, flip)
            LAST_NOTES.extend(notes)
            _flag_rows(bm, p.height)
        embed = getattr(p, 'embed', 0.0) if p.profile not in PUFF_BUILT else 0.0   # centred on the plane
        if embed > 0:
            # Stick to Surface: the bottom reaches into the surface (no gap on curves)
            for v in bm.verts:
                if v.co.z <= 1e-7:
                    v.co.z -= embed
        if abs(p.offset) > 0:
            bmesh.ops.translate(bm, verts=bm.verts[:], vec=(0.0, 0.0, p.offset))
        _bend(bm, groups, p)
        if not bm.faces or any(not e.is_manifold for e in bm.edges):
            raise cg.CutError('Generated solid is not closed (outline too thin or touching itself).')
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
        if bm.calc_volume(signed=True) < 0:
            bmesh.ops.reverse_faces(bm, faces=bm.faces[:])
        if bm.calc_volume() <= 1e-12:
            raise cg.CutError('Generated solid has no volume.')
        return bm
    except Exception:
        bm.free()
        raise


def bend_axis_dir(groups, turn=0.0):
    """(direction, centre) of the bend: the main axis of the outline points (PCA), turned by ``turn`` - pure."""
    pts = [q for outer, holes in groups for q in outer]
    n = max(1, len(pts))
    cx = sum(q[0] for q in pts) / n
    cy = sum(q[1] for q in pts) / n
    sxx = sum((q[0] - cx) ** 2 for q in pts)
    syy = sum((q[1] - cy) ** 2 for q in pts)
    sxy = sum((q[0] - cx) * (q[1] - cy) for q in pts)
    a = 0.5 * math.atan2(2.0 * sxy, sxx - syy) + turn
    return (math.cos(a), math.sin(a)), (cx, cy)


def bend_coords(u, w, z, half, up, side, style='SMOOTH', hinge_z=0.0, z_range=(0.0, 0.0), w_range=(0.0, 0.0),
                round_=0.0, round_in=0.0):
    """A point (along, across, up) of a shape ``half`` long each way from the bend spot, bent by ``up`` (both
    ends rise for +) and ``side`` (both ends go to +across for +) radians in total - pure.
    SMOOTH: an even arc over the length.  ANGLE: a sharp fold at u = 0 (height ``hinge_z``), both sides stay
    straight and meet on a mitred joint (no gap, no overlap); ``round_`` / ``round_in`` (x thickness) round the
    outer tip / the inside of the fold (``z_range`` / ``w_range`` = the shape's extent across the fold)."""
    if style == 'ANGLE':
        if abs(side) > 1e-6:
            th = w_range[1] - w_range[0]
            u, w = fold_round(u, w, 0.0, side / 2.0, w_range, round_ * th, round_in * th)
        if abs(up) > 1e-6:
            th = z_range[1] - z_range[0]
            u, z = fold_round(u, z, hinge_z, up / 2.0, z_range, round_ * th, round_in * th)
        return u, w, z
    if abs(side) > 1e-6 and half > 1e-12:
        r = 2.0 * half / side
        t = u / r
        u, w = (r - w) * math.sin(t), r - (r - w) * math.cos(t)
    if abs(up) > 1e-6 and half > 1e-12:
        r = 2.0 * half / up
        t = u / r
        u, z = (r - z) * math.sin(t), r - (r - z) * math.cos(t)
    return u, w, z


def _fold(s, h, h0, a):
    """Fold the (s, h) plane at s = 0 / h = h0: s > 0 turns up by ``a``, s < 0 by ``a`` the other way (mitred)."""
    if s < 0:
        s2, h2 = _fold(-s, h, h0, a)
        return -s2, h2
    d = h - h0
    x = s + d * math.tan(a)
    return x * math.cos(a) - d * math.sin(a), h0 + x * math.sin(a) + d * math.cos(a)


def fold_tangent(rho, a):
    """How far along the outer face the corner round reaches (each side of the fold)."""
    return rho * math.tan(min(abs(a), math.radians(80)))


def fold_round(s, h, h0, a, h_range, rho, rho_in=0.0):
    """``_fold`` with the corners of the fold rounded: radius ``rho`` on the outer face (away from the bend: the
    low side ``h_range[0]`` when ``a`` > 0) and ``rho_in`` on the inner face; points fade from round on a face to
    sharp that radius inside it - pure."""
    if a < 0:
        x, y = fold_round(s, -h, -h0, -a, (-h_range[1], -h_range[0]), rho, rho_in)
        return x, -y
    if s < 0:
        x, y = fold_round(-s, h, h0, a, h_range, rho, rho_in)
        return -x, y
    x, y = _fold(s, h, h0, a)
    ox = oy = 0.0
    for face, r, depth in ((h_range[0], rho, h - h_range[0]), (h_range[1], rho_in, h_range[1] - h)):
        t = fold_tangent(r, a)
        if r <= 1e-9 or s >= t:
            continue
        weight = max(0.0, min(1.0, 1.0 - depth / r))
        if weight <= 0.0:
            continue
        dx, dy = _round_offset(s, face, h0, a, r, t)
        ox += dx * weight
        oy += dy * weight
    return x + ox, y + oy


def _round_offset(s, face, h0, a, rho, t):
    """How far a point ``s`` from the fold on a face moves to sit on that face's corner round (radius ``rho``,
    tangent ``t`` each side).  Same circle for the outer (convex) and the inner (hollow) corner: its centre lies
    toward the inside of the bend."""
    kx, ky = _fold(0.0, face, h0, a)                     # the sharp corner on that face
    ca, sa = math.cos(a), math.sin(a)
    lx, ly = kx + ca * s, ky + sa * s                    # where the point sits on the sharp face
    cx, cy = kx + ca * t - sa * rho, ky + sa * t + ca * rho      # centre of the round
    th = a * (t - s) / t
    vx, vy = sa * rho, -ca * rho                         # centre -> tangent point, turned toward the corner
    ax = cx + vx * math.cos(th) + vy * math.sin(th)
    ay = cy - vx * math.sin(th) + vy * math.cos(th)
    return ax - lx, ay - ly


def _bend(bm, groups, p):
    """0.24.20 Bend Up / Down and Bend Sideways along the main axis of the outline (live Base Mesh)."""
    up, side = getattr(p, 'bend_up', 0.0), getattr(p, 'bend_side', 0.0)
    if abs(up) < 1e-6 and abs(side) < 1e-6:
        return
    (dx, dy), (cx, cy) = bend_axis_dir(groups, getattr(p, 'bend_axis', 0.0))
    us = [(v.co.x - cx) * dx + (v.co.y - cy) * dy for v in bm.verts]
    lo, hi = min(us), max(us)
    half = (hi - lo) / 2.0
    if half <= 1e-9:
        return
    mid = (lo + hi) / 2.0 + getattr(p, 'bend_pos', 0.0) * half      # the bend spot
    style = getattr(p, 'bend_style', 'SMOOTH')
    zs = [v.co.z for v in bm.verts]
    hinge_z = (min(zs) + max(zs)) / 2.0
    ws = [-(v.co.x - cx) * dy + (v.co.y - cy) * dx for v in bm.verts]
    z_range, w_range = (min(zs), max(zs)), (min(ws), max(ws))
    round_ = getattr(p, 'bend_round', 0.0)
    round_in = getattr(p, 'bend_round_in', 0.0)
    if style == 'ANGLE':
        cuts = [mid]                                     # an edge loop right on the fold
        reach = 0.0                                      # + rows across the rounded corners
        for ang, rng in ((up, z_range), (side, w_range)):
            if abs(ang) > 1e-6 and max(round_, round_in) > 0:
                reach = max(reach, fold_tangent(max(round_, round_in) * (rng[1] - rng[0]), ang / 2.0))
        cuts += [mid + sgn * reach * k / 6 for k in range(1, 7) for sgn in (-1, 1) if reach > 1e-9]
    elif p.profile not in PUFF_BUILT and p.profile != 'DOME':
        nb = ts.res_n(24, 6)
        cuts = [lo + (hi - lo) * k / nb for k in range(1, nb)]   # flat caps are single faces: slice them to curve
    else:
        cuts = []
    for u in cuts:
        if lo < u < hi:
            bmesh.ops.bisect_plane(bm, geom=bm.verts[:] + bm.edges[:] + bm.faces[:], dist=1e-7,
                                   plane_co=(cx + dx * u, cy + dy * u, 0.0), plane_no=(dx, dy, 0.0))
    for v in bm.verts:
        x, y, z = v.co
        u = (x - cx) * dx + (y - cy) * dy - mid
        w = -(x - cx) * dy + (y - cy) * dx
        if style == 'ANGLE' and abs(u) < 1e-6:
            u = 0.0
        u, w, z = bend_coords(u, w, z, half, up, side, style, hinge_z, z_range, w_range, round_, round_in)
        u += mid
        v.co = (cx + u * dx - w * dy, cy + u * dy + w * dx, z)


def _groups_from_json(text):
    data = json.loads(text)
    return [([tuple(q) for q in g['outer']], [[tuple(q) for q in h] for h in g['holes']])
            for g in data['groups']]


def _made_res(text):
    """0.24.95 the Resolution the stored outline was drawn at (parts from before: 100 %)."""
    try:
        return float(json.loads(text).get('res', 1.0)) or 1.0
    except (ValueError, TypeError, AttributeError):
        return 1.0




def _depth_at(points, u):
    if not points:
        return 0.0
    if u <= points[0][0]: return points[0][1]
    for a, b in zip(points, points[1:]):
        if u <= b[0]:
            t = (u-a[0])/max(b[0]-a[0],1e-9)
            return a[1]*(1.0-t)+b[1]*t
    return points[-1][1]


def _depth_profile_mesh(me, data):
    """Translate each cross-section along local Z without changing front silhouette.
    The guide is measured in the original mesh's local plane. No topology change.
    """
    try:
        axis = int(data['axis'])
        points = sorted([(float(u),float(z)) for u,z in data['points']], key=lambda q:q[0])
        if len(points) < 2 or axis not in (0,1): return
    except (TypeError,ValueError,KeyError,IndexError):
        return
    # Clean out overlapping control points for a single-valued depth function.
    spaced = [points[0]]
    for pt in points[1:]:
        if pt[0] - spaced[-1][0] > 1e-6:
            spaced.append(pt)
        else:
            spaced[-1]=pt
    if len(spaced)<2: return
    # 0.24.107 relative: the guide's shape bends the part, its height does not move it (a guide drawn above the
    # part lifted the whole mesh by that height) - measured from the guide's mean height along its length.
    span = spaced[-1][0] - spaced[0][0]
    if span > 1e-9:
        base = sum((b[0] - a[0]) * (a[1] + b[1]) * 0.5 for a, b in zip(spaced, spaced[1:])) / span
    else:
        base = sum(q[1] for q in spaced) / len(spaced)
    for v in me.vertices:
        v.co.z += _depth_at(spaced, v.co[axis]) - base


class MCH_OT_depth_side_guide(bpy.types.Operator):
    bl_idname = 'mch.depth_side_guide'
    bl_label = 'Draw Side Depth Guide'
    bl_description = 'From the side of an active LIVE Base Mesh, draw a freehand depth profile across its face'
    bl_options = {'REGISTER','UNDO','BLOCKING'}

    @classmethod
    def poll(cls, context):
        ob=context.active_object
        return context.mode == 'OBJECT' and context.area is not None and context.area.type == 'VIEW_3D' \
            and ob is not None and ob.type == 'MESH' and getattr(ob.mch_base,'live',False) \
            and bool(ob.mch_base.outline)

    def invoke(self, context, event):
        ob=context.active_object
        self.target_name=ob.name
        view=context.space_data.region_3d
        direction=(view.view_rotation @ Vector((0,0,-1))).normalized()
        mw=ob.matrix_world.to_3x3()
        ax=(mw @ Vector((1,0,0))).normalized()
        ay=(mw @ Vector((0,1,0))).normalized()
        az=(mw @ Vector((0,0,1))).normalized()
        if abs(direction.dot(az)) > .6:
            self.report({'WARNING'},'Rotate to a SIDE view of the Base Mesh (not front view)')
            return {'CANCELLED'}
        # A side view is aligned roughly with one axis of the front drawing plane.
        # The other, visible axis indexes the cross-sections of the depth guide.
        self.axis = 1 if abs(direction.dot(ax))>=abs(direction.dot(ay)) else 0
        self.plane_normal = ax if self.axis==1 else ay
        if abs(direction.dot(self.plane_normal)) < .15:
            self.report({'WARNING'},'Choose a side view approximately along the mesh local X or Y axis')
            return {'CANCELLED'}
        self.pts=[]; self.state='WAIT'
        self.winregion=next((r for r in context.area.regions if r.type=='WINDOW'),None)
        if self.winregion is None: return {'CANCELLED'}
        self.handler=bpy.types.SpaceView3D.draw_handler_add(self._draw,(), 'WINDOW','POST_PIXEL')
        context.area.header_text_set('Depth Guide: drag side profile (visible axis vs depth)  |  Esc cancel')
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def _stop(self,context):
        if getattr(self,'handler',None) is not None:
            bpy.types.SpaceView3D.draw_handler_remove(self.handler,'WINDOW');self.handler=None
        if context.area and context.area.type=='VIEW_3D':
            context.area.header_text_set(None);context.area.tag_redraw()

    def _draw(self):
        if len(self.pts)<2: return
        import gpu
        from gpu_extras.batch import batch_for_shader
        sh=gpu.shader.from_builtin('UNIFORM_COLOR')
        sh.bind();sh.uniform_float('color',(0.15,0.84,1.0,0.95))
        gpu.state.blend_set('ALPHA')
        gpu.state.line_width_set(3.0)
        batch_for_shader(sh,'LINE_STRIP',{'pos':self.pts}).draw(sh)
        gpu.state.line_width_set(1.0);gpu.state.blend_set('NONE')

    def modal(self,context,event):
        if event.type in {'ESC','RIGHTMOUSE'} and event.value=='PRESS':
            self._stop(context);return {'CANCELLED'}
        xy=(event.mouse_x-self.winregion.x, event.mouse_y-self.winregion.y)
        if self.state=='WAIT' and event.type=='LEFTMOUSE' and event.value=='PRESS':
            if not (0<=xy[0]<self.winregion.width and 0<=xy[1]<self.winregion.height):
                return {'RUNNING_MODAL'}
            self.pts=[xy];self.state='DRAW'
            return {'RUNNING_MODAL'}
        if self.state=='DRAW' and event.type=='MOUSEMOVE':
            if math.dist(xy,self.pts[-1])>=3:
                self.pts.append(xy)
                context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        if self.state=='DRAW' and event.type=='LEFTMOUSE' and event.value=='RELEASE':
            self._stop(context)
            if len(self.pts)<3 or math.dist(self.pts[0],self.pts[-1])<7:
                self.report({'WARNING'},'Draw a longer depth profile')
                return {'CANCELLED'}
            ob=bpy.data.objects.get(self.target_name)
            if ob is None or not ob.mch_base.live: return {'CANCELLED'}
            from bpy_extras.view3d_utils import region_2d_to_origin_3d,region_2d_to_vector_3d
            inv=ob.matrix_world.inverted_safe()
            pivot=ob.matrix_world.translation.copy()
            points=[]
            for q in self.pts:
                ro=region_2d_to_origin_3d(self.winregion,context.space_data.region_3d,q)
                rd=region_2d_to_vector_3d(self.winregion,context.space_data.region_3d,q)
                denom=rd.dot(self.plane_normal)
                if abs(denom)<1e-8: continue
                w=ro+rd*((pivot-ro).dot(self.plane_normal)/denom)
                local=inv @ w
                points.append((local[self.axis],local.z))
            if len(points)<2:
                self.report({'WARNING'},'Could not project depth guide onto side plane')
                return {'CANCELLED'}
            ob[DEPTH_KEY]=json.dumps({'axis':self.axis,'points':points})
            rebuild(ob)
            self.report({'INFO'},'Depth guide saved; edit live height/bevel as before. Draw again to replace guide.')
            return {'FINISHED'}
        return {'RUNNING_MODAL'}

    def cancel(self,context): self._stop(context)


class MCH_OT_depth_side_clear(bpy.types.Operator):
    bl_idname='mch.depth_side_clear'
    bl_label='Clear Side Depth Guide'
    bl_options={'REGISTER','UNDO'}
    @classmethod
    def poll(cls,context):
        ob=context.active_object
        return ob is not None and bool(ob.get(DEPTH_KEY)) and bool(getattr(ob.mch_base,'live',False))
    def execute(self,context):
        ob=context.active_object
        del ob[DEPTH_KEY]
        rebuild(ob)
        return {'FINISHED'}

# ----------------------------------------------------------------------------
# 0.24.103 Open-stroke section sweep (Circle / Square / saved Press Cut shape).
# Kept separate from build_bmesh: ordinary Base Mesh outlines remain unchanged.
# ----------------------------------------------------------------------------


def _section_loops(context, style):
    """Return a snapshot of the selected cross section in normalized XY units."""
    if style == 'CIRCLE':
        return [[(math.cos(i * math.tau / 32) * 0.5, math.sin(i * math.tau / 32) * 0.5)
                 for i in range(32)]], 'Circle'
    if style == 'SQUARE':
        return [[(-0.5, -0.5), (0.5, -0.5), (0.5, 0.5), (-0.5, 0.5)]], 'Square'
    if style != 'ALPHA':
        raise cg.CutError('Select Circle, Square or a saved Press Cut shape for a line sweep.')
    from . import cut_presets, press_cut
    # Honor the exact active Press Cut stamp, including an unsaved Shift-drawn shape.
    # This is a snapshot, so later selecting another stamp won't alter old meshes.
    press = context.scene.mch_press
    if getattr(press, 'drawn', False) and press_cut.DRAWN[0]:
        return [[(float(x), float(y)) for x, y in lp] for lp in press_cut.DRAWN[0]], 'Drawn Press Shape'
    stem = getattr(press, 'shape', 'NONE')
    if not stem or stem == 'NONE':
        raise cg.CutError('Select a Press Cut stamp before Alt + drawing.')
    loops = cut_presets.load_loops(stem)
    if not loops:
        raise cg.CutError('The selected Press Cut shape has no closed contour.')
    return [[(float(x), float(y)) for x, y in loop] for loop in loops], stem


def _resample_section_path(points, width, max_points=192):
    """Arc-length resampling: stable tangents and bounded vertex counts."""
    from bisect import bisect_right
    clean = []
    for q in points:
        p = tuple(float(c) for c in q)
        if not clean or math.dist(p, clean[-1]) > 1e-6:
            clean.append(p)
    if len(clean) < 2:
        raise cg.CutError('Draw a longer line to sweep the section.')
    cumulative = [0.0]
    for a, b in zip(clean, clean[1:]):
        cumulative.append(cumulative[-1] + math.dist(a, b))
    total = cumulative[-1]
    if total < 1e-5:
        raise cg.CutError('The line is too short for a swept cross section.')
    n = max(2, min(max_points, max(len(clean), int(math.ceil(total / max(width * 0.45, 0.002))) + 1)))
    sampled = []
    for i in range(n):
        d = total * i / (n-1)
        j = min(len(clean)-2, max(0, bisect_right(cumulative, d)-1))
        a, b = clean[j], clean[j+1]
        t = (d-cumulative[j]) / max(1e-12, cumulative[j+1]-cumulative[j])
        sampled.append(tuple(a[k] + t * (b[k] - a[k]) for k in range(len(a))))   # (0.24.110 2D or 3D points)
    return sampled


def sweep_frames(stations):
    """0.24.110 (U, V) per station of a 3D polyline: T the tangent (central difference), V the section's up - the
    plane normal (local z) at the start, carried along with the least twist (parallel transport: a bent bar does
    not spin) - and U = V x T across the line.  For a flat line this is exactly the old in-plane frame."""
    out = []
    n = len(stations)
    V = Vector((0.0, 0.0, 1.0))
    for i in range(n):
        a, b = (stations[0], stations[1]) if i == 0 else (stations[-2], stations[-1]) if i == n - 1 \
               else (stations[i - 1], stations[i + 1])
        T = Vector(b) - Vector(a)
        if T.length < 1e-8:
            raise cg.CutError('Overlapping drawing points; redraw the path.')
        T.normalize()
        Vn = V - T * V.dot(T)
        if Vn.length < 1e-6:                               # the line heads straight along the old up: pick any up
            Vn = Vector((1.0, 0.0, 0.0)) if abs(T.x) < 0.9 else Vector((0.0, 1.0, 0.0))
            Vn = Vn - T * Vn.dot(T)
        V = Vn.normalized()
        U = V.cross(T).normalized()
        out.append((U, V))
    return out


def _build_sweep_bmesh(data, p):
    """Watertight sections swept along a plane-local centreline; includes holes.

    Alpha shapes are a VECTOR outline, not brightness displacement. Each ring
    lies in the plane perpendicular to the path tangent, and remains editable.
    """
    # 0.24.110 (user: "여기 안 돼" - a continued line must be able to leave the first plane) the centreline is 3D
    # (``path3``, object local) when the line was continued out of its plane; a flat line keeps its 2D ``path``
    path = [tuple(float(c) for c in q) for q in (data.get('path3') or data['path'])]
    if path and len(path[0]) == 2:
        path = [(q[0], q[1], 0.0) for q in path]
    loops = [[(float(q[0]), float(q[1])) for q in lp] for lp in data['loops']]
    if not loops or sum(map(len, loops)) < 3:
        raise cg.CutError('The selected cross-section shape is empty.')
    total_points = sum(map(len, loops))
    if total_points > 1800:
        raise cg.CutError('Saved shape is too detailed (max 1800 outline points); simplify the contour first.')
    groups = cg.organize_loops(loops)
    if not groups:
        raise cg.CutError('Saved cross-section contains no closed area.')
    stations = _resample_section_path(path, p.section_width,
                                       max_points=min(192, max(12, 125000 // total_points)))
    frames = sweep_frames(stations)          # (U across, V up) per station: V starts as the plane's normal and is
    #                                          carried along the line with the least twist (a flat line: U in-plane, V = z)
    width, height = max(1e-5, p.section_width), max(1e-5, p.height)
    base_angle, twist, taper = p.section_rotation, p.section_twist, p.section_taper
    rest = bool(data.get('rest'))
    bottom = data.get('bottom')        # 0.24.109 a cutter: the section's lowest point at this local z (into the part)
    bm = bmesh.new()
    try:
        for outer, holes in groups:
            section_loops = [outer] + list(holes)
            flat = [q for lp in section_loops for q in lp]
            edges = []
            off = 0
            for lp in section_loops:
                edges += [(off+i, off+(i+1)%len(lp)) for i in range(len(lp))]
                off += len(lp)
            cap_faces = _triangulate(flat, len(flat), section_loops, edges)
            all_rings = []
            for i, (st_, (U, V)) in enumerate(zip(stations, frames)):
                P = Vector(st_)
                t = i / (len(stations)-1)
                scale = max(0.05, 1.0 - taper*(abs(2*t-1)**2))
                angle = base_angle + twist*t
                ca, sa = math.cos(angle), math.sin(angle)
                ring = []
                uv = [((u*ca-v*sa)*scale, (u*sa+v*ca)*scale) for u, v in flat]
                # 0.24.108 rest: the section's lowest point just under the surface (Press Cut draws the stamp
                # standing on the part; a centred section was half buried)
                dz = (-min(v for _u, v in uv) - 0.02) * height if rest else 0.0
                if bottom is not None:
                    dz = float(bottom) - p.offset - min(v for _u, v in uv) * height
                for u, v in uv:
                    ring.append(bm.verts.new(P + U * (u * width) + V * (p.offset + v * height + dz)))
                all_rings.append(ring)
            for a, b, c in cap_faces:
                # Profile +U points left across the path, +V points up.
                # A CCW cap faces forward; reverse the leading cap only.
                a, b, c = _orient_ccw((a,b,c), flat)
                bm.faces.new((all_rings[0][c], all_rings[0][b], all_rings[0][a]))
                bm.faces.new((all_rings[-1][a], all_rings[-1][b], all_rings[-1][c]))
            for ring0, ring1 in zip(all_rings, all_rings[1:]):
                for a, b in edges:
                    bm.faces.new((ring0[a], ring0[b], ring1[b], ring1[a]))
        if not bm.faces:
            raise cg.CutError('The Alpha sweep generated no faces.')
        bm.normal_update()
        return bm
    except Exception:
        bm.free()
        raise


def _area2(loop):
    return sum(a[0] * b[1] - b[0] * a[1] for a, b in zip(loop, loop[1:] + loop[:1]))


def _hull(points):
    """Convex hull (counter-clockwise) of 2D points, or None for fewer than 3 distinct points."""
    pts = sorted({(round(float(q[0]), 3), round(float(q[1]), 3)) for q in points})
    if len(pts) < 3:
        return None

    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    lower, upper = [], []
    for q in pts:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], q) <= 0:
            lower.pop()
        lower.append(q)
    for q in reversed(pts):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], q) <= 0:
            upper.pop()
        upper.append(q)
    hull = lower[:-1] + upper[:-1]
    return hull if len(hull) >= 3 else None


def sweep_frame(context, loops, projector, path):
    """The plane a drawn line is swept in - (outline groups, frame, the path in the frame's 2D) - for a screen
    ``path`` and its band ``loops``.  0.24.107 the frame comes from the path's hull (always a simple outline):
    the drawn band itself crosses itself on a tight or looping line and the sweep failed with "crosses itself"
    before it was built."""
    frame_loop = _hull(path) if path is not None else None
    if frame_loop is None or len(frame_loop) < 3 or abs(_area2(frame_loop)) < 4.0:
        frame_loop = loops[0] if loops else None
    if frame_loop is None:
        raise cg.CutError('Draw a longer line to sweep the section.')
    groups, frame, _screen, _embed = _local_groups(context, [frame_loop], projector)
    return groups, frame, plane_path(frame, projector, path)


def plane_path(frame, projector, path):
    """Screen points ``path`` projected onto the plane of ``frame`` (its local XY), as 2D points."""
    inv = frame.inverted_safe()
    origin, normal = frame.translation, Vector((frame[0][2], frame[1][2], frame[2][2]))
    out = []
    for q in path:
        l = inv @ _plane_point(projector, q, origin, normal)
        out.append((float(l.x), float(l.y)))
    return out


def envelope_section(loops, top, columns=96):
    """0.24.109 (user: "컷도 당연히 스탬프 단면으로 잘려야지") The section a stamp leaves when it is pressed in and
    dragged along: the stamp's lower outline, and straight walls up from its widest points to ``top`` (what the
    stamp's silhouette sweeps through on its way down; a hole in the stamp is passed through, so it is filled).
    ``loops`` are the stamp's loops (normalized, already turned); one counter-clockwise loop comes back."""
    pts = [q for lp in loops for q in lp]
    if len(pts) < 3:
        raise cg.CutError('The stamp has no outline')
    xs = sorted({round(float(q[0]), 6) for q in pts})
    lo, hi = xs[0], xs[-1]
    if hi - lo < 1e-9:
        raise cg.CutError('The stamp is too thin to sweep')
    sample = set(xs)
    for i in range(columns + 1):
        sample.add(round(lo + (hi - lo) * i / columns, 6))
    edges = []
    for lp in loops:
        for a, b in zip(lp, lp[1:] + lp[:1]):
            edges.append((float(a[0]), float(a[1]), float(b[0]), float(b[1])))
    chain = []
    for x in sorted(sample):
        best = None
        for ax, ay, bx, by in edges:
            if (ax <= x <= bx) or (bx <= x <= ax):
                if abs(bx - ax) < 1e-12:
                    y = min(ay, by)
                else:
                    y = ay + (by - ay) * (x - ax) / (bx - ax)
                best = y if best is None else min(best, y)
        if best is not None:
            chain.append((x, best))
    if len(chain) < 2:
        raise cg.CutError('The stamp has no outline')
    top = max(float(top), max(float(q[1]) for q in pts) + 1e-3)
    out = chain + [(chain[-1][0], top), (chain[0][0], top)]
    # drop points on a straight run (the columns across a flat bottom)
    kept = [out[0]]
    for a, b, c in zip(out, out[1:], out[2:] + out[:1]):
        if abs((b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0])) > 1e-9 * max(1.0, abs(hi - lo)):
            kept.append(b)
    kept = [q for i, q in enumerate(kept) if i == 0 or math.dist(q, kept[i - 1]) > 1e-9]
    if _area2(kept) < 0:
        kept.reverse()
    return kept


class _SweepCutterSettings:
    """Settings view for a swept cutter: the section's size and turn, nothing else of the Base Mesh."""

    def __init__(self, width, height, rotation=0.0):
        self.section_width = max(1e-5, float(width))
        self.height = max(1e-5, float(height))
        self.offset = 0.0
        self.section_rotation = float(rotation)
        self.section_twist = 0.0
        self.section_taper = 0.0


def sweep_cutter_mesh(frame, local_path, section, width, height, bottom, rotation=0.0):
    """0.24.109 The swept cutter as a mesh: ``section`` (normalized loops) swept along ``local_path`` in the plane of
    ``frame``, its lowest point at local z ``bottom`` (negative = into the part the plane sits on)."""
    data = {'path': [[float(q[0]), float(q[1])] for q in local_path],
            'loops': [[list(q) for q in lp] for lp in section], 'bottom': float(bottom)}
    if any(len(q) > 2 and abs(float(q[2])) > 1e-9 for q in local_path):     # 0.24.110 a groove that leaves its plane
        data['path3'] = [list(_xyz(q)) for q in local_path]
    bm = _build_sweep_bmesh(data, _SweepCutterSettings(width, height, rotation))
    try:
        me = bpy.data.meshes.new('MCH_LineCutter')
        bm.to_mesh(me)
        from . import edge_memory as _em
        _em.drop_profile_flags(me)
    finally:
        bm.free()
    return me


def sweep_cut(context, frame, local_path, section, width, height, bottom, targets, mode='CUT', rotation=0.0):
    """0.24.109 Press Cut Alt + drag: the stamp's section swept along the drawn line and taken out of ``targets``
    (``mode`` CUT), or the swept piece kept as its own part (SPLIT).  Returns the report line."""
    from . import cut_engine as ce
    targets = [t for t in targets if t is not None and t.type == 'MESH']
    if not targets:
        raise cg.CutError('Line Cut: no mesh in the line / selection')
    me = sweep_cutter_mesh(frame, local_path, section, width, height, bottom, rotation)
    cutter = cg.link_temp_object(context, me)
    cutter.matrix_world = frame
    cut = context.scene.mch_cut
    done, failed, temp, pieces = [], [], [], []
    try:
        results = []
        for t in targets:
            try:
                cg.check_target(t)
                if mode == 'SPLIT':
                    inner, _s = cg.boolean_result(context, t, cutter, 'INTERSECT', cut.solver, cut.hole_tolerant)
                    temp.append(inner)
                res, _solver = cg.boolean_result(context, t, cutter, 'DIFFERENCE', cut.solver, cut.hole_tolerant)
                temp.append(res)
                results.append((t, res))
                if mode == 'SPLIT':
                    pieces.append((t, inner))
            except (cg.CutError, RuntimeError) as ex:
                if len(targets) == 1:
                    raise
                failed.append(f'{t.name} ({str(ex).splitlines()[0][:60]})')
        if not results:
            raise cg.CutError('The line does not reach any target; nothing was changed.')
        for t, res in results:
            cg.commit_mesh(t, res, cut.shared_mesh)
            done.append(t.name)
        for t, inner in pieces:
            if len(inner.polygons):
                ce._make_piece(t, inner)
                temp.remove(inner)
    finally:
        for m in temp:
            if m.users == 0:
                bpy.data.meshes.remove(m)
        cg.remove_object_and_mesh(cutter)
    msg = f'{"Line Split" if mode == "SPLIT" else "Line Cut"} ({len(local_path)} points, the stamp as its section) on ' \
          + ', '.join(done)
    if failed:
        msg += ' | FAILED, unchanged: ' + '; '.join(failed)
    return msg


def _create_section_sweep(context, loops, projector, path, defaults, attach=None):
    """One shared implementation for Base Mesh Line and Unified Press Alt+Draw."""
    section, name = _section_loops(context, defaults.profile_sweep)
    groups, frame, local_path = sweep_frame(context, loops, projector, path)
    # Snapshot vector loops: rebuilding still works if the saved Press Cut shape is renamed/deleted.
    sweep = {'path': local_path, 'loops': section, 'section_name': name,
             'rest': bool(getattr(defaults, 'section_rest', False))}
    msg = _create_live_base(context, groups, frame, defaults, embed=0.0, sweep_data=sweep)
    ob = getattr(context, 'active_object', None) if attach is not None else None
    if ob is not None and getattr(ob, 'mch_base', None) is not None and ob.mch_base.live:
        set_attach(ob, frame, projector, *attach)          # 0.24.107 Attach Ends for a swept line too
        msg += f' | Attach Ends: {sum(1 for h in attach[1:] if h is not None)} of 2 on a mesh'
    return msg + f' | Sweep section: {name}'


def sweep_ends(ob):
    """0.24.109 The two ends (world) of a live swept line - [start, end] - or None when ``ob`` is not one."""
    if ob is None or not ob.get(SWEEP_KEY) or getattr(ob, 'mch_base', None) is None or not ob.mch_base.live:
        return None
    try:
        data = json.loads(ob[SWEEP_KEY])
        path = data.get('path3') or data['path']
    except (TypeError, ValueError, KeyError):
        return None
    if len(path) < 2:
        return None
    mw = ob.matrix_world
    return [mw @ Vector(_xyz(q)) for q in (path[0], path[-1])]


def _xyz(q):
    return (float(q[0]), float(q[1]), float(q[2]) if len(q) > 2 else 0.0)


CONTINUE_SAME_PLANE_DEG = 20.0    # the view turned less than this since the first stroke: the line stays in its plane


def continue_plane_path(frame, projector, pts, end_local):
    """0.24.110 Where a continued stroke goes: screen points ``pts`` projected onto the plane through the old end point
    that faces the CURRENT view - the user turned the view to head off in a new direction (their "여기 안 돼") - or,
    when the view turned less than ``CONTINUE_SAME_PLANE_DEG`` from the line's own plane, onto that plane (a small
    orbit to see better keeps a flat line flat).  Returns (3D points in the frame's local space, degrees the view is
    turned from the first plane, True when the piece leaves the plane)."""
    inv = frame.inverted_safe()
    n_first = Vector((frame[0][2], frame[1][2], frame[2][2])).normalized()
    n_view = -Vector(projector.view_dir).normalized()
    turned = math.degrees(math.acos(max(-1.0, min(1.0, abs(n_view.dot(n_first))))))
    end_world = frame @ Vector(_xyz(end_local))
    if turned < CONTINUE_SAME_PLANE_DEG:
        normal, leaves = n_first, False
    else:
        normal, leaves = n_view, True
    out = []
    for q in pts:
        l = inv @ _plane_point(projector, q, end_world, normal)
        out.append((float(l.x), float(l.y), float(l.z) if leaves else 0.0))
    return out, turned, leaves


def join_path(old, new, fade, tail=0.0):
    """0.24.109 ``new`` (plane 2D) joined onto the end of ``old``: its first point is moved onto old's last point and
    that shift fades out over the first ``fade`` of its length, so the drawn shape is kept.  Returns (the last
    ``tail`` length of ``old`` ending at its end point, the joined new points without the coincident first one)."""
    if len(new) < 2 or not old:
        raise cg.CutError('Draw a longer line')
    joint = old[-1]
    shift = [joint[k] - new[0][k] for k in range(len(joint))]
    fade = max(float(fade), 1e-6)
    run, out = 0.0, []
    for k, q in enumerate(new):
        if k:
            run += math.dist(new[k - 1], q)
        f = max(0.0, 1.0 - run / fade)
        out.append(tuple(q[c] + shift[c] * f for c in range(len(joint))))
    added = [q for q in out[1:] if math.dist(q, joint) > 1e-6]
    if not added:
        raise cg.CutError('Draw a longer line')
    keep = [joint]
    run = 0.0
    for a, b in zip(old[-2::-1], old[::-1]):                # back from the end until ``tail`` is covered
        run += math.dist(a, b)
        keep.insert(0, a)
        if run >= tail:
            break
    return keep, added


def extend_sweep(ob, projector, pts, at_end=True, end_hit=None):
    """0.24.109 (user: "한번 긋고 뷰포트 돌려서 처음 그었던 선 끝난 부분에 이어서 그릴 수 있게") The screen stroke ``pts``
    continued onto the live swept line ``ob``.  The view may have turned since the first stroke: the new points are
    projected onto the FIRST stroke's plane (the object's own frame) and joined to the path's end (or its start when
    ``at_end`` is False) - one object, the section as it was, pointing the way the first stroke did.  The stroke's
    first point lands exactly on the old end; the small gap the pointer left is faded out over the first two
    section widths.  Returns (points added, degrees the view is turned from the first stroke, left the plane)."""
    data = json.loads(ob[SWEEP_KEY])
    frame = ob.matrix_world
    inv = frame.inverted_safe()
    path = [_xyz(q) for q in (data.get('path3') or data['path'])]
    if not at_end:                                        # (the stroke starts at the line's start: it is put in front)
        path.reverse()
    if len(pts) < 2:
        raise cg.CutError('Draw a longer line')
    # 0.24.110 the new piece lies in the plane of the CURRENT view through the old end (the line can leave its first
    # plane); a view turned less than 20 deg keeps the first plane
    local, turned, leaves = continue_plane_path(frame, projector, pts, path[-1])
    _tail, new = join_path(path, local, fade=2.0 * float(ob.mch_base.section_width))
    path = path + new
    if not at_end:
        path.reverse()
    flat = all(abs(q[2]) < 1e-6 for q in path)
    probe = dict(data)
    probe['path'] = [(q[0], q[1]) for q in path]
    if flat:
        probe.pop('path3', None)
    else:
        probe['path3'] = path
    _build_sweep_bmesh(probe, ob.mch_base).free()        # validate first: never lose the line that was there
    data['path'] = probe['path']
    if flat:
        data.pop('path3', None)
    else:
        data['path3'] = path
    ob[SWEEP_KEY] = json.dumps(data, separators=(',', ':'))
    hull = _hull(data['path'])                            # the stored outline follows the whole line (its plane view)
    if hull is not None and abs(_area2(hull)) >= 4.0 * 1e-6:
        ob.mch_base.outline = json.dumps({'groups': [{'outer': hull, 'holes': []}], 'res': ts.res_scale()})
    if ob.get(ATTACH_KEY):                                # Attach Ends: the bend runs along the whole line now
        if not flat:                                      # (... but not along a line that left its plane)
            del ob[ATTACH_KEY]
        else:
            try:
                att = json.loads(ob[ATTACH_KEY])
                att['path'] = [[q[0], q[1]] for q in data['path']]
                if end_hit is not None:
                    att['z1' if at_end else 'z0'] = (inv @ Vector(end_hit)).z
                ob[ATTACH_KEY] = json.dumps(att)
            except (TypeError, ValueError, KeyError):
                pass
    rebuild(ob)
    return len(new), turned, leaves


class MCH_OT_base_section_use_alpha(bpy.types.Operator):
    """Apply the currently selected saved Press Cut shape to an existing LIVE swept Base Mesh."""
    bl_idname = 'mch.base_section_use_alpha'
    bl_label = 'Use Selected Press Cut Shape in Live Line'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        ob = active_live_base(context)
        return ob is not None and SWEEP_KEY in ob

    def execute(self, context):
        ob = active_live_base(context)
        try:
            loops, name = _section_loops(context, 'ALPHA')
            data = json.loads(ob[SWEEP_KEY])
            data['loops'], data['section_name'] = loops, name
            # Update after validation, never destroy the prior sweep on error.
            _build_sweep_bmesh(data, ob.mch_base).free()
            ob[SWEEP_KEY] = json.dumps(data)
            ob.mch_base.profile_sweep = 'ALPHA'
            rebuild(ob)
            self.report({'INFO'}, 'Live section updated from selected Press Cut shape')
            return {'FINISHED'}
        except (cg.CutError, ValueError, KeyError) as ex:
            self.report({'WARNING'}, str(ex))
            return {'CANCELLED'}


def rebuild(ob):
    """Regenerate a live Base Mesh object from its stored outline + settings.  At another Resolution than the
    outline was drawn at, its curved runs are resampled to match (0.24.95: a part made at 100 %, rebuilt at 200 %
    has the round outline of a new 200 % one)."""
    groups = _groups_from_json(ob.mch_base.outline)
    f = ts.res_scale() / _made_res(ob.mch_base.outline)
    if abs(f - 1.0) > 1e-6:
        groups = [(cg.reres_loop(o, f), [cg.reres_loop(h, f) for h in hs]) for o, hs in groups]
    sweep = json.loads(ob[SWEEP_KEY]) if ob.get(SWEEP_KEY) and ob.mch_base.profile_sweep != 'OFF' else None
    if sweep is not None and ob.mch_base.profile_sweep in {'CIRCLE', 'SQUARE'}:
        # Live Circle/Square selectors must use their current section, not the
        # previous Alpha snapshot. Saved Press shapes intentionally stay snapshotted
        # until 'Use Selected Press Shape' is pressed, preserving reproducibility.
        sweep['loops'], _label = _section_loops(None, ob.mch_base.profile_sweep)
    bm = (_build_sweep_bmesh(sweep, ob.mch_base) if sweep is not None
          else build_bmesh(groups, ob.mch_base))
    try:
        bm.to_mesh(ob.data)
        from . import edge_memory as _em; _em.mark_generated(ob.data)   # 0.24.95 Edge Memory: the part's own lines
    finally:
        bm.free()
    if ob.get(ATTACH_KEY):
        try:
            attach_bend(ob.data, json.loads(ob[ATTACH_KEY]), ob.mch_base.attach_curve)
        except (TypeError, ValueError, KeyError):
            pass
    if ob.get(DEPTH_KEY):
        try:
            _depth_profile_mesh(ob.data, json.loads(ob[DEPTH_KEY]))
        except (ValueError,TypeError,KeyError): pass
    ob.data.update()
    ob['mch_base_notes'] = '; '.join(LAST_NOTES)      # 0.23.17 shown in the LIVE panel (e.g. width limited)


def path_param(path, xy):
    """0..1 along the 2D polyline ``path`` of the point nearest ``xy`` (by length)."""
    best, t_best, run = None, 0.0, 0.0
    lens = [math.dist(path[i], path[i + 1]) for i in range(len(path) - 1)]
    total = sum(lens) or 1.0
    for i, ln in enumerate(lens):
        ax, ay = path[i]
        bx, by = path[i + 1]
        dx, dy = bx - ax, by - ay
        u = 0.0 if ln < 1e-12 else max(0.0, min(1.0, ((xy[0] - ax) * dx + (xy[1] - ay) * dy) / (ln * ln)))
        d = math.hypot(xy[0] - (ax + u * dx), xy[1] - (ay + u * dy))
        if best is None or d < best:
            best, t_best = d, (run + u * ln) / total
        run += ln
    return t_best


def ease(t, curve):
    """How far from the start depth to the end depth at ``t``: As Drawn = evenly, Smooth = eased in and out."""
    t = max(0.0, min(1.0, t))
    return t if curve == 'DRAWN' else t * t * (3.0 - 2.0 * t)


def densify_along(me, path, step=None):
    """0.24.58 The flat solid's top / bottom are a few long faces; bent in 3D they twist and shade broken.  Cut the
    mesh across the line at even steps (planes square to the 2D ``path``) and split the leftover n-gons into
    triangles, so every face is small enough to follow the bend."""
    lens = [math.dist(path[i], path[i + 1]) for i in range(len(path) - 1)]
    total = sum(lens)
    if total < 1e-9:
        return
    n = max(8, min(ts.res_n(96, 8), int(total / step) if step else ts.res_n(48, 8)))
    bm = bmesh.new()
    bm.from_mesh(me)
    i, run = 0, 0.0
    for k in range(1, n):
        at = total * k / n
        while i < len(lens) - 1 and run + lens[i] < at:
            run += lens[i]
            i += 1
        ln = lens[i]
        if ln < 1e-12:
            continue
        u = (at - run) / ln
        (ax, ay), (bx, by) = path[i], path[i + 1]
        geom = bm.verts[:] + bm.edges[:] + bm.faces[:]
        bmesh.ops.bisect_plane(bm, geom=geom, dist=1e-6, plane_co=(ax + u * (bx - ax), ay + u * (by - ay), 0.0),
                               plane_no=((bx - ax) / ln, (by - ay) / ln, 0.0))
    big = [f for f in bm.faces if len(f.verts) > 4]
    if big:
        bmesh.ops.triangulate(bm, faces=big, quad_method='BEAUTY', ngon_method='BEAUTY')
    bm.to_mesh(me)
    bm.free()


def attach_bend(me, data, curve='SMOOTH'):
    """0.24.57 Line Attach Ends: the flat solid (in its plane) bent so its start sits at depth ``z0`` and its end at
    ``z1`` (object space; along the view ray when ``eye`` is set, so it looks the same from where it was drawn)."""
    path = [tuple(q) for q in data['path']]
    if len(path) < 2:
        return
    z0, z1 = float(data.get('z0', 0.0)), float(data.get('z1', 0.0))
    eye = Vector(data['eye']) if data.get('eye') is not None else None
    if abs(z1 - z0) > 1e-9:
        densify_along(me, path)
    for v in me.vertices:
        co = v.co
        dz = z0 + (z1 - z0) * ease(path_param(path, (co.x, co.y)), curve)
        if abs(dz) < 1e-12:
            continue
        if eye is not None:
            d = co - eye
            if abs(d.z) > 1e-9:
                v.co = co + d * (dz / d.z)
                continue
        v.co = Vector((co.x, co.y, co.z + dz))


# -----------------------------------------------------------------------------
# Screen outline -> plane
# -----------------------------------------------------------------------------


def _plane_point(projector, xy, plane_co, normal):
    o, d = projector.ray(xy)
    return cg._plane_hit(o, d, plane_co, normal)[0]


def anchor_hit(context, projector, outer):
    """0.24.36 Where the new solid sits: the surface under the outline centre, or - when the centre is over empty
    space (a line drawn half off the mesh) - the front-most surface under the outline / line.  Returns
    (screen point, (location, normal, object)) or (centre, None) when nothing is under it at all."""
    c = (sum(q[0] for q in outer) / len(outer), sum(q[1] for q in outer) / len(outer))
    dg = context.evaluated_depsgraph_get()
    vd = Vector(projector.view_dir)
    best = None
    for k, q in enumerate([c] + list(_outline_samples(outer)) + list(outer[::max(1, len(outer) // 48)])):
        o, d = projector.ray(q)
        hit, loc, nrm, _i, ob, _m = target_rules.scene_ray(context, dg, o, d)
        if not hit or ob is None or ob.type != 'MESH':
            continue
        if k == 0:
            return c, (Vector(loc), Vector(nrm), ob)
        depth = (Vector(loc) - Vector(o)).dot(vd)
        if best is None or depth < best[0]:
            best = (depth, q, (Vector(loc), Vector(nrm), ob))
    return (best[1], best[2]) if best else (c, None)


def plane_frame(context, projector, groups):
    """(origin, X, Y, N) for the outline plane; N points toward the viewer."""
    vd = projector.view_dir
    outer = groups[0][0]
    c = (sum(q[0] for q in outer) / len(outer), sum(q[1] for q in outer) / len(outer))
    origin = None
    try:
        _q, found = anchor_hit(context, projector, outer)
        if found is not None:
            origin = found[0]
    except (AttributeError, RuntimeError, TypeError):
        origin = None
    if origin is None:
        origin = _plane_point(projector, c, context.scene.cursor.location.copy(), vd)
    else:
        origin = _plane_point(projector, c, origin, vd)
    n = -vd
    px = _plane_point(projector, (c[0] + 100.0, c[1]), origin, vd)
    x = px - origin
    x = (x - n * x.dot(n))
    if x.length < 1e-12:
        raise cg.CutError('Cannot place the outline plane in this view.')
    x.normalize()
    y = n.cross(x).normalized()
    return origin, x, y, n


def _outline_samples(outer, count=24):
    step = max(1, len(outer) // count)
    return [outer[i] for i in range(0, len(outer), step)]


def surface_frame(context, projector, screen_groups, height=0.2):
    """0.14.2+ Stick to Surface: (origin, X, Y, N, embed) for an outline drawn
    over a mesh, or None (nothing under it / seen edge-on).

    N = the average surface normal under the outline (turned toward the
    viewer), origin = the surface point under the outline centre, embed = how
    far the bottom must reach below that plane so a curved surface leaves no
    gap (at least 2 % of the height, so the bottom never z-fights with a flat
    surface)."""
    outer = screen_groups[0][0]
    try:
        dg = context.evaluated_depsgraph_get()
        c, found = anchor_hit(context, projector, outer)      # 0.24.36 a line half off the mesh: its front part
    except (AttributeError, RuntimeError, TypeError):
        return None
    if found is None:
        return None
    loc, nrm, ob = found
    o, d = projector.ray(c)
    d = Vector(d)
    name = ob.name
    hits = [(Vector(loc), Vector(nrm))]
    for q in _outline_samples(outer):
        o2, d2 = projector.ray(q)
        h2, l2, n2, _i2, ob2, _m2 = target_rules.scene_ray(context, dg, o2, d2)
        if h2 and ob2 is not None and ob2.name == name:
            hits.append((Vector(l2), Vector(n2)))
    n = Vector((0.0, 0.0, 0.0))
    for _p, nv in hits:
        n += nv if nv.dot(-d) >= 0 else -nv
    if n.length < 1e-9:
        return None
    n.normalize()
    if abs(n.dot(projector.view_dir)) < 0.2:
        return None                      # seen almost edge-on: drawing onto it would smear
    origin = Vector(loc)
    below = min((pt - origin).dot(n) for pt, _nv in hits)
    embed = max(0.0, -below) + max(height * 0.02, 1e-5)
    px = _plane_point(projector, (c[0] + 100.0, c[1]), origin, n)
    x = px - origin
    x = x - n * x.dot(n)
    if x.length < 1e-12:
        return None
    x.normalize()
    y = n.cross(x).normalized()
    return origin, x, y, n, embed


SESSION_KEY = 'mch_base_session'     # Scene ID prop: live Base Meshes made since the tool was entered


def frame_for(context, projector, screen_groups, allow_invert=True):
    """(origin, X, Y, N, embed): on the surface under the outline when Stick
    to Surface is on and there is one, else facing the view (embed 0)."""
    p = scene_defaults(context)
    sf = surface_frame(context, projector, screen_groups, p.height) if getattr(p, 'surface_align', False) else None
    if sf is None:
        sf = (*plane_frame(context, projector, screen_groups), 0.0)
    if allow_invert and getattr(p, 'invert_height', False):   # 0.24.37 Invert: the height grows back from the drawn plane
        origin, x, y, n, embed = sf
        sf = (origin, x, -y, -n, max(p.height * 0.02, 1e-5) if embed > 0 else 0.0)
    return sf


def _local_groups(context, loops, projector, allow_invert=True):
    screen_groups = cg.prepare_loops(loops)
    origin, x, y, n, embed = frame_for(context, projector, screen_groups, allow_invert)

    def to_local(q):
        w = _plane_point(projector, q, origin, n)
        v = w - origin
        return (v.dot(x), v.dot(y))
    groups = [([to_local(q) for q in outer], [[to_local(q) for q in h] for h in holes])
              for outer, holes in screen_groups]
    groups = cg.organize_loops([lp for outer, holes in groups for lp in [outer] + holes])
    frame = Matrix.Identity(4)
    for r in range(3):
        frame[r][0], frame[r][1], frame[r][2], frame[r][3] = x[r], y[r], n[r], origin[r]
    return groups, frame, screen_groups, embed


def perform_base(context, loops, projector, cutter=False, targets=None, attach=None, path=None,
                 sweep_style=None, section_width=None, section_height=None, section_rest=False,
                 section_rotation=None):
    """Create a solid or cutter, optionally forcing a section for a single draw.

    Press Cut Alt+drag uses sweep_style='ALPHA' so its CURRENT selected stamp
    is the section without changing the regular Base Mesh section setting.
    """
    defaults = scene_defaults(context)
    if sweep_style is not None:
        if sweep_style not in {'CIRCLE', 'SQUARE', 'ALPHA'}:
            raise cg.CutError('Invalid line section style.')
        defaults = _WithSectionStyle(defaults, sweep_style, section_width, section_height, section_rest,
                                     section_rotation)
    creature = defaults.profile in CREATURE_PROFILES
    if not cutter and path is not None and not creature and defaults.profile_sweep != 'OFF':
        return _create_section_sweep(context, loops, projector, path, defaults, attach)
    if cutter and not creature and getattr(defaults, 'alt_mode', 'HEIGHT') == 'CUT':
        return cut_like_cut_tool(context, loops, projector, targets)
    if cutter and not creature and defaults.profile in SURFACE_CARVE:
        return carve_surface(context, loops, projector, defaults, targets)
    groups, frame, screen_groups, embed = _local_groups(context, loops, projector, allow_invert=not cutter)
    if cutter:      # 0.24.23 Creature Base Mesh: Alt engraves the lump (as deep as it is thick); 0.24.37 Base Mesh:
        # the drawn shape carved in, as deep as Height (Alt: Like Cut = the Cut tool's way)
        return _perform_cutter(context, groups, frame, defaults, projector, screen_groups, targets)
    msg = _create_live_base(context, groups, frame, defaults, embed)
    ob = getattr(context, 'active_object', None) if attach is not None else None
    if ob is not None and getattr(ob, 'mch_base', None) is not None and ob.mch_base.live:
        set_attach(ob, frame, projector, *attach)
        ends = sum(1 for h in attach[1:] if h is not None)
        msg += f' | Attach Ends: {ends} of 2 on a mesh ({"As Drawn" if ob.mch_base.attach_curve == "DRAWN" else "Smooth"})'
    return msg


def set_attach(ob, frame, projector, path, hit0, hit1):
    """0.24.57 remember the line (in the solid's plane) and the depths of the meshes at its two ends."""
    inv = frame.inverted_safe()
    n = Vector((frame[0][2], frame[1][2], frame[2][2]))
    origin = frame.translation
    loc = []
    for q in path:
        w = _plane_point(projector, q, origin, n)
        lw = inv @ w
        loc.append([lw.x, lw.y])
    z0 = (inv @ Vector(hit0)).z if hit0 is not None else 0.0
    z1 = (inv @ Vector(hit1)).z if hit1 is not None else 0.0
    eye = None
    if getattr(projector, 'is_perspective', False) and getattr(projector, 'eye', None) is not None:
        eye = list(inv @ Vector(projector.eye))
    ob[ATTACH_KEY] = json.dumps({'path': loc, 'z0': z0, 'z1': z1, 'eye': eye})
    rebuild(ob)


def profiles_for(context, live=None):
    """0.24.20 the profiles a tool offers: Creature Base Mesh = Puff / Ridge / Pillow, Base Mesh = the rest."""
    p = live.mch_base if live is not None else scene_defaults(context)
    creature = p.profile in CREATURE_PROFILES if live is not None else p == getattr(context.scene, 'mch_cbase', None)
    return [q for q in PROFILES if (q[0] in CREATURE_PROFILES) == creature]


def scene_defaults(context):
    """0.24.20 settings for the next shape: Creature Base Mesh has its own (Puff / Ridge / Pillow)."""
    scene = context.scene
    try:
        creature = ts.effective_tool(context) == 'CBASE'
    except (AttributeError, KeyError, TypeError):
        creature = False
    p = scene.mch_cbase if creature and hasattr(scene, 'mch_cbase') else scene.mch_base
    if (p.profile in CREATURE_PROFILES) != creature:
        try:                     # each tool keeps to its own profiles (not possible while drawing the UI)
            p.profile = 'PUFF' if creature else 'FLAT'
        except (AttributeError, RuntimeError, TypeError):
            pass
    return p


class _WithSectionStyle:
    """Settings view for a single Alt+draw. Does NOT mutate scene settings."""

    def __init__(self, base, style, width=None, height=None, rest=False, rotation=None):
        self._base = base
        self.profile_sweep = style
        if width is not None:          # 0.24.107 the drawn line's own width (what the preview band showed)
            self.section_width = max(0.001, float(width))
        if height is not None:         # 0.24.108 Press Cut: the section as tall as the stamp (the stamp itself)
            self.height = max(0.001, float(height))
        self.section_rest = bool(rest) # 0.24.108 the section rests on the surface (not half sunk)
        if rotation is not None:       # 0.24.109 (user: "스탬프를 로테이션으로 돌리면 ... 앵글도 돌아가야지") the stamp's turn
            self.section_rotation = float(rotation)

    def __getattr__(self, name):
        return getattr(self._base, name)


class _WithEmbed:
    """Settings view: ``defaults`` with this shape's own embed."""

    def __init__(self, base, embed):
        self._base = base
        self.embed = embed

    def __getattr__(self, name):
        return getattr(self._base, name)


def _create_live_base(context, groups, frame, defaults, embed=0.0, sweep_data=None):
    """New live Base Mesh object from plane-local ``groups`` at ``frame``."""
    bm = (_build_sweep_bmesh(sweep_data, defaults) if sweep_data is not None
          else build_bmesh(groups, _WithEmbed(defaults, embed)))
    me = bpy.data.meshes.new('MCH_BaseMesh')
    try:
        bm.to_mesh(me)
        from . import edge_memory as _em; _em.mark_generated(me)   # 0.24.95 Edge Memory: the part's own lines
    finally:
        bm.free()
    ob = bpy.data.objects.new('MCH_Base', me)
    coll = context.collection if context.collection is not None else context.scene.collection
    try:
        coll.objects.link(ob)
    except RuntimeError:
        context.scene.collection.objects.link(ob)
    ob.matrix_world = frame
    live = ob.mch_base
    for key in SETTING_KEYS:
        setattr(live, key, getattr(defaults, key))
    live.profile = defaults.profile        # live is still False: no rebuild yet
    live.embed = embed
    if defaults.profile in CREATURE_PROFILES and defaults.peak <= 0 and LAST_NATURAL:
        live.peak = LAST_NATURAL[0]            # 0.24.20 the Height slider starts at the real height
    live.outline = json.dumps({'groups': [{'outer': g[0], 'holes': g[1]} for g in groups],
                               'res': ts.res_scale()})
    if sweep_data is not None:
        ob[SWEEP_KEY] = json.dumps(sweep_data, separators=(',', ':'))                  # (0.24.95 drawn at this Resolution)
    live.live = True
    session = list(context.scene.get(SESSION_KEY, []))
    session.append(ob.name)
    context.scene[SESSION_KEY] = session
    _arm_tab_watch(context)
    for o in context.selected_objects:
        o.select_set(False)
    ob.select_set(True)
    context.view_layer.objects.active = ob
    name = ('Line ' + defaults.profile_sweep.title() if sweep_data is not None
            else dict((p[0], p[1]) for p in PROFILES)[defaults.profile])
    notes = (' | ' + '; '.join(LAST_NOTES)) if LAST_NOTES else ''
    return f'Base Mesh created: {ob.name} ({name}, {len(me.vertices)} verts, closed solid){notes}'


def _respect_targets(context, found):
    """0.24.95 (user: "베이스 메시 컷을 셀렉트로 하는데 왜 다 잘려?") only the meshes the Targets setting (T) lets a
    tool use: Selected - the selected ones (and what a selected live part was drawn on), Active - the active one."""
    names = target_rules.allowed(context)
    if names is None:
        return list(found)
    return [o for o in found if target_rules.ok(context, o, names)]


def _cutter_targets(context, projector, screen_groups, targets):
    if targets:
        return [t for t in targets if t.type == 'MESH']
    sel = _respect_targets(context, [o for o in context.selected_objects if o.type == 'MESH' and not
                                     (getattr(o, 'mch_base', None) and o.mch_base.live)])
    if sel:
        return sel
    outer = screen_groups[0][0]
    _q, found = anchor_hit(context, projector, outer)      # 0.24.37 a line half off the mesh still finds it
    return [bpy.data.objects[found[2].name]] if found is not None else []


def _sketch_cutter_targets(context, groups, frame):
    """Selected meshes, else the mesh under the sketch (ray from in front of
    the plane, against its normal)."""
    sel = _respect_targets(context, [o for o in context.selected_objects if o.type == 'MESH' and not
                                     (getattr(o, 'mch_base', None) and o.mch_base.live)])
    if sel:
        return sel
    dg = context.evaluated_depsgraph_get()
    n = frame.col[2].to_3d().normalized()
    found = []
    for outer, _holes in groups:
        cx = sum(q[0] for q in outer) / len(outer)
        cy = sum(q[1] for q in outer) / len(outer)
        for q in [(cx, cy)] + list(_outline_samples(outer)):   # 0.24.38 the centre may be off the mesh
            start = frame @ Vector((q[0], q[1], 0.0)) + n * 1000.0
            hit, _loc, _n, _i, ob, _m = target_rules.scene_ray(context, dg, start, -n)
            if hit and ob is not None and ob.type == 'MESH':
                real = bpy.data.objects[ob.name]
                if real not in found:
                    found.append(real)
                break
    return found


SURFACE_CARVE = {'FLAT': 'SQUARE', 'CHAMFER': 'CHAMFER', 'BEVEL': 'BEVEL'}


def first_edge(loops, min_px=2.0):
    """(a, b) the first edge of the drawn outline (screen) - the deep side of Alt: Ramp."""
    if not loops or len(loops[0]) < 3:
        return None
    lp = [tuple(q) for q in loops[0]]
    a = lp[0]
    for b in lp[1:]:
        if math.dist(a, b) >= min_px:
            return a, b
    return None


def carve_surface(context, loops, projector, p, targets=None, ramp_edge=None, live=True):
    """0.24.37 Alt (Carve Height): the drawn shape laid ON the surface and carved in, Height deep everywhere
    along it (a curved surface gets an even pocket / groove, not a flat-bottomed one); Flat = straight walls,
    Chamfer / Bevel = that edge at the opening (Border Width)."""
    from types import SimpleNamespace
    from . import surface_draw as sd
    screen_groups = cg.prepare_loops(loops)
    if not screen_groups:
        raise cg.CutError('The outline is empty.')
    targets = _cutter_targets(context, projector, screen_groups, targets)
    if not targets:
        raise cg.CutError('Alt Base Mesh carves into a mesh: draw over one (nothing was changed).')
    through = getattr(p, 'alt_mode', 'HEIGHT') == 'THROUGH' and ramp_edge is None
    height = max(getattr(p, 'carve_depth', 0.0) or p.height, 1e-5)
    st = SimpleNamespace(profile=SURFACE_CARVE.get(p.profile, 'SQUARE'), edge=0.35, sink=0.0, edge_abs=getattr(p, 'bevel_width', 0.05),
                         fill_res=max(15, min(60, getattr(p, 'resolution', 28))),
                         segments=ts.res_n(getattr(p, 'bevel_segments', 4)),
                         fine=getattr(p, 'resolution', 28) / 28.0 * ts.res_scale(),
                         steep=getattr(p, 'carve_steep', 'EVEN'))
    ramp = None
    is_ramp = ramp_edge is not None or getattr(p, 'alt_mode', 'HEIGHT') == 'RAMP'
    if is_ramp:                     # 0.24.44 the first side drawn is the deep side (0.24.45: or the one picked later)
        from . import ramp_edit
        edge = ramp_edge
        if edge is None:
            segs = ramp_edit.sides(loops[0]) if loops and len(loops[0]) >= 3 else []
            edge = segs[0] if segs else first_edge(loops)
        if edge is None:
            raise cg.CutError('Alt: Ramp - draw a shape with at least one clear edge.')
        ramp = (edge[0], edge[1], getattr(p, 'ramp_length', 1.0), getattr(p, 'ramp_soft', 0.5))
        if live and len(targets) == 1:
            ramp_edit.begin(context, targets[0], loops, projector)     # 0.24.45 the deep side can change later
    done, failed = [], []
    for t in targets:
        try:
            cg.check_target(t)
            if not is_ramp and getattr(p, 'alt_mode', 'HEIGHT') == 'INSIDE':
                height = sd.carve_inside(context, t, screen_groups, projector, st, getattr(p, 'inside_skin', 0.25))
            else:
                height = sd.carve_area(context, t, screen_groups, projector, st, height, through, ramp=ramp)
            done.append(t.name)
        except (cg.CutError, RuntimeError) as ex:
            if len(targets) == 1:
                if ramp is not None and live:
                    from . import ramp_edit
                    ramp_edit.finish(t)         # nothing carved: nothing to change later either
                raise
            failed.append(f'{t.name} ({str(ex).splitlines()[0][:60]})')
    if not done:
        raise cg.CutError('Alt Base Mesh: nothing was carved. ' + '; '.join(failed))
    if is_ramp and live and len(targets) == 1:
        from . import ramp_edit
        ramp_edit.stamp(targets[0])               # 0.24.53 later edits are noticed (not thrown away)
    return f'Base Mesh carve (Alt): {", ".join(done)} | ' + \
        ('a window right through' if through else
         f'a ramp {height:.3g} deep, up to the surface (deep side: < > / Pick Edge in the panel)' if ramp else
         'a channel inside (windows where it crosses the side walls)' if p.alt_mode == 'INSIDE' else
         f'{height:.3g} deep along the surface') + \
        (' | failed: ' + '; '.join(failed) if failed else '')


def cut_like_cut_tool(context, loops, projector, targets=None):
    """0.24.5 Alt in Base Mesh works like the Cut tool (its depth mode, depth, edge finish and solver): the
    old profile cutter was Height deep and went through thin plates."""
    from . import cut_engine as ce
    if not targets:                  # (0.24.95 only what the Targets setting lets it cut - it cut every mesh under
        targets = _respect_targets(context, ce.auto_targets(context.view_layer, projector, loops))   # the shape)
        if not targets and target_rules.mode(context) != 'AUTO':
            what = 'the active mesh' if target_rules.mode(context) == 'ACTIVE' else 'a selected mesh'
            raise cg.CutError(f'Alt Base Mesh (Like Cut): the shape is not over {what} (Targets) - nothing was cut.')
    if not targets:
        raise cg.CutError('Alt Base Mesh cuts like the Cut tool: draw over a mesh.')
    return ce.perform_closed(context, 'CUT', targets, loops, projector, False)


def _view_projector(context):
    try:
        region, rv3d = context.region, context.region_data
        if region is None or region.type != 'WINDOW' or rv3d is None:
            return None
        from . import cut_engine as ce
        return ce.make_projector(region, rv3d)
    except (AttributeError, TypeError):
        return None


def _perform_cutter(context, groups, frame, p, projector, screen_groups, targets):
    """Alt: the drawn solid becomes a Boolean Difference cutter.  Its bevel
    sides are flipped (Top <-> Bottom, Both swaps top/bottom settings) and it is
    mirrored INTO the surface, so the flipped bevel lands on the opening of the
    pocket.  Depth = Height."""
    targets = _cutter_targets(context, projector, screen_groups, targets) if projector is not None \
        else (targets or [])
    if not targets:
        raise cg.CutError('Alt Base Mesh cuts into a mesh: start on a mesh or select the target first.')
    if p.profile == 'DOME' or p.profile == 'CUSHION':
        raise cg.CutError('Alt cutter supports Flat / Chamfer / Bevel and the creature profiles (Dome / Cushion have '
                          'no flat cap).')
    if p.profile in PUFF_BUILT:
        # 0.24.23 creature lump: it is centred on the surface, so the part inside the mesh is taken out (an
        # engraving as deep as the drawn shape is thick, not a cut through)
        bm = build_bmesh(groups, p)
    else:
        bm = build_bmesh(groups, _WithEmbed(p, 0.0), flip=True)
    try:
        if p.profile not in PUFF_BUILT:
            # mirror along local Z (into the surface) and lift a hair above it so the
            # opening is not coplanar with the surface
            eps = max(p.height * 0.01, 1e-5)
            k = (getattr(p, 'carve_depth', 0.0) or p.height) / max(p.height, 1e-9)    # 0.24.38 Carve Depth
            for v in bm.verts:
                v.co.z = -v.co.z * k + eps
            bmesh.ops.reverse_faces(bm, faces=bm.faces[:])
        me = bpy.data.meshes.new('MCH_BaseCutter')
        bm.to_mesh(me)
        from . import edge_memory as _em
        _em.drop_profile_flags(me)                 # (a cutter: its profile rows are not a part's)
    finally:
        bm.free()
    cutter = cg.link_temp_object(context, me)
    cutter.matrix_world = frame
    cut = context.scene.mch_cut
    done, failed, temp = [], [], []
    try:
        results = []
        for t in targets:
            try:
                cg.check_target(t)
                res, _solver = cg.boolean_result(context, t, cutter, 'DIFFERENCE', cut.solver, cut.hole_tolerant)
                temp.append(res)
                results.append((t, res))
            except (cg.CutError, RuntimeError) as ex:
                if len(targets) == 1:
                    raise
                failed.append(f'{t.name} ({str(ex).splitlines()[0][:60]})')
        if not results:
            raise cg.CutError('The Base Mesh cutter does not intersect any target; nothing was changed.')
        for t, res in results:
            cg.commit_mesh(t, res, cut.shared_mesh)
            done.append(t.name)
    finally:
        for m in temp:
            if m.users == 0:
                bpy.data.meshes.remove(m)
        cg.remove_object_and_mesh(cutter)
    sides, _t, _b = side_values(p, flip=True)
    if p.profile in PUFF_BUILT:
        msg = f'Engraved (Alt) into {", ".join(done)}: as deep as the shape is thick'
    else:
        msg = f'Base Mesh cutter (Alt): {", ".join(done)} | cutter bevel: {sides.title()}'
    if failed:
        msg += ' | FAILED, unchanged: ' + '; '.join(failed)
    return msg


# -----------------------------------------------------------------------------
# 0.14.1 Sketch First: orange outline you add to / subtract from, Enter = mesh
# -----------------------------------------------------------------------------

SKETCH_KEY = 'mch_base_sketch'     # Scene ID prop (JSON): undo (Ctrl+Z) removes the last stroke
SKETCH_EPS = 1e-7


def sketch_data(scene):
    text = scene.get(SKETCH_KEY) if scene is not None else None
    if not text:
        return None
    try:
        data = json.loads(text)
    except (TypeError, ValueError):
        return None
    return data if data.get('items') else None


def sketch_frame(data):
    m = Matrix.Identity(4)
    vals = data['frame']
    for r in range(4):
        for c in range(4):
            m[r][c] = vals[r * 4 + c]
    return m


def sketch_clear(scene):
    if scene is not None and SKETCH_KEY in scene:
        del scene[SKETCH_KEY]


def _region_loops(items):
    """Flatten sketch items into CDT input: loops + (item index, is_hole)."""
    loops, owner = [], []
    for k, item in enumerate(items):
        for outer, holes in item['groups']:
            loops.append(outer)
            owner.append((k, False))
            for h in holes:
                loops.append(h)
                owner.append((k, True))
    return loops, owner


def sketch_triangles(items):
    """(verts, kept triangles) of the combined sketch: every stroke region is
    added or subtracted IN ORDER.  Blender's constrained Delaunay splits all
    outlines at their crossings and reports which input outlines contain each
    triangle, so overlaps, holes and islands come out exactly."""
    loops, owner = _region_loops(items)
    if not loops:
        return [], []
    verts, faces = [], []
    for lp in loops:
        if cg.signed_area(lp) < 0:
            lp = list(reversed(lp))      # the CDT needs counter-clockwise faces (holes are known by owner)
        start = len(verts)
        verts += [Vector((q[0], q[1])) for q in lp]
        faces.append(list(range(start, start + len(lp))))
    out_v, _e, out_f, _vo, _eo, out_fo = delaunay_2d_cdt(verts, [], faces, 1, SKETCH_EPS, True)
    kept = []
    for f, orig in zip(out_f, out_fo):
        if len(f) != 3:
            continue
        inside = False
        for k, item in enumerate(items):
            mine = [owner[i][1] for i in orig if owner[i][0] == k]
            # inside this stroke = inside one of its outlines and not in its holes
            in_region = bool(mine) and (mine.count(False) - mine.count(True)) > 0
            if not in_region:
                continue
            inside = item['op'] == 'ADD'
        if inside:
            a, b, c = f
            area = (out_v[b] - out_v[a]).cross(out_v[c] - out_v[a])
            kept.append((a, b, c) if area > 0 else (a, c, b))
    return [tuple(v) for v in out_v], kept


def _boundary_loops(verts, tris):
    """Outline loops of a set of counter-clockwise triangles."""
    directed = set()
    for a, b, c in tris:
        directed.update(((a, b), (b, c), (c, a)))
    nxt = {}
    for a, b in directed:
        if (b, a) not in directed:
            nxt.setdefault(a, []).append(b)
    loops = []
    while nxt:
        start = next(iter(nxt))
        lp = [start]
        cur = start
        for _ in range(len(directed) + 1):
            outs = nxt.get(cur)
            if not outs:
                break
            n = outs.pop()
            if not outs:
                del nxt[cur]
            if n == start:
                break
            lp.append(n)
            cur = n
        if len(lp) >= 3:
            loops.append([verts[i] for i in lp])
    return [_drop_collinear(lp) for lp in loops]


def _drop_collinear(lp, eps=1e-10):
    out = []
    n = len(lp)
    for i in range(n):
        a, b, c = lp[i - 1], lp[i], lp[(i + 1) % n]
        cross = (b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0])
        if abs(cross) > eps * max(1e-12, math.dist(a, b) * math.dist(b, c)) or math.dist(a, c) < 1e-12:
            out.append(b)
    return out if len(out) >= 3 else lp


def sketch_regions(items, fill=False):
    """Combined sketch as Base Mesh groups [(outer CCW, [holes CW])].  0.24.108 ``fill``: the added strokes' union
    with its holes filled (Line mode Area: the region the lines enclose), the subtracted ones still taken away."""
    if fill:
        items = sketch_filled_items(items)
    verts, tris = sketch_triangles(items)
    if not tris:
        return []
    return cg.organize_loops(_boundary_loops(verts, tris))


def sketch_filled_items(items):
    """The sketch's items with every ADD stroke replaced by one ADD of their union without holes (SUB items kept,
    after it)."""
    adds = [it for it in items if it.get('op') == 'ADD']
    subs = [it for it in items if it.get('op') != 'ADD']
    if not adds:
        return list(items)
    verts, tris = sketch_triangles(adds)
    if not tris:
        return list(items)
    filled = [[[list(q) for q in outer], []] for outer, _holes in cg.organize_loops(_boundary_loops(verts, tris))]
    return [{'op': 'ADD', 'groups': filled}] + subs


def sketch_add(context, loops, projector, subtract=False):
    """Add (or, Alt, subtract) a drawn outline to the sketch.  The first stroke
    fixes the drawing plane; later strokes are projected onto that plane, so
    the view may be orbited between strokes."""
    scene = context.scene
    screen_groups = cg.prepare_loops(loops)
    data = sketch_data(scene)
    if data is None:
        if subtract:
            raise cg.CutError('Draw a shape first: Alt subtracts from the orange sketch.')
        origin, x, y, n, embed = frame_for(context, projector, screen_groups)
        frame = Matrix.Identity(4)
        for r in range(3):
            frame[r][0], frame[r][1], frame[r][2], frame[r][3] = x[r], y[r], n[r], origin[r]
        data = {'frame': [frame[r][c] for r in range(4) for c in range(4)], 'items': [], 'embed': embed}
    else:
        frame = sketch_frame(data)
    origin = frame.translation
    n = frame.col[2].to_3d().normalized()
    inv = frame.inverted()

    def to_local(q):
        o, d = projector.ray(q)
        if abs(d.dot(n)) < 1e-6:
            raise cg.CutError('The view is edge-on to the sketch plane: orbit a little and draw again.')
        w = cg._plane_hit(o, d, origin, n)[0]
        v = inv @ w
        return (v.x, v.y)
    local_loops = [[to_local(q) for q in lp] for outer, holes in screen_groups for lp in [outer] + holes]
    groups = cg.organize_loops(local_loops)
    data['items'].append({'op': 'SUB' if subtract else 'ADD',
                          'groups': [[[list(q) for q in o], [[list(q) for q in h] for h in hs]] for o, hs in groups]})
    regions = sketch_regions(data['items'])
    scene[SKETCH_KEY] = json.dumps(data)
    adds = sum(1 for it in data['items'] if it['op'] == 'ADD')
    subs = len(data['items']) - adds
    state = f'{len(regions)} piece(s)' if regions else 'empty'
    return (f'Sketch: {"subtracted" if subtract else "added"} ({adds} added, {subs} subtracted, {state}) | '
            f'Enter: make mesh, Alt+Enter: cut into mesh, Esc: clear')


def sketch_commit(context, cutter=False):
    """Enter: the sketch becomes a live Base Mesh (Alt+Enter: a cutter into
    the mesh below).  The sketch is cleared only on success."""
    scene = context.scene
    data = sketch_data(scene)
    if data is None:
        raise cg.CutError('No sketch: draw a shape with the Base Mesh tool first.')
    groups = sketch_regions(data['items'])
    if not groups:
        raise cg.CutError('The sketch is empty (everything was subtracted). Esc clears it.')
    frame = sketch_frame(data)
    groups = [([tuple(q) for q in o], [[tuple(q) for q in h] for h in hs]) for o, hs in groups]
    p = scene_defaults(context)
    creature = p.profile in CREATURE_PROFILES
    like_cut = getattr(p, 'alt_mode', 'HEIGHT') == 'CUT'
    on_surface = p.profile in SURFACE_CARVE        # 0.24.38 Carve Height / Through follow the surface here too
    proj = _view_projector(context) if cutter and not creature and (like_cut or on_surface) else None
    if cutter and proj is not None:
        # 0.24.5 Alt+Enter cuts like the Cut tool too: the sketch seen from the current view
        loops = []
        for o, hs in groups:
            for lp in [o] + list(hs):
                pts = [proj.to_screen(frame @ Vector((q[0], q[1], 0.0))) for q in lp]
                if any(p_ is None for p_ in pts):
                    raise cg.CutError('The sketch is behind the view: orbit so it is in front, then Alt+Enter.')
                loops.append([tuple(p_) for p_ in pts])
        msg = cut_like_cut_tool(context, loops, proj) if like_cut else carve_surface(context, loops, proj, p)
    elif cutter:
        if getattr(p, 'invert_height', False):    # the sketch plane was flipped for Invert: carve into the mesh
            frame = frame @ Matrix.Diagonal((1.0, -1.0, -1.0, 1.0))
            groups = [([(q[0], -q[1]) for q in o], [[(q[0], -q[1]) for q in h] for h in hs]) for o, hs in groups]
        targets = _sketch_cutter_targets(context, groups, frame)
        msg = _perform_cutter(context, groups, frame, p, None, None, targets)
    else:
        msg = _create_live_base(context, groups, frame, scene_defaults(context), data.get('embed', 0.0))
    sketch_clear(scene)
    return msg


_SKETCH_CACHE = {}
_sketch_handle = None


def _sketch_draw_data(scene):
    text = scene.get(SKETCH_KEY)
    hit = _SKETCH_CACHE.get('v')
    if hit is not None and hit[0] == text:
        return hit[1]
    data = sketch_data(scene)
    out = None
    if data is not None:
        frame = sketch_frame(data)
        verts, tris = sketch_triangles(data['items'])
        world = [tuple(frame @ Vector((v[0], v[1], 0.0))) for v in verts]
        lines = []
        for lp in (_boundary_loops(verts, tris) if tris else []):
            pts = [tuple(frame @ Vector((q[0], q[1], 0.0))) for q in lp]
            for i in range(len(pts)):
                lines += [pts[i], pts[(i + 1) % len(pts)]]
        out = (world, tris, lines)
    _SKETCH_CACHE['v'] = (text, out)
    return out


def _draw_sketch():
    try:
        context = bpy.context
        scene = context.scene
        if scene is None or not scene.get(SKETCH_KEY):
            return
        from . import tool_state as ts
        if ts.effective_tool(context) != 'BASE':
            return
        d = _sketch_draw_data(scene)
        if not d:
            return
        import gpu
        from gpu_extras.batch import batch_for_shader
        world, tris, lines = d
        sh = gpu.shader.from_builtin('UNIFORM_COLOR')
        gpu.state.blend_set('ALPHA')
        gpu.state.depth_test_set('NONE')
        orange = (1.0, 0.55, 0.12)
        if tris:
            sh.uniform_float('color', (*orange, 0.18))
            batch_for_shader(sh, 'TRIS', {'pos': world}, indices=tris).draw(sh)
        if lines:
            gpu.state.line_width_set(2.0)
            sh.uniform_float('color', (*orange, 0.95))
            batch_for_shader(sh, 'LINES', {'pos': lines}).draw(sh)
            gpu.state.line_width_set(1.0)
        gpu.state.blend_set('NONE')
    except Exception:      # never break viewport drawing
        pass


def _sketch_poll(context):
    from . import tool_state as ts
    try:
        return (context.area is not None and context.area.type == 'VIEW_3D' and
                ts.effective_tool(context) == 'BASE' and sketch_data(context.scene) is not None)
    except (AttributeError, KeyError, TypeError):
        return False


class MCH_OT_base_sketch_commit(bpy.types.Operator):
    """Enter: the orange sketch becomes a Base Mesh.  Alt+Enter: it cuts into the mesh below"""
    bl_idname = 'mch.base_sketch_commit'
    bl_label = 'Make Mesh from Sketch'
    bl_options = {'REGISTER', 'UNDO'}
    cutter: BoolProperty(name='Cut Into Mesh', default=False, options={'SKIP_SAVE'})

    @classmethod
    def description(cls, context, properties):
        return ('Cut the sketch into the mesh below (selected meshes first)  (Alt+Enter)' if properties.cutter
                else 'Make a new Base Mesh from the orange sketch  (Enter)')

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and sketch_data(context.scene) is not None

    def execute(self, context):
        try:
            msg = sketch_commit(context, self.cutter)
        except cg.CutError as ex:
            self.report({'WARNING'}, str(ex))
            return {'CANCELLED'}
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class MCH_OT_base_sketch_key(bpy.types.Operator):
    """Enter / Alt+Enter in the Base Mesh tool while a sketch exists"""
    bl_idname = 'mch.base_sketch_key'
    bl_label = 'Sketch Key'
    bl_options = {'INTERNAL'}
    cutter: BoolProperty(default=False, options={'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        return _sketch_poll(context)

    def execute(self, context):
        return bpy.ops.mch.base_sketch_commit('EXEC_DEFAULT', cutter=self.cutter)


class MCH_OT_base_sketch_clear(bpy.types.Operator):
    """Throw the orange sketch away (Esc in the Base Mesh tool)"""
    bl_idname = 'mch.base_sketch_clear'
    bl_label = 'Clear Sketch'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return sketch_data(context.scene) is not None

    def execute(self, context):
        sketch_clear(context.scene)
        self.report({'INFO'}, 'Sketch cleared')
        return {'FINISHED'}


class MCH_OT_base_sketch_undo(bpy.types.Operator):
    """Remove the last shape from the sketch (Backspace)"""
    bl_idname = 'mch.base_sketch_undo'
    bl_label = 'Remove Last Sketch Shape'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return sketch_data(context.scene) is not None

    def execute(self, context):
        data = sketch_data(context.scene)
        data['items'].pop()
        if data['items']:
            context.scene[SKETCH_KEY] = json.dumps(data)
        else:
            sketch_clear(context.scene)
        return {'FINISHED'}


def auto_apply_session(context):
    """F02: leaving / switching away from the Base Mesh tool applies (freezes)
    ONLY the live Base Meshes this tool created since it was entered.  Other
    objects and modifiers are never touched.  Freezing keeps the geometry
    (no data change) and is one undo step."""
    from . import live_queue
    live_queue.flush()                      # 0.24.73 a rebuild still waiting goes in before freezing
    names = list(context.scene.get(SESSION_KEY, []))
    for key in (SESSION_KEY, WS_KEY):
        if key in context.scene:
            del context.scene[key]
    frozen = []
    for name in names:
        ob = bpy.data.objects.get(name)
        if ob is not None and getattr(ob, 'mch_base', None) and ob.mch_base.live:
            ob.mch_base.live = False
            frozen.append(name)
    if frozen:
        from . import undo_keep
        undo_keep.push('Base Mesh: auto apply')
    return frozen


WS_KEY = 'mch_base_session_ws'      # workspace the session was started in
WATCH_INTERVAL = 0.5


def _current_workspaces():
    wm = bpy.context.window_manager
    try:
        return {w.workspace.name for w in wm.windows if w.workspace is not None}
    except (AttributeError, ReferenceError):
        return set()


def _arm_tab_watch(context):
    """Leaving the workspace (another top tab) also applies this session's
    shapes.  A light timer runs only while unapplied shapes exist."""
    try:
        ws = context.workspace.name if context.workspace is not None else ''
    except (AttributeError, ReferenceError):
        ws = ''
    if ws and not context.scene.get(WS_KEY):
        context.scene[WS_KEY] = ws
    if not bpy.app.timers.is_registered(_tab_watch):
        bpy.app.timers.register(_tab_watch, first_interval=WATCH_INTERVAL)


def check_tab_left(context=None, workspaces=None):
    """Apply the session when its workspace is no longer shown in any window.
    Returns the frozen object names (testable without a window)."""
    context = context or bpy.context
    scene = context.scene
    if scene is None or not scene.get(SESSION_KEY):
        return None
    ws = scene.get(WS_KEY, '')
    shown = _current_workspaces() if workspaces is None else set(workspaces)
    if ws and shown and ws not in shown:
        frozen = auto_apply_session(context)
        return frozen
    return []


def _tab_watch():
    try:
        scene = bpy.context.scene
        if scene is None or not scene.get(SESSION_KEY):
            return None                      # nothing pending: stop the timer
        check_tab_left()
        return WATCH_INTERVAL if bpy.context.scene.get(SESSION_KEY) else None
    except (AttributeError, ReferenceError, RuntimeError):
        return None


CBASE_START = {'resolution': 15}       # 0.24.21 Creature Base Mesh starts lighter than Base Mesh (same settings type)


def init_creature_defaults(scene):
    """Give a scene's Creature Base Mesh settings their own starting values once (they share the Base Mesh type)."""
    st = getattr(scene, 'mch_cbase', None)
    if st is None or scene.get('mch_cbase_init'):
        return
    for k, v in CBASE_START.items():
        setattr(st, k, v)
    scene['mch_cbase_init'] = True


def _init_all_scenes():
    try:
        for sc in bpy.data.scenes:
            init_creature_defaults(sc)
    except (AttributeError, TypeError, RuntimeError):
        pass
    return None


@bpy.app.handlers.persistent
def _migrate_on_load(_dummy=None):
    """v0.8-0.9 'Bevel Bottom Too' -> Bevel Sides = Both (only when unset)."""
    _init_all_scenes()
    pgs = [sc.mch_base for sc in bpy.data.scenes if hasattr(sc, 'mch_base')]
    pgs += [ob.mch_base for ob in bpy.data.objects if hasattr(ob, 'mch_base')]
    for p in pgs:
        if p.bottom_too and 'bevel_sides' not in p:
            live = p.live
            p.live = False          # no rebuild while migrating
            p.bevel_sides = 'BOTH'
            p.live = live


# -----------------------------------------------------------------------------
# Operators
# -----------------------------------------------------------------------------


def active_live_base(context):
    ob = context.active_object
    if ob is not None and ob.type == 'MESH' and getattr(ob, 'mch_base', None) and \
            ob.mch_base.live and ob.mch_base.outline and ob.select_get():
        return ob
    return None


class MCH_OT_set_profile(bpy.types.Operator):
    bl_idname = 'mch.set_profile'
    bl_label = 'Base Mesh Profile'
    bl_description = 'Profile for new Base Mesh shapes (also applied to the selected live Base Mesh)'
    bl_options = {'REGISTER', 'UNDO'}
    profile: EnumProperty(items=PROFILE_ITEMS, default='FLAT')

    @classmethod
    def description(cls, context, properties):
        p = next((p for p in PROFILES if p[0] == properties.profile), None)
        return p[2] if p else cls.bl_description

    def execute(self, context):
        scene_defaults(context).profile = self.profile
        ob = active_live_base(context)
        if ob is not None:
            ob.mch_base.profile = self.profile
            if ob.mch_base.last_error:
                self.report({'WARNING'}, ob.mch_base.last_error)
        return {'FINISHED'}


class MCH_OT_base_freeze(bpy.types.Operator):
    bl_idname = 'mch.base_freeze'
    bl_label = 'Freeze Base Mesh'
    bl_description = 'Stop live rebuilding; the mesh becomes an ordinary mesh you can edit freely'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return active_live_base(context) is not None

    def execute(self, context):
        from . import live_queue
        live_queue.flush()                  # 0.24.73 a rebuild still waiting goes in before freezing
        ob = active_live_base(context)
        ob.mch_base.live = False
        self.report({'INFO'}, f'{ob.name}: frozen (no longer live)')
        return {'FINISHED'}


CLASSES = (MCH_PG_BaseMesh, MCH_OT_set_profile, MCH_OT_base_section_use_alpha, MCH_OT_base_freeze,
           MCH_OT_depth_side_guide, MCH_OT_depth_side_clear, MCH_OT_base_sketch_commit,
           MCH_OT_base_sketch_key, MCH_OT_base_sketch_clear, MCH_OT_base_sketch_undo)


def register():
    for c in CLASSES:
        bpy.utils.register_class(c)
    bpy.types.Scene.mch_base = bpy.props.PointerProperty(type=MCH_PG_BaseMesh)
    bpy.types.Scene.mch_cbase = bpy.props.PointerProperty(type=MCH_PG_BaseMesh)    # 0.24.20 Creature Base Mesh
    bpy.types.Object.mch_base = bpy.props.PointerProperty(type=MCH_PG_BaseMesh)
    if _migrate_on_load not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_migrate_on_load)
    bpy.app.timers.register(_init_all_scenes, first_interval=0.1)    # the scene open while enabling the add-on
    global _sketch_handle
    if not bpy.app.background and _sketch_handle is None:
        _sketch_handle = bpy.types.SpaceView3D.draw_handler_add(_draw_sketch, (), 'WINDOW', 'POST_VIEW')


def unregister():
    global _sketch_handle
    if _sketch_handle is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(_sketch_handle, 'WINDOW')
        except (ValueError, RuntimeError):
            pass
        _sketch_handle = None
    if bpy.app.timers.is_registered(_tab_watch):
        bpy.app.timers.unregister(_tab_watch)
    if _migrate_on_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_migrate_on_load)
    for n, t in (('mch_base', bpy.types.Object), ('mch_base', bpy.types.Scene), ('mch_cbase', bpy.types.Scene)):
        if hasattr(t, n):
            delattr(t, n)
    for c in reversed(CLASSES):
        bpy.utils.unregister_class(c)
