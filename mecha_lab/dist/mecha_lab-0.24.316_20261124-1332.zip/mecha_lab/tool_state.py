"""Shared Mecha Lab state: tool registry, shape (brush) settings, cut settings.

Separation (docs/01 "data design"):
* Tool ID ............ ``Scene.mch_settings.mch_active_tool`` (+ the native
                       WorkSpaceTool for drawing tools, which wins when active)
* Shape/brush ........ ``Scene.mch_brush`` (shared by Cut / Split / Mask)
* Per-tool options ... ``Scene.mch_cut`` and the v0.5.9 ``Scene.mch_settings``
* Machine-wide ....... add-on preferences (hotkeys) and the PNG shape library
                       in the user config folder (see cut_presets).
"""
import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty

from . import facet_carve as fc

WORKSPACE_NAME = 'MECHA LAB'
WORKSPACE_TAG = 'mch_workspace'

# (id, label, description, png icon stem, fallback icon, native tool idname, status)
# status: 'OK' working, 'PARTIAL' limited, 'TODO' not implemented (shown honestly).
TOOLS = (
    ('CUT', 'Cut', 'Draw a shape to remove the inside (Alt: keep inside)', 'cut', 'MOD_BOOLEAN', 'mecha.cut', 'OK'),
    ('SPLIT', 'Split', 'Draw a shape to split the mesh into two solid parts', 'split', 'MOD_EDGESPLIT', 'mecha.split', 'OK'),
    ('PRESS', 'Press Cut', 'A saved shape as a stamp: press on a part and hold - it is cut in, deeper the longer you '
     'hold (let go to keep it, Esc to put it back); Cut or Split; Save Shape keeps a lasso you drew', 'press_cut',
     'MOD_BOOLEAN', 'mecha.press_cut', 'OK'),
    ('HIDE', 'Box Hide', 'Draw a shape over meshes to hide what is inside it (Alt: show it again); Cap / Open, '
     'Mirror X, Show All, Apply - non-destructive until Apply', 'hide', 'HIDE_ON', 'mecha.box_hide', 'OK'),
    ('CMOVE', 'Concept Move', 'Grab the surface and pull it like clay (Sphere / Box, Hardness); the pulled part is '
     'really generated, F9 adjusts it. Hold D + drag in any tool does the same',
     'concept_move', 'VIEW_PAN', 'mecha.concept_move', 'OK'),
    ('CPATH', 'Path Move', 'Grab like Concept Move and drag a path: the grabbed box / ball keeps its shape and '
     'follows the way you go, turning where it bends (frames, pipes, arms); F9 adjusts',
     'path_move', 'MOD_CURVE', 'mecha.concept_path', 'OK'),
    ('SMOVE', 'Silhouette Move', 'Path Move that always pulls the whole part: cut where you grab, the whole section '
     'follows the way you go, so the part stretches and bends - its silhouette changes (the Path Move of before '
     '0.24.54, Whole without Tab)', 'silhouette_move', 'MOD_SIMPLEDEFORM', 'mecha.silhouette_move', 'OK'),
    ('SMART', 'Smart Move', 'Place a part by hand: click a part to hold it, click a surface - its origin goes there '
     '(rotation and size unchanged, Lift along the normal); the 3D mouse turns it about its origin (View / World axes, '
     'Speed, Invert; Push off / Normal / Free).  Enter / Space / RMB keep, Esc puts it back', 'smart_move',
     'OBJECT_ORIGIN', 'mecha.smart_move', 'OK'),
    ('GSCULPT', 'Geo Sculpt', 'Sculpt brushes on a plain part, no DynaMesh (Geometry Nodes): Standard, Clay, Clay '
     'Buildup, Flat, Move, Smooth, Edge Line (the line you draw becomes a crisp edge, only as far as you drew), Panel '
     'Line (a panel groove along it), Chamfer / Round (a hard edge, as wide as the brush).  S: Draw Size, U: Intensity, Alt: invert, Shift: Smooth; '
     'the mesh changes on Apply', 'geo_sculpt', 'SCULPTMODE_HLT', 'mecha.geo_sculpt', 'OK'),
    ('GREEBLE', 'Greeble Line', 'Drag on a part: the meshes you picked (the window: Pick Part - click them, Add '
     'Selected, Starter Parts) laid one after another along the line, standing on the surface - machine parts packed '
     'along the stroke.  Order, Part Size, Gap, Rows, Sink, Flip / Turn Random; select a line to change it, Apply to '
     'keep', 'greeble', 'MOD_ARRAY', 'mecha.greeble_line', 'OK'),
    ('CGREEBLE', 'Scale Line', 'Drag on a creature: scales laid overlapping in staggered rows along the line (Scale '
     'Parts), or details scattered along it - spikes, bumps, nubs, fins, warts (Detail Parts), or your own meshes '
     '(Pick Part); each standing on the surface.  Up / Turn / Tilt, Gap, Rows, Stagger, Sink; select a line to change '
     'it, Apply to keep', 'cgreeble', 'OUTLINER_OB_POINTCLOUD', 'mecha.scale_line', 'OK'),
    ('FGREEBLE', 'Feather Line', 'Drag on a creature: feathers along the line, their quills on it, overlapping like '
     'shingles - 16 feathers (contour, covert, primary, tail, down, plume, owl, hawk, pheasant, crest, ribbon, peacock, kestrel '
     '...), Length / Width, Longer to End / at Start, Length Random, Rows; select a line to change it, Enter / Apply to '
     'keep', 'fgreeble', 'OUTLINER_OB_POINTCLOUD', 'mecha.feather_line', 'OK'),
    ('PERF', 'Perforate', 'Sci-fi perforated plate: honeycomb / circle / square / diamond holes through the selected '
     'meshes; live (size, gap, margin, rotation, offset), Apply to keep',
     'perforate', 'MOD_BOOLEAN', None, 'OK'),
    ('SDRAW', 'Surface Draw', 'Draw on a mesh like in VR: a raised band along the line (edges Square / Chamfer / Bevel); '
     'every stroke keeps the first one\'s width and height, bands never pile up; Alt + draw cuts that area out', 'surface_draw', 'GREASEPENCIL',
     'mecha.surface_draw', 'OK'),
    ('RSYM', 'Radial Symmetry', 'Click a centre point: the selected meshes repeat round it (Count, the active mesh\'s '
     'local X / Y / Z axis); new Base Mesh / plates repeat too, Cut cuts every copy', 'radial_sym', 'MOD_ARRAY', None,
     'OK'),
    ('BASE', 'Base Mesh', 'Draw an outline to create a NEW solid (Flat / Chamfer / Bevel / Dome); RMB = profiles',
     'base', 'MESH_CUBE', 'mecha.base_mesh', 'OK'),
    # 0.24.305 (user: "기존 베이스 메쉬랑 아머 플레이트는 냅두고 복사해서 몰드 베이스 메쉬, 몰드 아머 플레이트로 분리") the same tools
    # with the moldings (Side / Edge Molding, Top Dome, Mold Cut); the originals as they were before them
    ('MBASE', 'Mold Base Mesh', 'Base Mesh with moldings: Side Molding, Top / Bottom Edge Molding (out or in, Lip Rim, '
     'Slope), Top Dome; Alt + draw carves with the Mold Cut', 'mbase', 'MESH_CUBE', 'mecha.mold_base', 'OK'),
    ('MPLATE', 'Mold Armor Plate', 'Armor Plate with moldings: Top / Bottom Edge Molding, Lip Rim, Top Dome; Alt + draw '
     'carves with the Mold Cut', 'mplate', 'MOD_SOLIDIFY', 'mecha.mold_plate', 'OK'),
    ('CBASE', 'Creature Base Mesh', 'Draw an outline to create a NEW rounded solid: Puff (round, thin parts thin), '
     'Ridge (diamond cross-section) or Pillow (flat, round edge); Height slider; RMB = profiles',
     'cbase', 'META_BALL', 'mecha.creature_base', 'OK'),
    # 0.24.183 (user: "크리쳐 베이스 메쉬 2 ... 라쏘로 그리면 그 형태에 따라서 바위나 비늘, 버섯, 수정 그런 큰 덩어리의 오가닉한
    # 물질 프리셋으로")
    ('OMASS', 'Creature Base Mesh 2', 'Draw an outline: a big organic lump in that shape, of the matter you pick - Rock, '
     'Big Scale, Mushroom, Crystal, Coral, Bone, Shell, Lava Rock, Flesh, Ice, Sponge, Bark; live (Thickness, Back, '
     'Lumps, Detail, its Pattern, colours), Enter keeps it', 'omass', 'OUTLINER_OB_META', 'mecha.organic_mass', 'OK'),
    ('SUBD', 'SubD Plane', 'Plane with live Simple + Catmull-Clark subdivision and Solidify; edit it right here '
     '(0.24.231, no Edit Mode): drag a point, drag an outline edge to pull a new face out', 'subd', 'MOD_SUBSURF',
     'mecha.subd_plane', 'OK'),
    ('PLATE', 'Armor Plate', 'Draw a lasso on a mesh: a separate armour plate made of new clean faces '
     '(no retopology); mouse wheel while drawing = profile', 'armor', 'MOD_SOLIDIFY', 'mecha.armor_plate', 'OK'),
    ('CPLATE', 'Creature Plate', 'Draw a lasso on a mesh: a rounded plate laid on the surface - Puff / Ridge / '
     'Pillow, Height and End Height (one end lifts like a scale), Edge Round / Edge Thickness; live until Apply',
     'cplate', 'MOD_SMOOTH', 'mecha.creature_plate', 'OK'),
    ('BELT', 'Belt Maker', 'Draw a line over a mesh: a strap - Wrap Around (all the way around there) or Follow '
     'Line (along the line); Plain / Rail (sci-fi rails, groove, bolts) strap; live until Apply',
     'belt', 'MOD_CURVE', 'mecha.belt_maker', 'OK'),
    ('SPIKE', 'Creature Spike', 'Draw a line over a mesh: spikes stand along it - four presets (tick some, they '
     'mix at random), size / lean / turn with random amounts; live until Apply',
     'spike', 'CON_TRACKTO', 'mecha.creature_spike', 'OK'),
    ('SCALES', 'Creature Scales', 'Draw a line over a mesh: overlapping scales along it - Scale A / B / C mixed at '
     'random, size and rotation random, rows; thick roots, thin lifted tips; live until Apply',
     'scales', 'SHARPCURVE', 'mecha.creature_scales', 'OK'),
    ('SBRUSH', 'Scale Brush', 'Lasso an area on a mesh: it fills with flat-bottomed scales packed close together '
     'without touching - twelve pebble presets mixed at random, size / rotation random, gap; live until Apply',
     'scale_brush', 'MESH_ICOSPHERE', 'mecha.scale_brush', 'OK'),
    ('BRIDGE', 'Bridge Patch', 'Lasso across two meshes: the gap between them fills with a smooth patch on the side '
     'you see (the slope carries on), its edges sunk into both; Smooth / Bulge / Thickness; live until Apply',
     'bridge_patch', 'MOD_LATTICE', 'mecha.bridge_patch', 'OK'),
    ('FLOWER', 'Flower Plate', 'Draw an outline on a mesh: that shape grows from it - where you start drawing '
     'stays on the surface, the rest lifts off and bends (Lift, Curl back over or outward, Side Bend, Roll); '
     'live until Apply',
     'flower', 'OUTLINER_OB_FORCE_FIELD', 'mecha.flower_plate', 'OK'),
    ('SCURVE', 'Surface Curve', 'Draw along a mesh: a curve (tube) lies on it - then edit it like a Mesh Curve '
     '(points, radius, profiles incl. Creature / Guts / From Object, outer lines)',
     'surface_curve', 'CURVE_BEZCURVE', 'mecha.surface_curve', 'OK'),
    ('CAPE', 'Cape', 'Draw on a body from the side the cape hangs on: the top of the drawing is the collar - a '
     'live cloak / capelet / poncho drapes from it (Style, Length, Hem, Flare, Wrap, folds, Wind, Tatter); a short '
     'drawing = Preset, a tall one = your outline',
     'cape', 'MOD_CLOTH', 'mecha.cape', 'OK'),
    ('SCAPE', 'Scarf Cape', 'Draw a line across a body: a cape hangs from it, as wide as the line, with fold lines '
     'running across like a draped scarf; Gravity sags the middle down', 'scarf_cape', 'MOD_CLOTH', 'mecha.scarf_cape', 'OK'),
    ('HAIR', 'Creature Hair', 'Draw the scalp area on a head: live dreadlocks / tentacles / quills / strands grow '
     'there and fall over the body (Style, Count, Length, Thickness, Taper, Lift, Gravity, Wave, Rope, Rings)',
     'hair', 'CURVES', 'mecha.creature_hair', 'OK'),
    ('FUR', 'Fur', 'Draw an area on a body: fur grows there - live hair (Geometry Nodes): Density, Length, Lie Down / '
     'Flow, Gravity, Curl, Frizz, Clump, Root / Tip Thickness, colour from the polypaint; draw again: more area, Alt: '
     'take it away', 'fur', 'CURVES', 'mecha.creature_fur', 'OK'),
    ('MEMBRANE', 'Creature Cloth', 'Draw a membrane over your mesh (a dragon / bat wing between its bones): the parts over the '
     'mesh are pinned to it, the rest a cloth that falls (Space), no collision; Enter keeps it '
     '(+ Thickness), skin and vein presets', 'membrane', 'MOD_CLOTH', 'mecha.creature_membrane', 'OK'),   # 0.24.173
    # 0.24.183 (user: "근육 제네레이터 만들자 ... 끝과 끝 점을 이으면 거기에 근육이 생기는 거구"; "메카 근육 메뉴도")
    ('MUSCLE', 'Muscle', 'Click the points of a muscle on your mesh (the bones): it lies on it between them - two for a '
     'long one (thigh, triceps), three for a fan (shoulder, chest: the bands twisting into the arm); Strands, '
     'Thickness, Volume, Length live; Membrane: click points, Enter; Skin Over All: one mesh over the bones and the '
     'muscles', 'muscle', 'OUTLINER_OB_FORCE_FIELD', 'mecha.muscle', 'OK'),
    # 0.24.183 (user: "팔다리 허벅지 이런 거 분리해서 내가 각각 조절" / "슬라이더로 체형이랑 다리 길이 이런 것도 변경")
    ('BODYKIT', 'Body Kit', 'A body made of parts (your Human / Creature): Body Shape sliders (height, legs, arms, '
     'shoulders, hips, build, muscle, definition, head / hands / feet), each part on its own (length, width, depth, '
     'taper, bend), turn a part at its joint (R), swap a part (the other body\'s, your own), muscles on a part; Join '
     'to One Mesh', 'bodykit', 'ARMATURE_DATA', 'mecha.body_kit', 'OK'),
    # 0.24.241 (user: "리깅 툴" - 사람 / 크리쳐 몸, 메카, 꼬리 / 촉수 체인)
    ('RIG', 'Rig', 'Rig a body (Human / Quadruped: joints found on the mesh, IK, weights), mecha parts (one bone a '
     'part; click a part: its joint) or a tail / tentacle chain (Jiggle on playback); Edit Bones, Bind', 'rig',
     'ARMATURE_DATA', 'mecha.rig', 'OK'),
    ('MMUSCLE', 'Mecha Muscle', 'The same points and presets as Muscle, made as an artificial muscle - a core (Fibre '
     'Bundle, Smooth, Ribbed, Piston), a sleeve with holes, end caps - or as Cables; your own core / cap / muscle '
     'presets; Skin Over All', 'mmuscle', 'MOD_SCREW', 'mecha.mecha_muscle', 'OK'),
    ('WING', 'Insect Wing', 'Draw a wing\'s outline: a thin insect wing in that shape, its veins raised inside it '
     '(Dragonfly, Damselfly, Bee / Wasp, Fly, Lacewing, Cicada) - Vein Height / Width / Density, '
     'Thickness; no simulation; select a wing to change it, Enter / Apply to keep', 'wing', 'MOD_PARTICLE_INSTANCE', 'mecha.insect_wing', 'OK'),   # 0.24.173
    ('WDIRT', 'Dirt', 'Draw an area as with Armor Plate: dirt there - lumpy, clods and crumbs, brown; live (its values in '
     'the window). Click a Mesh (the window): click a mesh you made to make it dirt, Alt + click: back to the shape', 'wdirt', 'MOD_DISPLACE',
     'mecha.weather_dirt', 'OK'),
    ('WDUST', 'Dust', 'Draw an area as with Armor Plate: a soft dust layer there (smoothed, puffed a little, fine grain); '
     'live. Click a Mesh (the window): click a mesh, Alt + click: back to the shape', 'wdust', 'MOD_SMOOTH', 'mecha.weather_dust', 'OK'),
    ('WLEAF', 'Leaves', 'Draw an area as with Armor Plate: leaves piled there, green to autumn colours, soil under '
     'them; live. Click a Mesh (the window): click a mesh, Alt + click: back to the shape', 'wleaf', 'OUTLINER_OB_POINTCLOUD', 'mecha.weather_leaves', 'OK'),
    ('WSNOW', 'Snow', 'Draw an area as with Armor Plate: snow there - smoothed, puffed (more on top), soft lumps, white '
     'with blue shade; live. Click a Mesh (the window): click a mesh, Alt + click: back to the shape', 'wsnow', 'FREEZE', 'mecha.weather_snow', 'OK'),
    ('PMEASURE', 'Print Measure', 'Drag on the model: the length and how much of it is horizontal / vertical (Shift: '
     'straight); kept until cleared. The window: the part\'s size, if it fits the printer, Scale to Height',
     'pmeasure', 'DRIVER_DISTANCE', 'mecha.print_measure', 'OK'),
    ('PCUT', 'Print Cut', 'Drag a line across a part: cut into two closed parts with connection pins across the cut '
     '(a peg and a hole, or holes and separate dowel pins; clearance); or cut it through the middle',
     'pcut', 'MOD_BOOLEAN', 'mecha.print_cut', 'OK'),
    ('GARMENT', 'Clothing', 'Front view: draw the outline of a top or pants over a body - the body surface inside it '
     '(front and back) becomes a live garment: Type (T-Shirt / Hoodie / Pants / Cargo), Fit, Smooth, Hem Flare, '
     'Wrinkles, Thickness',
     'garment', 'MATCLOTH', 'mecha.clothing', 'OK'),
    ('HOOD', 'Hood', 'Look at the face and draw round the head: a live hood over it, open toward you, with a cowl '
     'over the shoulders (Style, Looseness, Peak, Cowl, Open Front, Face Opening, Folds, Thickness)',
     'hood', 'USER', 'mecha.hood', 'OK'),
    ('SCARF', 'Scarf', 'Look at the front and draw round the neck: live wraps round it with tails or a front drape '
     '(Style, Wraps, Height, Thickness, Bunching, Flare, Ends, Tail Length / Width, Fringe)',
     'scarf', 'MOD_CLOTH', 'mecha.scarf', 'OK'),
    ('DETAIL', 'Plate Detail', 'Draw an outline on a plate: a low surface trim - flat inside, 1 / 2 / 3 stepped '
     'layers along the edge (edge high or inside high), optional screw recesses; live until Apply',
     'detail1', 'MESH_PLANE', 'mecha.plate_detail', 'OK'),
    ('DETAIL2', 'Plate Detail 2', 'Draw an outline on a surface: it rises smoothly inside the outline to a flat top '
     '(height, slope width, slope shape); live until Apply', 'detail2', 'SURFACE_NSURFACE', 'mecha.plate_detail2', 'OK'),
    ('DETAIL3', 'Plate Detail 3', 'Draw an outline on a plate: a flat raised panel with straight walls, no trim '
     'layers (height, lift); live until Apply', 'detail3', 'MESH_PLANE', 'mecha.plate_detail3', 'OK'),
    ('DETAIL4', 'Plate Detail 4', 'Draw an outline on a surface: a raised plate whose outer rim is rough - concrete, '
     'stone or creature skin (10 presets; height, rim width, strength, chips, texture mix); live until Apply',
     'detail4', 'MESH_PLANE', 'mecha.plate_detail4', 'OK'),
    ('SCREW', 'Screw Stamp', 'Click on a surface to place screw heads (Dome / Post / Socket / Cross), aligned '
     'to the surface; size, height and hole depth stay live; Alt + click removes', 'screw', 'RADIOBUT_ON',
     'mecha.screw_stamp', 'OK'),
    ('WRINKLE', 'Cloth Plate', 'Draw a lasso on a mesh: a separate padded cloth panel - puffs up inside the '
     'border, edge roll, seam pinch folds, stitching (+ optional Padding / Denim / Leather pattern), live until Apply', 'cloth', 'MOD_CLOTH', 'mecha.cloth_wrinkle', 'OK'),
    ('CDRAPE', 'Cloth Drape', 'Draw a lasso on a mesh: a loose cloth laid over that region drops onto it (its rim sewn '
     'on, the body under it the collider); Space drapes, Enter keeps the cloth object, Esc drops it', 'cloth_drape',
     'MOD_CLOTH', 'mecha.cloth_drape', 'OK'),
    ('ZONE', 'Lasso Zone', 'Draw a zone on a Mech / Creature part (any shape, Corners, Line, Sketch, Slow Line, '
     'Surface - like Cut): Paint - its own paint, projected; Split - edges cut along it, a material of its own. '
     'From the Mech / Creature page (Zones)', 'mask', 'MOD_MASK', 'mecha.lasso_zone', 'OK'),
    ('WLINES', 'Wrinkle Lines', 'Draw guide lines on a mesh, Space: a short cloth simulation folds the surface '
     'along them (fabric presets, wrinkle size, shrink, gravity, silhouette keep); Enter keeps, Esc goes back',
     'wrinkle_lines', 'MOD_CLOTH', 'mecha.wrinkle_lines', 'OK'),
    ('PRIMITIVE', 'Primitive', 'Ghost shape with handles: Enter = merge into the mesh it touches, Alt+Enter = '
     'subtract; Station Primitive presets; RMB = shape picker',
     'primitive', 'MESH_CUBE', 'mecha.primitive', 'OK'),
    ('BOOLEAN', 'Boolean', 'Difference / Union / Intersect with a selected cutter mesh', 'boolean', 'MOD_BOOLEAN', None, 'OK'),
    ('BBEVEL', 'Boolean Bevel', 'Drag along an edge of a part: that much of it is cut off by a boolean - a chamfer or a '
     'round, Width wide (click: the whole edge); the edges you can use are shown', 'bool_bevel', 'MOD_BEVEL',
     'mecha.bool_bevel', 'OK'),
    ('FUSE', 'Smart Fuse', 'Union two overlapping meshes with a fillet/chamfer seam', 'fuse', 'MOD_BEVEL', None, 'PARTIAL'),
    # 0.24.280 (user: "SDF 빌더 한번 만들어 줘")
    # 0.24.284 (user: "지브러시의 플래너처럼 - 그 부근의 평평한 면으로 밀어 버렸으면")
    ('PLANAR', 'Clean (Planar)', 'Draw an outline over a sculpted part: the surface you see inside it is pushed onto '
     'one flat plane, like ZBrush Planar (Both / Cut / Fill, Soft Edge); the mesh stays as it is (no remesh)',
     'planar', 'MOD_SMOOTH', 'mecha.clean_planar', 'OK'),
    # 0.24.286 (user: "선택하는 영역의 엣지 크리즈를 클릭하면 지워지는 엣지 클리어")
    ('ECLEAR', 'Edge Clear', 'Click a creased edge of a part: its crease (and sharp mark) is cleared - the whole line '
     '(Shift: only that edge); the creased edges are shown', 'eclear', 'X', 'mecha.edge_clear', 'OK'),
    ('SDF', 'SDF Builder', 'A stack of parts made one shape through distance fields: each Union / Subtract / '
     'Intersect with a Blend (soft fillets and grooves); coarse in the viewport, fine in a render; live, Make Real',
     'sdf', 'META_BALL', None, 'OK'),
    ('MIRROR', 'Symmetry', 'Symmetry: lean the mouse to the side to copy to, Enter applies (left buttons: live Mirror)', 'mirror', 'MOD_MIRROR', None, 'OK'),
    ('MASK', 'Mask', 'Paint a face mask with the shared shapes (Alt: erase)', 'mask', 'MOD_MASK', 'mecha.mask', 'PARTIAL'),
    ('ARRAY', 'Curve Array', 'Repeat a part along a drawn curve', 'array', 'MOD_ARRAY', None, 'OK'),
    ('RADIAL', 'Radial Array', 'Radial copies around the 3D cursor + Boolean', 'radial', 'MOD_SCREW', None, 'OK'),
    # 0.24.279 (user: "직선이나 대각선 토글도 되고 내가 긋는 직선대로 어레이되는 툴 - 라쏘 · 오토 셀렉트 액티브 다")
    ('LARRAY', 'Line Array', 'Draw from a part: copies of it along the line - Straight (Free / Straight / Diagonal snap) '
     'or Follow the drawn path, round a drawn outline; Count or Spacing, Align; Targets Auto / Selected / Active; live, '
     'Enter makes it real', 'larray', 'MOD_ARRAY', 'mecha.line_array', 'OK'),
    # 0.24.297 (user: "어레이컷 - 스케치 모드가 기본, 쉬프트 누르고 라인 그으면 어레이 가이드 - 직선 / 프리드로우 / 원 / 박스")
    ('ACUT', 'Array Cut', 'Draw the shape (a sketch), Shift + draw the guide (Line / Free / Circle / Box): the shape is '
     'cut along it - Count, Spacing, End Size (smaller toward the end), Align; live, Enter keeps it',
     'acut', 'MOD_ARRAY', 'mecha.array_cut', 'OK'),
    # 0.24.294 (user: "직선 어레이 메뉴처럼 스프링 제네레이터도 - 그으면 스프링, 두께 · 폭은 추후에 정해서 엔터나 어플라이로 확정")
    ('SPRING', 'Spring', 'Draw a line: a coil spring along it (Straight / Follow, end to end between two parts); '
     'Width, Wire, Coils, Closed Ends, End Width, Round / Square / Flat wire - live, Enter or Apply keeps it',
     'spring', 'MOD_SCREW', 'mecha.spring', 'OK'),
    # 0.24.306 (user: "타이어 제네레이터도 메뉴로 빼주고 거기에 톱니도 추가해줘")
    ('TIREGEN', 'Tire & Gear', 'Summon a tire, its wheel or a gear (teeth, depth, width, Square / Trapezoid / Round / '
     'Saw, hole) at the 3D cursor - the sliders change the selected one live; draw a piece on it, Array Around',
     'tiregear', 'PREFERENCES', 'mecha.tire_gear', 'OK'),
    # 0.24.307 (user: "실린더 메뉴 ... 두께랑 그런거 수정하고 위아래 레이어 분리" / "연결 부위도 나사 박히는 부분 내가 사이즈 조정")
    ('CYLGEN', 'Cylinder', 'Summon a cylinder (an actuator): a Round or Square body and a rod sliding out of it, a mount '
     '(Eye / Clevis) at each end - its size, thickness, hole and bolt; Length, Width, Body / Rod / Cap proportions - '
     'live while selected',
     'cylgen', 'MESH_CYLINDER', 'mecha.cylinder_gen', 'OK'),
    # 0.24.308 (user: "나사는 박히는 메뉴로 바꾸자 ... 육각도 ... 깍이는 부분도 쳄퍼랑 베벨 아니면 그냥 깍이기")
    ('BOLT', 'Bolt Insert', 'Click a surface: a round pocket cut there (Plain / Chamfer / Bevel rim) and a bolt set in '
     'it (Hex / Round / Socket head, threaded shank) - live while selected; Alt + click removes. Also: Screw Stack',
     'bolt', 'MOD_BOOLEAN', 'mecha.bolt_insert', 'OK'),
    # 0.24.313 (user: "점 두 개 찍으면 생기는 전선도 ... 넓은 전선, 얇은 거 한 개, 여러 개, 두꺼운 거에 얇은 거, 와이어 뭉쳐 있는 전선")
    ('WIRE', 'Wire Harness', 'Click a surface, then another: a wire between them - Flat Ribbon, Single Wire, Thin Wires, '
     'Thick + Thin, Wire Loom (tied); Length, Gravity, Twist, Bend Left / Right, Front / Back - live while selected',
     'wire', 'OUTLINER_OB_CURVES', 'mecha.wire_gen', 'OK'),
    # 0.24.315 (user, mech leg / arm photos: "관절 메뉴도 만들어 줘, 관절 제네레이터야")
    ('JOINT', 'Joint Generator', 'Summon a joint: Fork, Side Plates, Tube Frame, Ball Joint or Universal - a drum with '
     'caps and bolts, upper / lower links, Bend (live), a piston between the links',
     'joint', 'CON_PIVOT', 'mecha.joint_gen', 'OK'),
    ('DRAW', 'Mesh Curve', 'Draw a curve and sweep a profile along it (or a panel-line cut); '
     'smooth/straight points, resolution, rotation, twist', 'panel', 'CURVE_BEZCURVE', None, 'OK'),
    ('POSE', 'Deform', 'Lattice Cage / Bend Curve: click control points and Move / Rotate / Scale them with '
     'falloff (rotate a Bend point = local twist); non-destructive until Apply. Rigid pose not yet supported',
     'deform', 'MOD_LATTICE', None, 'PARTIAL'),
    ('EXTRACT', 'Face Extract', 'Edit Mode: selected faces -> a separate part. Basic Extract (height, thickness, '
     'chamfer width / angle / depth, bevel, outer edge) or Armor Sculpt (N/E/S/W thickness and edges, centre ridge)',
     'extract', 'FACESEL', None, 'OK'),
    # 0.24.183 (user: "메카 표면 디테일 홀은 다른 메쉬에 라쏘로 그릴 수 있게 서페이스 디테일로")
    ('MHOLE', 'Mecha Holes', 'Draw an outline on a part: a panel of holes on it - a raised frame round it, the floor '
     'recessed, holes in rows (Square, Round, Hex, Slots, Diamond, Hex Tiles); live, Enter keeps it', 'mhole',
     'MOD_LATTICE', 'mecha.mecha_holes', 'OK'),
    ('FPOP', 'Face Pop', 'Click faces of a part: they stand out (Height, Taper); drag over faces: each one; Alt: '
     'off.  Live until Apply', 'face_pop', 'FACESEL', 'mecha.face_pop', 'OK'),
    ('MOLDING', 'Edge Molding', 'Drag along a mesh: a molding profile along the line, on its surface; click a part: '
     'along its edges (rim or sharp edges); also face outlines / edges picked in Edit Mode, panel outlines, the Armor '
     'centre line', 'molding', 'MOD_CURVE', 'mecha.edge_molding', 'OK'),
    ('HOLLOW', 'Hollow / Shell', 'Hollow shell with wall thickness, direction, rim and openings (live Solidify)',
     'hollow', 'MOD_SOLIDIFY', None, 'OK'),
    ('ALONG', 'Mesh Along Curve', 'Curve Deform and Curve Array (rigid / deform), Free or World X/Y/Z curve base line',
     'along', 'MOD_ARRAY', None, 'OK'),
    ('CABLE', 'Cable', 'Two-point cables between mesh surfaces, Edge to Cable, thickness / profile / sag / twist',
     'cable', 'OUTLINER_OB_CURVE', None, 'OK'),
    ('TUBE', 'Mesh Curve', 'Nomad-style curve: click points (on the mesh or in the air), a live solid tube right '
     'away - radius per point, profile, cap, hole, twist - or Repeat your own (linked) object along it with spacing',
     'tube', 'CURVE_BEZCURVE', None, 'OK'),
    ('TUBE_SAME', 'Line Curve', 'Click points: a tube of one thickness everywhere (no per-point size) - Thickness '
     'makes all of it thicker / thinner; profile, cap, closed, twist like Mesh Curve; live until Apply',
     'line_curve', 'CURVE_BEZCURVE', None, 'OK'),
    ('LOFT', 'Loft / Surface', 'Smooth surface through 2+ curves, or sweep a profile along a path (live)',
     'loft', 'SURFACE_DATA', None, 'PARTIAL'),
    ('ZBRUSH', 'ZBrush Bridge', 'Send selected objects to ZBrush as OBJ files and import them back (not GoZ)',
     'zbrush', 'EXPORT', None, 'PARTIAL'),
    ('SURFACE', 'Surface Conform', 'Snap / wrap a part onto a surface', 'surface', 'MOD_SHRINKWRAP', None, 'OK'),
    ('LIBRARY', 'Assets', 'Save / insert reusable mesh parts and profiles', 'assets', 'ASSET_MANAGER', None, 'OK'),
    ('REMESH', 'Remesh', 'Voxel remesh + smooth, sculpt Move', 'remesh', 'MOD_REMESH', None, 'OK'),
    ('EDIT', 'Live Result', 'Confirm live curves / arrays / cuts', 'live', 'CHECKMARK', None, 'OK'),
)
TOOL_BY_ID = {t[0]: t for t in TOOLS}
# v0.10 (B08/F07): Mask does not work reliably for the user -> hidden from the
# tool list, Space / V menus, toolbar and hotkeys.  Its code, operators and
# all saved mask data (face attributes, vertex groups) are kept untouched.
HIDDEN_TOOLS = {'MASK', 'DRAW'}     # 0.23.2: the old Mesh Curve (DRAW) is replaced by the Tube tool
HIDDEN_TOOLS |= {'ZONE'}           # 0.24.95 Lasso Zone: from the Mech / Creature page's Zones (Paint Zone / Split Zone)
# 0.24.31: the new cloth tools (Clothing / Hood / Scarf, and the Edit Mode Quad Cloth panel) are still being tuned:
# hidden from every menu and the toolbar.  Their code and saved live objects are kept; True brings them back.
EXPERIMENTAL_CLOTH = False
EXPERIMENTAL_CLOTH_TOOLS = {'GARMENT', 'HOOD', 'SCARF'}
if not EXPERIMENTAL_CLOTH:
    HIDDEN_TOOLS |= EXPERIMENTAL_CLOTH_TOOLS
VISIBLE_TOOLS = tuple(t for t in TOOLS if t[0] not in HIDDEN_TOOLS)
# V quick menu (docs/02): the six core tools (+ Armor Plate since 0.19).
QUICK_TOOLS = ('CUT', 'BOOLEAN', 'BASE', 'SUBD', 'SPLIT', 'RADIAL', 'PLATE')   # 0.19: + Armor Plate
NATIVE_TO_TOOL = {t[5]: t[0] for t in TOOLS if t[5]}
SHAPE_TOOLS = {'CUT', 'SPLIT', 'MASK', 'BASE', 'CBASE', 'PLATE', 'CPLATE', 'WRINKLE', 'CDRAPE', 'ZONE', 'HIDE', 'DETAIL', 'DETAIL2',
               'DETAIL3', 'DETAIL4', 'BELT', 'SPIKE', 'SCALES', 'SBRUSH', 'BRIDGE', 'FLOWER', 'SCURVE', 'CAPE', 'SCAPE', 'HAIR', 'GARMENT', 'HOOD', 'SCARF', 'SDRAW',
               'FUR', 'WING', 'OMASS', 'MHOLE', 'MEMBRANE', 'WDIRT', 'WDUST', 'WLEAF', 'WSNOW', 'PCUT', 'LARRAY',
               'PLANAR', 'SPRING', 'ACUT'}

DRAW_TOOLS = SHAPE_TOOLS | {'PRESS'}      # 0.24.95 + Press Cut (Shift + draw its stamp): the lasso settings it keeps
DRAW_TOOLS |= {'GREEBLE', 'CGREEBLE'}   # 0.24.154 + Greeble / Scale Line (Shift + draw a part)

# 0.24.55 the tool list by job (about 10 groups instead of one long list); a tool not listed goes to Other
TOOL_GROUPS = (
    ('Block-out', ('BASE', 'MBASE', 'CBASE', 'OMASS', 'SUBD', 'PRIMITIVE', 'TIREGEN', 'CYLGEN', 'JOINT')),
    ('Cut', ('CUT', 'SPLIT', 'PRESS', 'ACUT', 'HIDE', 'BOOLEAN', 'BBEVEL', 'FUSE', 'SDF', 'PLANAR', 'ECLEAR', 'PERF')),
    ('Surface detail', ('GSCULPT', 'GREEBLE', 'PLATE', 'MPLATE', 'DETAIL', 'DETAIL2', 'DETAIL3', 'SDRAW', 'SCREW', 'BOLT', 'EXTRACT', 'FPOP', 'MHOLE', 'MOLDING', 'BELT')),
    ('Move', ('CMOVE', 'CPATH', 'SMOVE', 'SMART', 'POSE', 'RIG', 'REMESH')),   # 0.24.241 + Rig (beside Pose)
    ('Symmetry & repeat', ('MIRROR', 'RSYM', 'RADIAL', 'ARRAY', 'LARRAY')),
    ('Curves', ('TUBE', 'TUBE_SAME', 'SCURVE', 'CABLE', 'WIRE', 'SPRING', 'MMUSCLE', 'ALONG', 'LOFT')),
    ('Creature', ('CPLATE', 'DETAIL4', 'CGREEBLE', 'FGREEBLE', 'SPIKE', 'SCALES', 'SBRUSH', 'BRIDGE', 'FLOWER', 'HAIR', 'FUR', 'WING', 'MEMBRANE', 'BODYKIT', 'MUSCLE')),
    ('Weathering', ('WDIRT', 'WDUST', 'WLEAF', 'WSNOW')),                  # 0.24.158 click a shape: dirt / dust / ...
    ('3D Print', ('PMEASURE', 'PCUT')),                                    # 0.24.164 measure; cut with connection pins
    ('Cloth', ('WRINKLE', 'CDRAPE', 'MEMBRANE', 'WLINES', 'CAPE', 'SCAPE', 'GARMENT', 'HOOD', 'SCARF')),
    ('Utility', ('HOLLOW', 'ZBRUSH', 'SURFACE', 'LIBRARY', 'EDIT')),
)


def grouped_tools(tools=None):
    """[(group name, [tool rows])] of the visible tools, in TOOL_GROUPS order; the rest under 'Other'."""
    tools = list(tools if tools is not None else VISIBLE_TOOLS)
    by_id = {t[0]: t for t in tools}
    out, seen = [], set()
    for name, ids in TOOL_GROUPS:
        rows = [by_id[i] for i in ids if i in by_id]
        seen.update(t[0] for t in rows)
        if rows:
            out.append((name, rows))
    rest = [t for t in tools if t[0] not in seen]
    if rest:
        out.append(('Other', rest))
    return out

# Enum numbers keep v0.5.9 values so saved .blend files map to the same tool.
_ENUM_NUMBERS = {'CUT': 1, 'BOOLEAN': 2, 'FUSE': 3, 'MIRROR': 4, 'MASK': 5, 'DRAW': 6,
                 'ARRAY': 7, 'RADIAL': 8, 'SURFACE': 9, 'LIBRARY': 10, 'EDIT': 11,
                 'REMESH': 12, 'SPLIT': 13, 'POSE': 14, 'BASE': 15, 'LOFT': 16, 'ZBRUSH': 17, 'SUBD': 18, 'PRIMITIVE': 19,
                 'EXTRACT': 20, 'MOLDING': 21, 'HOLLOW': 22, 'ALONG': 23, 'CABLE': 24, 'PLATE': 25, 'WRINKLE': 26, 'TUBE': 27,
                 'HIDE': 28, 'DETAIL': 29, 'DETAIL2': 30, 'SCREW': 31, 'DETAIL3': 32, 'TUBE_SAME': 33,
                 'CBASE': 34, 'CPLATE': 35, 'BELT': 36, 'SPIKE': 37, 'SCALES': 38, 'FLOWER': 39, 'SCURVE': 40, 'SBRUSH': 41, 'BRIDGE': 42, 'CAPE': 43, 'HAIR': 44, 'GARMENT': 45, 'HOOD': 46, 'SCARF': 47, 'CMOVE': 48, 'CPATH': 50, 'PERF': 51, 'SDRAW': 52, 'SCAPE': 53, 'RSYM': 55, 'SMOVE': 56, 'WLINES': 57, 'CDRAPE': 58, 'ZONE': 59, 'PRESS': 60, 'SMART': 61, 'GSCULPT': 62, 'GREEBLE': 63, 'CGREEBLE': 64, 'FUR': 65, 'WDIRT': 66,
                 'WDUST': 67, 'WLEAF': 68, 'WSNOW': 69, 'DETAIL4': 70, 'PMEASURE': 71, 'PCUT': 72, 'FGREEBLE': 73, 'WING': 74, 'MEMBRANE': 75, 'BBEVEL': 76, 'FPOP': 77, 'OMASS': 78, 'MUSCLE': 79, 'MMUSCLE': 80, 'MHOLE': 81, 'BODYKIT': 82, 'RIG': 83, 'LARRAY': 84, 'SDF': 85, 'PLANAR': 86, 'ECLEAR': 87, 'SPRING': 88, 'ACUT': 89, 'MBASE': 90, 'MPLATE': 91, 'TIREGEN': 92, 'CYLGEN': 93, 'BOLT': 94, 'WIRE': 95, 'JOINT': 96}   # 54: the removed Cloth Wrap (kept free)   # 49: the removed Jungle Gym prototype (0.24.31), kept free
TOOL_ENUM_ITEMS = [(t[0], t[1], t[2], t[4], _ENUM_NUMBERS[t[0]]) for t in TOOLS]

SHAPES = (
    ('LASSO', 'Lasso', 'Straight-segment outline: click point by point (draw freely with Free Draw). '
     'Double-click anywhere closes and applies. 2 points = straight line cut', 'lasso', 'GP_SELECT_POINTS'),
    ('CURVE_LASSO', 'Curve Lasso', 'Smooth closed spline through control points from the start. '
     'Click a point: sharp/smooth, drag points or Bezier handles. Double-click anywhere closes',
     'curve_lasso', 'CURVE_BEZCURVE'),
    ('RECT', 'Rectangle', 'Drag a rectangle (Shift square, Ctrl from center)', 'rect', 'MESH_PLANE'),
    ('CIRCLE', 'Circle', 'Drag from center to radius', 'circle', 'MESH_CIRCLE'),
    ('ELLIPSE', 'Ellipse', 'Drag an ellipse box (Shift circle, Ctrl from center)', 'ellipse', 'MESH_UVSPHERE'),
    ('STROKE', 'Free Draw', 'Hold LMB and draw continuously; release applies. Cut/Split/Base Mesh: closed '
     'freehand outline. Mask: open brush stroke', 'stroke', 'GREASEPENCIL'),
    ('CUSTOM', 'Custom', 'Imported PNG vector shape: click = stamp, drag = size', 'custom', 'IMAGE_DATA'),
)
SHAPE_BY_ID = {s[0]: s for s in SHAPES}
SHAPE_ENUM_ITEMS = [(s[0], s[1], s[2], s[4], i) for i, s in enumerate(SHAPES)]


def is_mecha_workspace(workspace):
    if workspace is None:
        return False
    try:
        return bool(workspace.get(WORKSPACE_TAG)) or workspace.name.startswith(WORKSPACE_NAME)
    except ReferenceError:
        return False


def find_mecha_workspace():
    for ws in bpy.data.workspaces:
        if ws.get(WORKSPACE_TAG):
            return ws
    for ws in bpy.data.workspaces:
        if ws.name.startswith(WORKSPACE_NAME):
            return ws
    return None


def native_tool_id(context):
    try:
        tool = context.workspace.tools.from_space_view3d_mode('OBJECT', create=False)
    except (AttributeError, TypeError, RuntimeError):
        return ''
    return tool.idname if tool else ''


# 0.24.305 the Mold tools run as their original (every BASE / PLATE path); ``mold_on`` tells them apart
ALIAS = {'MBASE': 'BASE', 'MPLATE': 'PLATE'}


def mold_on(context):
    """0.24.305 The tool in use is Mold Base Mesh / Mold Armor Plate (the moldings shown and used)."""
    try:
        return _raw_tool(context) in ALIAS
    except (AttributeError, KeyError, TypeError):
        return False


def effective_tool(context):
    """The tool in use (a Mold tool as the tool it copies)."""
    t = _raw_tool(context)
    return ALIAS.get(t, t)


def _raw_tool(context):
    """Native drawing tool wins (it is what LMB does); else the selected tool."""
    native_id = native_tool_id(context)
    native = NATIVE_TO_TOOL.get(native_id)
    settings = getattr(getattr(context, 'scene', None), 'mch_settings', None)
    if native:
        chosen = settings.mch_active_tool if settings else native
        try:
            stuck = settings is not None and settings.get('mch_native_at_choice') == native_id
        except (AttributeError, TypeError):
            stuck = False
        if stuck and chosen != native and TOOL_BY_ID[chosen][5] is None:
            # The user picked a non-drawing tool but the toolbar could not be
            # switched: the explicit choice wins (the panel follows it and the
            # drawing tool does not grab LMB, see cut_engine.StrokeLogic.invoke).
            return chosen
        return native
    chosen = settings.mch_active_tool if settings else 'CUT'
    # (a hidden tool chosen: Cut - but the Lasso Zone stays itself after Esc, as the other drawing tools do)
    return 'CUT' if chosen in HIDDEN_TOOLS - {'ZONE'} else chosen


def sidebar_select(context):
    """0.23.24 the general sidebar extras (Primitive Shapes, Detail Stamp, High Poly, icon size, hotkeys ...)
    only in Select mode - with a tool chosen the sidebar shows just that tool."""
    try:
        from . import bottom_bar
        return bool(bottom_bar.in_select(context))
    except (AttributeError, KeyError, TypeError, ImportError):
        return True


def hud_for(context, tools):
    """0.23.21 a tool's HUD (buttons / sliders next to its result) only while that tool is chosen - like
    the Mirror buttons; switching to another tool hides it (the result itself stays)."""
    try:
        return effective_tool(context) in tools
    except (AttributeError, KeyError, TypeError):
        return True


def hud_labels_ok(context, tools):
    """0.24.146 (user: "이거 글씨 안 뜨게 해 줘" - a plate's HUD names floating in the Cut tool) the words beside a HUD's
    buttons / sliders only when those are drawn: that tool chosen and the viewport's gizmos on."""
    if not hud_for(context, tools):
        return False
    space = getattr(context, 'space_data', None)
    return bool(getattr(space, 'show_gizmo', True))


DRAFT = [False]          # 0.24.95 live_queue: a slider drag is rebuilding a slow part - the Preview Resolution


def res_scale(context=None):
    """0.24.95 the global Resolution (scene.mch_settings.geo_res, %) as a factor: 1.0 = every tool as set.  While
    live_queue rebuilds during a drag (DRAFT) it is held at the Preview Resolution."""
    try:
        st = (context or bpy.context).scene.mch_settings
        s = max(0.1, float(st.geo_res) / 100.0)
        if DRAFT[0] and st.geo_draft:
            s = min(s, max(0.1, float(st.geo_draft_res) / 100.0))
        return s
    except Exception:
        return 1.0


def draft_differs(context=None):
    """Fast Preview would change something: on, and the Preview Resolution under the Resolution."""
    try:
        st = (context or bpy.context).scene.mch_settings
        return bool(st.geo_draft) and st.geo_draft_res < st.geo_res
    except Exception:
        return False


def res_n(n, lo=1, hi=None, context=None):
    """A segment / sample count x the global Resolution (at least ``lo``, at most ``hi``); n itself at 100 %."""
    s = res_scale(context)
    if s == 1.0:
        v = int(n)
    else:
        v = max(int(lo), int(round(n * s)))
    return min(v, int(hi)) if hi is not None else max(v, int(lo))


def tool_is(context, tool_id):
    return bool(getattr(context, 'scene', None) and hasattr(context.scene, 'mch_settings')
                and effective_tool(context) == tool_id)


class MCH_PG_Brush(bpy.types.PropertyGroup):
    shape: EnumProperty(name='Shape', items=SHAPE_ENUM_ITEMS, default='LASSO')
    circle_segments: IntProperty(name='Circle Segments', default=64, min=8, max=512,
                                 description='Real geometric resolution of circles/ellipses (not shading)')
    curve_resolution: IntProperty(name='Curve Samples', default=12, min=2, max=64,
                                  description='Samples per Curve Lasso span (between two control points)')
    curve_smoothness: FloatProperty(name='Curve Smoothness', default=1.0, min=0.0, max=2.0,
                                    description='Tangent length of automatic (Catmull-Rom) control points')
    outline_corner: EnumProperty(name='Outline Corners', items=[
        ('NONE', 'Sharp', 'Keep drawn corners'),
        ('ROUND', 'Round', 'Round the corners of the 2D outline (Lasso / Rectangle)'),
        ('CHAMFER', 'Chamfer', 'Straight-cut the corners of the 2D outline (Lasso / Rectangle)')],
        default='NONE', description='2D shape option, separate from the 3D Edge Finish of the cut')
    outline_radius: FloatProperty(name='Corner Width (px)', default=12.0, min=0.0, max=500.0)
    outline_segments: IntProperty(name='Corner Segments', default=6, min=1, max=32)
    stroke_smooth: IntProperty(name='Free Draw Smoothing', default=2, min=0, max=10,
                               description='Smoothing passes applied to the drawn freehand path')
    stroke_spacing: FloatProperty(name='Stroke Spacing (px)', default=4.0, min=1.0, max=50.0,
                                  description='Free Draw: a new outline point every N pixels of (stabilized) movement')
    stab_enable: BoolProperty(name='Slow Line (Lazy Mouse)', default=False,
                              description='Careful lines: while you hold and drag (Free Draw, Line strokes, the Path '
                                          'Move path) the line follows the mouse slowly and smoothly - every '
                                          'drawing tool. OFF = exact previous behaviour')
    stab_strength: FloatProperty(name='Smoothing Strength', default=50.0, min=0.0, max=100.0, subtype='PERCENTAGE',
                                 description='Higher = smoother but slower follow (time based, same feel at any '
                                             'mouse rate). Applies immediately, also while drawing')
    stab_radius: FloatProperty(name='Lazy Radius (px)', default=20.0, min=0.0, soft_max=80.0, max=200.0,
                               description='The line does not move while the cursor stays inside this circle; '
                                           'outside, it is pulled along on the circle edge')
    stab_guide: BoolProperty(name='Show Lazy Guide', default=True,
                             description='Draw the lazy circle and the cursor-to-line string while drawing')
    mask_brush_radius: FloatProperty(name='Mask Brush Radius (px)', default=18.0, min=1.0, max=200.0,
                                     description='Pixel radius for Brush Stroke in Mask mode')
    stroke_simplify: FloatProperty(name='Simplify (px)', default=1.0, min=0.0, max=10.0,
                                   description='Removes mouse jitter from Brush Stroke outlines')
    custom_size: FloatProperty(name='Stamp Radius (px)', default=120.0, min=4.0, max=4000.0,
                               description='Screen radius used when the Custom shape is clicked without dragging')
    custom_rotation: FloatProperty(name='Stamp Rotation', default=0.0, subtype='ANGLE')
    custom_drag_rotate: BoolProperty(name='Rotate With Drag', default=False,
                                     description='Dragging a Custom shape also rotates it')
    line_open: BoolProperty(name='Open Line (F)', default=False,
                            description='Lasso points form an open line across the mesh instead of a closed outline')
    line_mode: BoolProperty(name='Line', default=False,
                            description='Lasso / Curve Lasso / Stroke draw a LINE: the tool uses a band of Line Width '
                                        'around the path instead of the enclosed area')
    line_width: FloatProperty(name='Line Width', default=0.02, min=0.0005, soft_max=2.0, max=20.0, unit='LENGTH',
                              precision=4, description='Width of the band drawn in Line mode')   # 0.24.59 soft 0.5 -> 2
    # 0.24.143 (user: "아머 플레이트, 서페이스 드로우, 플레이트 디테일 시리즈, 크리쳐 플레이트에 모두 끝부분 뾰족해지고 끝부분이
    # 둥글어지는 테이퍼 그 옵션 넣어 줘") a third kind of end: Pointed (the band thins to a point - Taper Amount)
    line_caps: EnumProperty(name='Line Ends', items=[('ROUND', 'Round', 'Round line ends'),
                                                     ('FLAT', 'Flat', 'Square line ends'),
                                                     ('POINT', 'Pointed', 'The line thins to a point at both ends '
                                                                         '(how far in: Taper Amount)')], default='ROUND')
    # 0.24.108 (user: "선이 둘러싼 전체 영역을 하나의 도형으로") the region the line encloses becomes the shape
    line_area: BoolProperty(name='Area', default=False,
                            description='Line mode: when the line closes on itself or crosses itself, the whole '
                                        'region it encloses is the shape (off: the line stays a band - a closed '
                                        'stroke is a ring).  With the Sketch: the region all the strokes enclose')
    # 0.24.21 like a pen: the line thins to a point at both ends (Taper) and / or follows the tablet pressure
    line_taper_on: BoolProperty(name='Taper', default=False,
                                description='Line mode: the band thins to a point toward both ends (amount next to it)')
    line_taper: FloatProperty(name='Taper Amount', default=0.5, min=-1.0, max=1.0,
                              description='How much of the line thins toward the ends (1 = pointed over the whole '
                                          'length).  Below 0 (minus taper): the ends flare out instead - wider '
                                          'toward the ends (-1 = twice as wide there)')
    line_pressure: BoolProperty(name='Pressure', default=False,
                                description='Line mode, Free Draw: the band is as wide as you press the pen '
                                            '(tablet pressure); [ / ] change Line Width')
    surface_mode: BoolProperty(name='Surface', default=False,
                               description='Cut / Split / Armor Plate / Cloth Plate: click points ON the mesh (they '
                                           'stay on it when you orbit); Enter applies (Cut / Split: a loop around a '
                                           'part splits it off; plates: the outline on the surface)')
    through_mode: BoolProperty(name='Through', default=False,
                               description='Armor / Cloth Plate: the outline goes through the mesh - the back is '
                                           'taken too (every layer inside the outline); split into panels where '
                                           'it turns away from the view and at sharp creases')
    through_crease: FloatProperty(name='Crease', default=50.0, min=5.0, max=180.0, precision=0,
                                  description='Through: a fold sharper than this splits the panels (a seam), '
                                              '180 = never')
    surface_gap: FloatProperty(name='Cut Gap', default=0.0005, min=0.0, soft_max=0.02, max=1.0, unit='LENGTH',
                               precision=4, description='Gap between the parts split by the Surface Lasso')
    sketch_first: BoolProperty(name='Sketch', default=False,
                               description='Lasso tools: draw outlines into a sketch, Alt+draw subtracts, '
                                           'Enter applies (Alt+Enter: Alt action), Backspace: last, Esc: clear')


def _ramp_refresh_update(self, context):
    """0.24.46 a Cut Ramp slider moved: the live ramp (if any) is carved again (0.24.56: or the last cut)."""
    try:
        from . import ramp_edit
        ramp_edit.refresh_later(context, ('cut', 'cutlive'))      # 0.24.83 from a timer, not in the update
    except Exception:          # a slider must never fail
        pass


def _live_cut_update(self, context):
    """0.24.56 a Cut / GN Edge setting changed: the last cut (still live) is cut again with it."""
    try:
        from . import ramp_edit
        ramp_edit.refresh_later(context, 'cutlive')                # 0.24.83 from a timer, not in the update
    except Exception:          # a slider must never fail
        pass


class MCH_PG_Cut(bpy.types.PropertyGroup):
    depth_mode: EnumProperty(name='Depth', items=[
        ('THROUGH', 'Through All', 'Cut through the whole object along the view'),
        ('SURFACE', 'From Surface', 'Pocket of fixed depth starting at the surface under the shape')],
        default='THROUGH', update=_live_cut_update)
    depth: FloatProperty(name='Cut Depth', default=0.1, min=0.00001, soft_max=10.0, precision=4,
                         unit='LENGTH', update=_ramp_refresh_update)
    depth_floor: EnumProperty(name='Floor', default='FLAT', update=_live_cut_update, items=[
        ('FOLLOW', 'Follow', 'As deep below the surface everywhere under the shape, however the part is turned to the view'),
        ('LEVEL', 'Level', 'A flat floor at the depth below the point you press: everything higher under the shape - '
                           'a raised face beside it - is cleared down to it'),
        ('FLAT', 'Flat', 'A flat floor across the view from the point you press; higher faces under the shape are left '
                         'standing (seen at an angle: a lip of the near side)')],
                              description='From Surface: how deep the pocket floor is under the shape')
    targets: EnumProperty(name='Targets', items=[
        ('AUTO', 'Auto Target', 'Every mesh the drawn shape covers, whatever is selected: keep the tool and cut the '
                                'next part directly (T toggles)'),
        ('SELECTED', 'Selected Only', 'Only the selected meshes the shape covers (cut several chosen parts at once)'),
        ('ACTIVE', 'Active', 'Only the active mesh (or the mesh under the cursor)')], default='AUTO',
        description='Auto Target (default since 0.12): the shape decides what is cut. Selected Only: the selection does')
    solver: EnumProperty(name='Solver', items=[
        ('AUTO', 'Auto', 'Closed mesh: fast Manifold solver, Exact as fallback. Open mesh: Exact'),
        ('EXACT', 'Exact', 'Blender Exact solver only'),
        ('MANIFOLD', 'Manifold', 'Fast manifold solver (needs closed input)'),
        ('FAST', 'Float', 'Legacy fast solver (least robust)')], default='AUTO')
    # 0.24.278 (user: "클로스 ... 스플릿이랑 컷 해서 ... 자르면 오류" -> 9번 "ㄱㄱ") a thin sheet thickened before a cut
    sheet_thick: BoolProperty(name='Thin Sheets: Give Thickness', default=False,
                              description='An open single sheet (a cloth, a plane) gets a thin 1.5 mm thickness before '
                                          'Cut / Split - the pieces are thin solids.  Off (as before): a sheet is cut as '
                                          'the sheet it is (the pieces stay single sheets)')
    hole_tolerant: BoolProperty(name='Hole Tolerant', default=False,
                                description='Exact solver option for meshes with holes/non-manifold parts (slower)')
    # 0.24.152 (user: "컷 스플릿 같은 것도 6~7 mil 하이폴에서도 렉 안 걸리게") on by default: a 5.2 M-face part's Cut
    # 41.6 s -> a few seconds; checked against the whole-part boolean (falls back to it when the seam does not close)
    hipoly: BoolProperty(name='High Poly', default=True,
                         description='A dense part (100k faces and more): the boolean runs only on the faces round the '
                                     'shape and is stitched back - many times faster on millions of faces, the rest '
                                     'of the part untouched (it falls back to the whole part when the seam does not '
                                     'close). Off: the whole part goes through the solver')
    edge_finish: EnumProperty(name='Edge Finish', items=[
        ('NONE', 'Off', 'Keep the new cut edges sharp'),
        ('BEVEL', 'Bevel', 'Round only the NEW cut edges'),
        ('CHAMFER', 'Chamfer', 'Flat chamfer on the NEW cut edges only')], default='NONE', update=_live_cut_update)
    finish_width: FloatProperty(name='Width', default=0.01, min=0.0, soft_max=10.0, precision=4,
                                unit='LENGTH', description='Edge Finish width in model units (type any value)',
                                update=_live_cut_update)
    finish_segments: IntProperty(name='Segments', default=3, min=1, max=32, update=_live_cut_update)
    finish_profile: FloatProperty(name='Profile', default=0.5, min=0.0, max=1.0)
    shared_mesh: EnumProperty(name='Shared Mesh', items=[
        ('SINGLE', 'This Object Only', 'Linked duplicates (Alt+D) keep the old mesh; this object gets its own copy'),
        ('ALL', 'All Linked Copies', 'Change the shared mesh data, so every linked duplicate is cut')],
        default='SINGLE')
    split_mode: EnumProperty(name='Split Mode', items=[
        ('NORMAL', 'Normal', 'Thin cut line: two parts touching along the cut'),
        ('GAP', 'Gap', 'Thick blade: removes a strip of Gap Width between the two parts')], default='NORMAL')
    gap_width: FloatProperty(name='Gap Width', default=0.02, min=0.0, soft_max=10.0, precision=4, unit='LENGTH',
                             description='Width of the removed strip in model units, centred on the drawn line')
    side_a_finish: EnumProperty(name='Side A', items=[
        ('NONE', 'None', 'Keep the cut edge sharp'), ('CHAMFER', 'Chamfer', 'Flat chamfer on the cut edge'),
        ('BEVEL', 'Bevel', 'Rounded bevel on the cut edge')], default='NONE',
        description='Side A = the remaining original object')
    side_a_width: FloatProperty(name='Width', default=0.01, min=0.0, soft_max=10.0, precision=4, unit='LENGTH')
    side_a_segments: IntProperty(name='Segments', default=3, min=1, max=32)
    side_b_finish: EnumProperty(name='Side B', items=[
        ('NONE', 'None', 'Keep the cut edge sharp'), ('CHAMFER', 'Chamfer', 'Flat chamfer on the cut edge'),
        ('BEVEL', 'Bevel', 'Rounded bevel on the cut edge')], default='NONE',
        description='Side B = the new "_Split" part')
    side_b_width: FloatProperty(name='Width', default=0.01, min=0.0, soft_max=10.0, precision=4, unit='LENGTH')
    side_b_segments: IntProperty(name='Segments', default=3, min=1, max=32)
    finish_clamp: BoolProperty(name='Clamp Overlap', default=True,
                               description='Limit bevel width where neighbouring edges are short (safe geometry). '
                                           'The result message tells you when the width was limited')
    finish_crisp: BoolProperty(name='Crisp Shading', default=True,
                               description='0.24.24 hard-surface look: the bevel band gets sharp borders (a chamfer is '
                                           'a flat strip, a bevel shades round inside), the cut walls stay flat, and '
                                           'imported custom normals (FBX) are dropped so they do not smear over the '
                                           'new faces')
    # 0.24.41 GN Edge: its own menu - the cut border chamfered / rounded by a Geometry Nodes sweep
    gn_finish: EnumProperty(name='GN Edge', items=[
        ('NONE', 'Off', 'No GN edge'),
        ('CHAMFER', 'Chamfer', 'A straight chamfer swept along the border of the drawn area (Geometry Nodes)'),
        ('BEVEL', 'Bevel', 'A round bevel swept along the border of the drawn area (Geometry Nodes)')],
        default='NONE', description='Geometry Nodes edge: a profile is swept along the new border and carved off - '
                                    'even all the way round (the Edge Finish above is skipped while this is on)',
        update=_live_cut_update)
    gn_width: FloatProperty(name='Width', default=0.01, min=0.0, soft_max=10.0, precision=4, unit='LENGTH',
                            description='How far the GN edge reaches along the surface and down the cut wall',
                            update=_live_cut_update)
    gn_segments: IntProperty(name='Segments', default=4, min=1, max=24, description='Steps round a GN bevel',
                             update=_live_cut_update)
    gn_ramp: BoolProperty(name='Ramp', default=False,
                          description='Cut: the drawn shape carved on a slope instead of a flat-bottomed pocket - deepest '
                                      '(Cut Depth) at the first side drawn, rising back to the surface (the deep side '
                                      'can be changed after: < > / Pick Edge). GN Edge Chamfer / Bevel = the deep wall')
    gn_ramp_length: FloatProperty(name='Ramp Length', default=1.0, min=0.05, max=1.0, subtype='FACTOR',
                                  update=_ramp_refresh_update,
                                  description='How far across the shape the slope goes (1 = meets the surface at the '
                                              'far side)')
    gn_ramp_soft: FloatProperty(name='Ramp Soft', default=0.5, min=0.0, max=1.0, subtype='FACTOR',
                                update=_ramp_refresh_update,
                                description='How softly the slope runs into the surface and the side walls round off')
    gn_ramp_steep: EnumProperty(name='Steep Edges', items=fc.STEEP_ITEMS, default='EVEN', update=_ramp_refresh_update,
                                description='Cut Ramp over a bent edge (each flat face gets its own floor): Even = '
                                            'every face the full depth across it, Limit = the same depth along your '
                                            'view (shallower down a steep side, like before)')
    gn_ramp_res: IntProperty(name='Ramp Resolution', default=20, min=8, max=160, update=_ramp_refresh_update,
                             description='How many points the ramp is built from (more = smoother slope and sides, '
                                         'slower)')
    gn_sides: EnumProperty(name='Split Sides', items=[
        ('BOTH', 'Both', 'Both parts of a Split'), ('A', 'Side A', 'Only the original object'),
        ('B', 'Side B', 'Only the new _Split part')], default='BOTH')
    split_cap: BoolProperty(name='Cap Split', default=True,
                            description='Close the cut faces of both parts (OFF leaves open shells)')
    fast_line: BoolProperty(name='Plane Cut for 2 Points', default=True,
                            description='A two-point line uses a fast plane bisect instead of a Boolean')
    line_cap: BoolProperty(name='Fill Plane Cut', default=True,
                           description='Fill the opening left by a plane cut (closed meshes)')


CLASSES = (MCH_PG_Brush, MCH_PG_Cut)


# -----------------------------------------------------------------------------
# Ctrl+Z must not change the tool UI: the brush shape / stamp / selected Mecha
# tool live in the Scene, so Blender's undo restored the shape picked before
# (user report 0.11.2).  Snapshot them before undo/redo, put them back after.
# -----------------------------------------------------------------------------

UNDO_KEEP = (('mch_brush', 'shape'), ('mch_brush', 'line_open'), ('mch_settings', 'mch_active_tool'),
             (None, 'mch_png_preset'),
             # 0.24.35 brush sizes (F / [ ] / sliders) stay as they are after Ctrl+Z
             ('mch_brush', 'line_width'), ('mch_brush', 'custom_size'), ('mch_brush', 'mask_brush_radius'),
             ('mch_concept', 'radius_px'), ('mch_concept', 'radius_world'), ('mch_concept', 'lock_size'),
             ('mch_screw', 'radius'), ('mch_sdraw', 'width'), ('mch_sdraw', 'height'))
_undo_snapshot = {}


def _owner(scene, group):
    return scene if group is None else getattr(scene, group, None)


def snapshot_ui_state(scene=None):
    scene = scene or bpy.context.scene
    _undo_snapshot.clear()
    if scene is None:
        return
    _undo_snapshot['scene'] = scene.name
    for group, attr in UNDO_KEEP:
        owner = _owner(scene, group)
        if owner is not None and hasattr(owner, attr):
            _undo_snapshot[(group, attr)] = getattr(owner, attr)


def restore_ui_state(scene=None):
    scene = scene or bpy.context.scene
    if scene is None or _undo_snapshot.get('scene') != scene.name:
        return []
    changed = []
    for group, attr in UNDO_KEEP:
        key = (group, attr)
        owner = _owner(scene, group)
        if key not in _undo_snapshot or owner is None or not hasattr(owner, attr):
            continue
        value = _undo_snapshot[key]
        try:
            if getattr(owner, attr) != value:
                setattr(owner, attr, value)
                changed.append(attr)
        except (TypeError, AttributeError, ValueError):
            pass          # e.g. a stamp preset that no longer exists
    return changed


@bpy.app.handlers.persistent
def _on_undo_pre(scene, *_args):
    try:
        snapshot_ui_state(scene)
    except (ReferenceError, AttributeError):
        _undo_snapshot.clear()
    try:                                     # 0.24.65 every tool / sculpt setting (undo_keep)
        from . import undo_keep
        undo_keep.snapshot(scene)
    except (ReferenceError, AttributeError, ImportError, RuntimeError):
        pass


@bpy.app.handlers.persistent
def _on_undo_post(scene, *_args):
    try:
        restore_ui_state(scene)
    except (ReferenceError, AttributeError):
        pass
    try:
        from . import undo_keep
        undo_keep.restore(scene)
        undo_keep.after_restore(scene)
    except (ReferenceError, AttributeError, ImportError, RuntimeError):
        pass


_UNDO_HANDLERS = (('undo_pre', _on_undo_pre), ('redo_pre', _on_undo_pre),
                  ('undo_post', _on_undo_post), ('redo_post', _on_undo_post))


def register():
    for c in CLASSES:
        bpy.utils.register_class(c)
    bpy.types.Scene.mch_brush = bpy.props.PointerProperty(type=MCH_PG_Brush)
    bpy.types.Scene.mch_cut = bpy.props.PointerProperty(type=MCH_PG_Cut)
    for name, fn in _UNDO_HANDLERS:
        lst = getattr(bpy.app.handlers, name)
        if fn not in lst:
            lst.append(fn)


def unregister():
    for name, fn in _UNDO_HANDLERS:
        lst = getattr(bpy.app.handlers, name)
        while fn in lst:
            lst.remove(fn)
    for n in ('mch_cut', 'mch_brush'):
        if hasattr(bpy.types.Scene, n):
            delattr(bpy.types.Scene, n)
    for c in reversed(CLASSES):
        bpy.utils.unregister_class(c)
