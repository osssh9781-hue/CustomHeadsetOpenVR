"""0.24.123 Smart Move: place a part by hand, the way you would in VR, with the mouse and a 3D mouse.

User: "내가 어떤 오브젝트를 클릭해, 그리고 내가 원하는 메시의 표면에 클릭하면 그 위치로 기존의 로테이션 값은 변하지 않고 가,
그리고 내가 그 위치에서 3D 마우스로 그 오브젝트를 로테이션 하는 거야" / "회전축은 오리진 기준으로 하자".

  * LMB on a part          -> it is held (selected, a ring on its origin, hints in the header)
  * LMB on a surface       -> the held part's ORIGIN goes to that point (+ Lift along the surface normal); its rotation and
                              size do not change; click again anywhere to move it again
  * 3D mouse (NDOF) twist  -> the held part turns about its ORIGIN - Turntable (default: twist round the world's up,
                              tilt round the screen's horizontal, like Blender's view), View (a trackball) or World;
                              Speed / Invert in the panel; the view does not move while a part is held
  * 3D mouse push          -> Free (default): left / right and forward / back along the ground as the view sees it, push
                              down / pull up = down / up; "Normal" slides along the last surface normal; X / Y / Z toggles
  * S (holding)            -> Smart Size: the 3D mouse scales the part about its origin instead (push x / y / z = that
                              axis - Local or World axes - twist = all); S again = move
  * Enter / Space / RMB    -> keep (one undo step for the whole hold),  Esc -> the part goes back where it was
  * MMB / wheel / numpad / trackpad -> the view, as always (passed on)

Idle (nothing held) Esc leaves the tool (Select), like every Mecha tool.  Everything the tool needs for a test is plain
math here (``turn_axis``, ``turn_angle``, ``rotate_about``, ``place``, ``cast``); the operator only adds the events.
"""
from __future__ import annotations

import math

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty
from mathutils import Matrix, Vector

RING_COL = (1.0, 0.62, 0.15, 0.95)        # the Move family's orange
HIT_COL = (0.35, 0.8, 1.0, 0.95)
NAV_TYPES = {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE', 'WHEELINMOUSE', 'WHEELOUTMOUSE', 'TRACKPADPAN',
             'TRACKPADZOOM', 'MOUSEROTATE', 'MOUSESMARTZOOM', 'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'}
CONFIRM_TYPES = {'RET', 'NUMPAD_ENTER', 'SPACE', 'RIGHTMOUSE', 'E'}   # (E: the key that started a hold in any tool ends it too)
ACTIVE = [None]       # the running operator (tests / the real-window check look here)
_DRAW = [None]


def _redraw(self, context):
    for w in context.window_manager.windows:
        for a in w.screen.areas:
            if a.type == 'VIEW_3D':
                a.tag_redraw()


class MCH_PG_Smart(bpy.types.PropertyGroup):
    axes: EnumProperty(name='Turn Axes', items=(
        ('BLENDER', 'Blender', '0.24.127 exactly like Blender\'s own 3D-mouse view navigation (its Preferences: orbit style, '
                               'navigation mode, sensitivities, dead zone): the part moves the way the scene moves under the view'),
        ('TURNTABLE', 'Turntable', '0.24.125 like Blender\'s view turning: twist = round the world\'s up (Z, a turntable), '
                                   'tilt = round the screen\'s horizontal, roll = round the view axis'),
        ('VIEW', 'View', 'The 3D mouse turns the part about the axes of the view you look through (tilt = up / down on '
                         'screen, twist = round the screen\'s up - tilted with the view, a trackball)'),
        ('WORLD', 'World', 'The 3D mouse turns the part about the world axes (twist = round Z up, tilt = round X), '
                           'whatever the view'),
        ('LOCAL', 'Local', '0.24.126 the 3D mouse turns the part about its OWN axes (twist = round its Z, tilt = round its X, '
                           'roll = round its Y), however it is turned')), default='BLENDER', update=_redraw)
    speed: FloatProperty(name='Speed', description='How fast the 3D mouse turns the part (1 = about as fast as it '
                         'turns the view)', default=1.0, min=0.05, max=8.0, soft_min=0.2, soft_max=4.0)
    invert: BoolProperty(name='Invert', description='Turn the other way round', default=False)
    push: EnumProperty(name='Push', items=(
        ('OFF', 'Off', 'The 3D mouse only turns the part'),
        ('NORMAL', 'Normal', 'Pushing / pulling the 3D mouse slides the part along the normal of the surface it was '
                             'last put on (up / down from it)'),
        ('FREE', 'Free', 'The 3D mouse also slides the part along the axes of the view')), default='FREE', update=_redraw)
    show_help: BoolProperty(name='How to use', default=False, description='Show the short how-to lines')
    push_speed: FloatProperty(name='Push Speed', description='How far a full push moves the part in one second, as '
                              'a share of the view distance', default=0.5, min=0.02, max=5.0)
    lift: FloatProperty(name='Lift', description='The origin is put this far off the surface, along its normal',
                        default=0.0, soft_min=-1.0, soft_max=1.0, step=1, precision=3, unit='LENGTH')
    # 0.24.126 (user: "미는 거는 xyz 축에 토글이 좀 되는 건 어때?") which WORLD axes a push may move the part along, and
    # which cap motions may turn it
    push_x: BoolProperty(name='X', default=True, description='A push may move the part along the world X axis')
    push_y: BoolProperty(name='Y', default=True, description='A push may move the part along the world Y axis')
    push_z: BoolProperty(name='Z', default=True, description='A push may move the part along the world Z axis (up / down)')
    # 0.24.126 (user: "3D 마우스 인버트 설정은 이 항목 다 넣어줘, 접었다 피면서 볼 수 있게" - 3DxWare's Speed panel) per cap
    # motion: Active / Speed / Reverse - see AXES below (ax_<key>_on / _speed / _rev), folded under show_axes
    show_axes: BoolProperty(name='3D Mouse Axes', default=False, description='Show the per-axis Active / Speed / Reverse table')
    turn_single: BoolProperty(name='One Axis', default=False,
                              description='0.24.126 only the strongest cap motion (tilt, spin or roll) turns the part: the turn stays '
                                          'bound to one axis at a time')
    # 0.24.126 (user: "오브젝트 사이즈 조절도 3D 마우스로 하게 해 주라, 스마트 사이즈로 / 로컬이랑 월드 축 선택") Smart Size
    ndof_do: EnumProperty(name='3D Mouse', items=(
        ('MOVE', 'Move', 'The 3D mouse moves and turns the held / selected part (Smart Move)'),
        ('SIZE', 'Size', 'Smart Size: the 3D mouse scales the part about its origin - push along x / y / z = that axis '
                         '(Local or World), twist = all axes; S while holding switches')), default='MOVE', update=_redraw)
    size_space: EnumProperty(name='Size Axes', items=(
        ('LOCAL', 'Local', 'Scale along the part\'s own axes (exact, whatever its rotation)'),
        ('WORLD', 'World', 'Scale along the world axes (a turned part: Blender\'s nearest shear-free result)')),
        default='LOCAL', update=_redraw)
    size_speed: FloatProperty(name='Size Speed', description='Doublings per second at a full push / twist',
                              default=1.0, min=0.05, max=8.0, soft_max=4.0)


# the six cap motions as Blender hands them over: translation x / y / z = left-right / forward-back / up-down (push, pull),
# rotation x / y / z = tilt / spin (twist) / roll
AXES = (('lr', 'Left / Right', 'the cap pushed left / right (a move: sideways; a size: X)'),
        ('fb', 'Forward / Back', 'the cap pushed forward / back (a move: along the ground; a size: Y)'),
        ('ud', 'Up / Down', 'the cap pulled up / pushed down (a move: up / down; a size: Z)'),
        ('tilt', 'Tilt', 'the cap tilted forward / back (a turn round the horizontal)'),
        ('spin', 'Spin', 'the cap twisted (a turn round the up axis; a size: all axes)'),
        ('roll', 'Roll', 'the cap rolled sideways (a turn round the view axis)'))
for _key, _label, _desc in AXES:
    MCH_PG_Smart.__annotations__[f'ax_{_key}_on'] = BoolProperty(name=_label, default=True, description=f'Active: {_desc}')
    MCH_PG_Smart.__annotations__[f'ax_{_key}_speed'] = FloatProperty(name='Speed', default=1.0, min=0.0, max=4.0, soft_max=3.0,
                                                                     description=f'Speed of {_desc}')
    MCH_PG_Smart.__annotations__[f'ax_{_key}_rev'] = BoolProperty(name='Reverse', default=False, description=f'Reverse: {_desc}')


def axis_gain(st, key):
    """What one cap motion counts for: 0 when switched off, else its Speed, negative when reversed."""
    if not getattr(st, f'ax_{key}_on', True):
        return 0.0
    g = float(getattr(st, f'ax_{key}_speed', 1.0))
    return -g if getattr(st, f'ax_{key}_rev', False) else g


def device_values(data, st):
    """(translation, rotation) of one 3D-mouse event with the per-axis Active / Speed / Reverse table applied."""
    t, r = Vector(data.translation), Vector(data.rotation)
    return (Vector((t.x * axis_gain(st, 'lr'), t.y * axis_gain(st, 'fb'), t.z * axis_gain(st, 'ud'))),
            Vector((r.x * axis_gain(st, 'tilt'), r.y * axis_gain(st, 'spin'), r.z * axis_gain(st, 'roll'))))


# ---- the maths ------------------------------------------------------------------------------------------------------

def turn_axis(rot, mode, view_matrix=None, local_matrix=None):
    """The world axis a 3D-mouse rotation vector (view space: X right, Y up, Z towards you) turns about.
    TURNTABLE (0.24.125, user: "약간 축이 돌아가 있어" - the View twist was round the screen's up, tilted with a view that
    looks down): twist = round the world's up (Z), tilt = round the view's horizontal, roll = round the view axis -
    Blender's own turntable view turning.  VIEW: all three through the view's rotation (a trackball).  WORLD: tilt
    forward = round world X, twist = round world Z (up), roll = round world Y - the front view's mapping, whatever the
    view.  LOCAL (0.24.126, user: "로컬 축이나 월드 축에 종속되서 돌려지는 버전"): the part's own axes - twist = round its
    Z, tilt = round its X, roll = round its Y (``local_matrix`` = its rotation).  No view: the front view's mapping."""
    v = Vector(rot)
    if mode == 'LOCAL' and local_matrix is not None:
        R = local_matrix.to_3x3().normalized()
        return R @ Vector((v.x, -v.z, v.y))
    if view_matrix is None:
        return Vector((v.x, -v.z, v.y))
    inv = view_matrix.to_3x3().inverted_safe()
    if mode == 'VIEW':
        return inv @ v
    if mode == 'TURNTABLE':
        vx = (inv @ Vector((1.0, 0.0, 0.0))).normalized()
        vz = (inv @ Vector((0.0, 0.0, 1.0))).normalized()
        return vx * v.x + Vector((0.0, 0.0, 1.0)) * v.y + vz * v.z
    return Vector((v.x, -v.z, v.y))


def turn_angle(rot, dt, speed=1.0, invert=False):
    """Radians for one motion event: the vector's length is the angle where 1.0 = 360 deg (Blender's NDOF data),
    scaled by the time since the last event (clamped: a first / stalled event is not a jump)."""
    dt = dt if dt and dt > 0.0 else 1.0 / 60.0
    dt = min(dt, 0.1)
    ang = Vector(rot).length * 2.0 * math.pi * dt * speed
    return -ang if invert else ang


def push_axes(mode, view_matrix=None):
    """0.24.126 (user: "안쪽이랑 바깥쪽으로 … 안 되네") The world directions a 3D-mouse push moves the part along -
    (right, forward, up) for the device's (x, y, z).  Blender hands the cap's left / right as x, forward / back as y and
    push-down / pull-up as z.  TURNTABLE / WORLD: right = the view's horizontal, forward = where the view looks, along the
    ground, up = the world's up - so pushing the cap down / pulling it up moves the part down / up (it moved along the
    line of sight before: invisible in an orthographic view and nearly so looking down).  VIEW: the view's own axes (push
    = towards / away from you).  No view: world X, Y, Z."""
    if view_matrix is None or mode in {'WORLD', 'LOCAL'}:     # (LOCAL: the push is turned into the part's axes by the caller)
        return Vector((1.0, 0.0, 0.0)), Vector((0.0, 1.0, 0.0)), Vector((0.0, 0.0, 1.0))
    inv = view_matrix.to_3x3().inverted_safe()
    vx, vy, vz = inv @ Vector((1.0, 0.0, 0.0)), inv @ Vector((0.0, 1.0, 0.0)), inv @ Vector((0.0, 0.0, 1.0))
    if mode == 'VIEW':
        return vx.normalized(), vy.normalized(), vz.normalized()
    right = Vector((vx.x, vx.y, 0.0))
    right = right.normalized() if right.length > 1e-6 else vx.normalized()
    forward = Vector((vy.x, vy.y, 0.0))                   # the screen's up, on the ground: away from you
    if forward.length < 1e-6:                             # (looking level: the screen's up is the world's up)
        forward = Vector((-vz.x, -vz.y, 0.0))             # ... then where the view looks
    forward = forward.normalized() if forward.length > 1e-6 else Vector((0.0, 1.0, 0.0))
    return right, forward, Vector((0.0, 0.0, 1.0))


def dominant(v):
    """``v`` with only its strongest component kept (One Axis)."""
    v = Vector(v)
    i = max(range(3), key=lambda k: abs(v[k]))
    out = Vector((0.0, 0.0, 0.0))
    out[i] = v[i]
    return out


def masked(v, x, y, z):
    """``v`` with the components that are switched off zeroed."""
    return Vector((v.x if x else 0.0, v.y if y else 0.0, v.z if z else 0.0))


def rotate_about(matrix, axis, angle, pivot):
    """``matrix`` turned by ``angle`` (rad) round the world ``axis`` through the world ``pivot`` (the origin stays)."""
    axis = Vector(axis)
    if axis.length < 1e-12 or abs(angle) < 1e-12:
        return matrix.copy()
    rot = Matrix.Rotation(angle, 4, axis.normalized())
    pivot = Vector(pivot)
    return Matrix.Translation(pivot) @ rot @ Matrix.Translation(-pivot) @ matrix


def place(matrix, hit, normal=None, lift=0.0):
    """``matrix`` with its translation at ``hit`` (+ lift along the normal) - the rotation and the scale untouched."""
    m = matrix.copy()
    p = Vector(hit)
    if normal is not None and lift:
        n = Vector(normal)
        if n.length > 1e-9:
            p = p + n.normalized() * lift
    m.translation = p
    return m


def cast(scene, depsgraph, origin, direction, skip=()):
    """The first mesh surface along a ray that is not one of ``skip`` (object names): (location, normal, object) or
    None.  The ray goes on through skipped objects."""
    o, d = Vector(origin), Vector(direction)
    if d.length < 1e-12:
        return None
    d.normalize()
    for _ in range(8):
        try:
            hit, loc, nor, _i, hob, _m = scene.ray_cast(depsgraph, o, d)
        except (AttributeError, RuntimeError, TypeError):
            return None
        if not hit or hob is None:
            return None
        ob = bpy.data.objects.get(hob.name)
        if ob is not None and ob.type == 'MESH' and ob.name not in skip:
            n = Vector(nor)
            return Vector(loc), (n.normalized() if n.length > 1e-9 else Vector((0.0, 0.0, 1.0))), ob
        o = Vector(loc) + d * 1e-4
    return None


def hit_under(context, xy, skip=()):
    """``cast`` from the mouse: (location, normal, object) or None."""
    try:
        from bpy_extras import view3d_utils
        region, rv3d = context.region, context.region_data
        if region is None or rv3d is None:
            return None
        o = view3d_utils.region_2d_to_origin_3d(region, rv3d, xy)
        d = view3d_utils.region_2d_to_vector_3d(region, rv3d, xy)
    except (AttributeError, RuntimeError, TypeError, ValueError):
        return None
    return cast(context.scene, context.evaluated_depsgraph_get(), o, d, skip)


def selectable(ob):
    try:
        return ob is not None and ob.type == 'MESH' and not ob.hide_get() and not ob.hide_select and not ob.hide_viewport
    except (AttributeError, RuntimeError, ReferenceError):
        return False


def ndof_apply(ob, data, st, rv3d, last_normal=None):
    """One 3D-mouse motion event on ``ob``: turned about its ORIGIN (Turntable / View / World axes, Speed, Invert) and, with Push
    on, slid - Normal: along ``last_normal`` (the surface it was last put on; none known: as Free), Free: along the view's
    axes.  Returns (radians turned, world step)."""
    mode = getattr(st, 'axes', 'BLENDER')
    speed = getattr(st, 'speed', 1.0)
    invert = getattr(st, 'invert', False)
    push = getattr(st, 'push', 'FREE')
    view = rv3d.view_matrix if rv3d is not None else None
    # 0.24.126 the cap motions that may turn (tilt = x, spin = y, roll = z) and the world axes a push may move along
    tr_dev, rot = device_values(data, st)                      # (per-axis Active / Speed / Reverse)
    if getattr(st, 'turn_single', False):
        rot = dominant(rot)                                   # one axis at a time
    dt = float(getattr(data, 'time_delta', 0.0) or 0.0)
    m = ob.matrix_world
    ang = 0.0
    if mode == 'BLENDER' and rv3d is not None:          # 0.24.127 exactly Blender's view navigation, on the part
        b_axis, b_ang, b_step = blender_motion(tr_dev, rot, dt, rv3d)
        b_ang *= speed * (-1.0 if invert else 1.0)
        if b_axis is not None and abs(b_ang) > 1e-12:
            m = rotate_about(m, b_axis, b_ang, m.translation)
            ang = b_ang
        step = Vector((0.0, 0.0, 0.0))
        if push != 'OFF' and b_step.length > 1e-12:
            step = b_step * speed
            if push == 'NORMAL' and last_normal is not None:
                step = Vector(last_normal) * (tr_dev.z * rv3d.view_distance * min(dt if dt > 0.0 else 1.0 / 60.0, 0.1)
                                              * getattr(st, 'push_speed', 0.5))
            step = masked(step, getattr(st, 'push_x', True), getattr(st, 'push_y', True), getattr(st, 'push_z', True))
            m = m.copy()
            m.translation = m.translation + step
        ob.matrix_world = m
        return ang, step
    if rot.length > 1e-9:
        axis = turn_axis(rot, mode, view, m)
        ang = turn_angle(rot, dt, speed, invert)
        m = rotate_about(m, axis, ang, m.translation)
    step = Vector((0.0, 0.0, 0.0))
    if push != 'OFF':
        tr = tr_dev
        if tr.length > 1e-9:
            dtc = min(dt if dt > 0.0 else 1.0 / 60.0, 0.1)
            dist = (rv3d.view_distance if rv3d is not None else 1.0) * getattr(st, 'push_speed', 0.5) * dtc
            if push == 'NORMAL' and last_normal is not None:
                step = Vector(last_normal) * (tr.z * dist)       # pull the cap up = off the surface, push down = into it
            else:
                right, forward, up = push_axes(mode, view)
                step = (right * tr.x + forward * tr.y + up * tr.z) * dist
                if mode == 'LOCAL':                           # along the part's own axes
                    step = m.to_3x3().normalized() @ step
            step = masked(step, getattr(st, 'push_x', True), getattr(st, 'push_y', True), getattr(st, 'push_z', True))
            m = m.copy()
            m.translation = m.translation + step
    ob.matrix_world = m
    return ang, step


def scale_about(matrix, factors, space='LOCAL'):
    """0.24.126 ``matrix`` scaled by ``factors`` (x, y, z) about its own ORIGIN - LOCAL: along the part's axes (exact),
    WORLD: along the world axes (a turned part ends up as Blender's nearest shear-free decomposition)."""
    fx, fy, fz = (max(1e-6, float(f)) for f in factors)
    S = Matrix.Diagonal((fx, fy, fz, 1.0))
    if space == 'WORLD':
        o = matrix.translation.copy()
        return Matrix.Translation(o) @ S @ Matrix.Translation(-o) @ matrix
    return matrix @ S


def size_factors(data, st, dt):
    """The scale factors one 3D-mouse event asks for: the cap pushed along x / y / z = that axis (the X / Y / Z toggles
    gate them, the per-axis table reverses / speeds them), a twist = all three; 2 ** (deflection x seconds x Size Speed)."""
    tr, rot = device_values(data, st)
    tr = masked(tr, getattr(st, 'push_x', True), getattr(st, 'push_y', True), getattr(st, 'push_z', True))
    uni = rot.y
    dtc = min(dt if dt > 0.0 else 1.0 / 60.0, 0.1)
    k = float(getattr(st, 'size_speed', 1.0)) * dtc
    u = 2.0 ** (uni * k)
    return (2.0 ** (tr.x * k) * u, 2.0 ** (tr.y * k) * u, 2.0 ** (tr.z * k) * u)


def size_apply(ob, data, st):
    """Smart Size: one 3D-mouse event scales ``ob`` about its origin (Local / World axes).  Returns the factors."""
    f = size_factors(data, st, float(getattr(data, 'time_delta', 0.0) or 0.0))
    if all(abs(v - 1.0) < 1e-12 for v in f):
        return f
    m = scale_about(ob.matrix_world, f, getattr(st, 'size_space', 'LOCAL'))
    sc = m.to_scale()
    if min(abs(c) for c in sc) < 1e-3:                    # (never collapse a part to nothing)
        return (1.0, 1.0, 1.0)
    ob.matrix_world = m
    return f


def blender_ndof_prefs():
    """0.24.127 Blender's own 3D-mouse preferences (missing in a build without NDOF: Blender's defaults)."""
    try:
        inp = bpy.context.preferences.inputs
    except AttributeError:
        inp = None
    g = lambda name, default: getattr(inp, name, default) if inp is not None else default        # noqa: E731
    return {'orbit': float(g('ndof_orbit_sensitivity', 1.0)), 'pan': float(g('ndof_sensitivity', 1.0)),
            'method': str(g('ndof_view_rotate_method', 'TURNTABLE')), 'mode': str(g('ndof_navigation_mode', 'OBJECT')),
            'dead': float(g('ndof_deadzone', 0.0)), 'zoom_invert': bool(g('ndof_zoom_invert', False))}


def blender_motion(tr, rot, dt, rv3d, prefs=None):
    """0.24.127 (user: "그냥 기존 블렌더 화면 이동이랑 똑같이 맞춰줘") What the SCENE visibly does under Blender's own
    3D-mouse view navigation for one event - from Blender's view3d_navigate_ndof: turntable = tilt round the view's
    horizontal and twist round the world's up (roll ignored), trackball = round the device vector through the view,
    angle = time x value x orbit sensitivity; pan = the view's axes x view distance x time x sensitivity, push / pull
    = towards / away (zoom); the navigation mode's sign (Object: the scene follows the hand).  Returns
    (world axis or None, radians, world step).  No view: nothing (the callers fall back)."""
    if rv3d is None:
        return None, 0.0, Vector((0.0, 0.0, 0.0))
    pr = prefs or blender_ndof_prefs()
    sign = -1.0 if pr['mode'] == 'OBJECT' else 1.0
    dead = pr['dead']
    tr = Vector(tr)
    rot = Vector(rot)
    if dead > 0.0:
        tr = Vector([0.0 if abs(c) < dead else c for c in tr])
        rot = Vector([0.0 if abs(c) < dead else c for c in rot])
    dtc = min(dt if dt > 0.0 else 1.0 / 60.0, 0.1)
    inv = rv3d.view_matrix.to_3x3().inverted_safe()
    axis, ang = None, 0.0
    if pr['method'] == 'TRACKBALL':
        if rot.length > 1e-9:
            axis = (inv @ rot).normalized() * sign       # the angle stays positive; the axis carries the sign
            ang = dtc * rot.length * pr['orbit']
    else:                                                 # turntable: tilt (x) and twist (y); roll is not used
        vx = (inv @ Vector((1.0, 0.0, 0.0))).normalized()
        a_tilt = dtc * rot.x * pr['orbit'] * sign
        a_spin = dtc * rot.y * pr['orbit'] * sign
        if abs(a_tilt) > 1e-12 or abs(a_spin) > 1e-12:
            q = Matrix.Rotation(a_spin, 3, Vector((0.0, 0.0, 1.0))) @ Matrix.Rotation(a_tilt, 3, vx)
            qq = q.to_quaternion()
            axis, ang = (Vector(qq.axis).normalized() if qq.angle > 1e-12 else None), qq.angle
    step = Vector((0.0, 0.0, 0.0))
    if tr.length > 1e-9:
        tz = tr.z * (-1.0 if pr['zoom_invert'] else 1.0)
        step = -sign * (inv @ Vector((tr.x, tr.y, tz))) * (rv3d.view_distance * dtc * pr['pan'])
    return axis, ang, step


def ndof_parts_on(context):
    """0.24.124 the corner card's 3D MOUSE: Parts - the 3D mouse drives the selected part in any tool."""
    return bool(getattr(context.window_manager, 'mch_ndof_parts', False))


def mecha_workspace(context):
    try:
        from . import tool_state as ts
        return ts.is_mecha_workspace(context.workspace)
    except (AttributeError, ReferenceError, ImportError):
        return False


# ---- the operator -----------------------------------------------------------------------------------------------------

def _draw(op, context):
    """A ring on the held part's origin (with its name) and a mark where it was last put (the surface normal)."""
    try:
        import blf
        import gpu
        from bpy_extras import view3d_utils
        from gpu_extras.batch import batch_for_shader
        ob = bpy.data.objects.get(op.ob_name) if op.ob_name else None
        if ob is None or context.region is None or context.region_data is None:
            return
        region, rv3d = context.region, context.region_data
        ui = context.preferences.system.ui_scale
        sh = gpu.shader.from_builtin('UNIFORM_COLOR')
        gpu.state.blend_set('ALPHA')
        gpu.state.line_width_set(2.0)
        o2 = view3d_utils.location_3d_to_region_2d(region, rv3d, ob.matrix_world.translation)
        if o2 is not None:
            r = 14.0 * ui
            pts = [(o2.x + r * math.cos(a), o2.y + r * math.sin(a)) for a in (2 * math.pi * i / 40 for i in range(40))]
            sh.uniform_float('color', RING_COL)
            batch_for_shader(sh, 'LINE_LOOP', {'pos': pts}).draw(sh)
            cross = [(o2.x - r * 0.5, o2.y), (o2.x + r * 0.5, o2.y), (o2.x, o2.y - r * 0.5), (o2.x, o2.y + r * 0.5)]
            batch_for_shader(sh, 'LINES', {'pos': cross}).draw(sh)
            blf.size(0, 11 * ui)
            blf.color(0, *RING_COL)
            blf.position(0, o2.x + r + 4 * ui, o2.y + 4 * ui, 0)
            blf.draw(0, ob.name)
        if op.last_hit is not None:
            loc, nor = op.last_hit
            h2 = view3d_utils.location_3d_to_region_2d(region, rv3d, loc)
            scale = max(rv3d.view_distance * 0.06, 1e-3)
            n2 = view3d_utils.location_3d_to_region_2d(region, rv3d, loc + nor * scale)
            if h2 is not None:
                r = 5.0 * ui
                sh.uniform_float('color', HIT_COL)
                pts = [(h2.x + r * math.cos(a), h2.y + r * math.sin(a)) for a in (2 * math.pi * i / 20 for i in range(20))]
                batch_for_shader(sh, 'LINE_LOOP', {'pos': pts}).draw(sh)
                if n2 is not None:
                    batch_for_shader(sh, 'LINES', {'pos': [(h2.x, h2.y), (n2.x, n2.y)]}).draw(sh)
        gpu.state.line_width_set(1.0)
        gpu.state.blend_set('NONE')
    except Exception:
        pass


class MCH_OT_smart_move(bpy.types.Operator):
    """Smart Move: click a part to hold it, click a surface - its origin goes there (rotation and size unchanged);
    the 3D mouse turns it about its origin.  Enter / Space / RMB keep, Esc puts it back"""
    bl_idname = 'mch.smart_move'
    bl_label = 'Smart Move'
    bl_options = {'UNDO'}          # (no REGISTER: a redo would undo the hold and have nothing to redo)

    # 0.24.124 (user: "스마트 무브는 모든 툴에 넣어줘") E in any Mecha tool: the part under the mouse, else the selected one
    from_key: BoolProperty(default=False, options={'SKIP_SAVE', 'HIDDEN'})

    @classmethod
    def poll(cls, context):
        return context.area is not None and context.area.type == 'VIEW_3D' and context.mode == 'OBJECT'

    # ---- state ----
    def _setup(self):
        self.ob_name = ''
        self.orig = None
        self.last_hit = None
        self.turned = 0.0
        self.prev_sel = []
        self.prev_active = ''
        self.tool0 = 'SMART'
        self.t_start = 0.0

    def invoke(self, context, event):
        import time
        self._setup()
        xy = (event.mouse_region_x, event.mouse_region_y)
        over = False
        try:
            from . import quick_hud
            over = quick_hud.over_ui(context, *xy)
        except (AttributeError, ImportError, TypeError):
            pass
        if over and not self.from_key:
            return {'PASS_THROUGH'}
        if self.from_key and not mecha_workspace(context):
            return {'PASS_THROUGH'}             # (E outside MECHA LAB stays Blender's)
        ob = self._target_for(context, xy, over)
        if ob is None:
            if self.from_key:
                self.report({'INFO'}, 'Smart Move: put the mouse on a part (or select one) and press E')
                return {'CANCELLED'}
            return {'PASS_THROUGH'}             # empty space / nothing to hold: Blender's click goes on
        try:
            from . import tool_state as ts
            self.tool0 = ts.effective_tool(context)
        except (AttributeError, KeyError, TypeError, ImportError):
            self.tool0 = 'SMART'
        self.t_start = time.perf_counter()
        self.ob_name = ob.name
        self.orig = ob.matrix_world.copy()
        try:
            self.prev_sel = [o.name for o in context.selected_objects]
            self.prev_active = context.view_layer.objects.active.name if context.view_layer.objects.active else ''
            for o in context.selected_objects:
                o.select_set(False)
            ob.select_set(True)
            context.view_layer.objects.active = ob
        except (AttributeError, RuntimeError, ReferenceError):
            pass
        self._hook(context)
        self._header(context)
        ACTIVE[0] = self
        try:
            context.window_manager.modal_handler_add(self)
        except (AttributeError, RuntimeError):
            self._unhook(context)
            ACTIVE[0] = None
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def _target_for(self, context, xy, over=False):
        """The part a press (the Smart Move tool) or E (any tool) holds: the mesh under the mouse; with E and nothing
        under the mouse (or the mouse on the drawn UI) the selected active part.  None: nothing to hold."""
        hit = None if over else hit_under(context, xy)
        ob = hit[2] if hit is not None and selectable(hit[2]) else None
        if ob is None and self.from_key:
            try:
                act = context.view_layer.objects.active
                if act is not None and act.type in {'MESH', 'CURVE', 'EMPTY', 'FONT', 'SURFACE', 'META'} \
                        and not act.hide_get() and act.select_get():
                    ob = act
            except (AttributeError, RuntimeError, ReferenceError):
                ob = None
        return ob

    def _hook(self, context):
        if _DRAW[0] is None:
            try:
                _DRAW[0] = bpy.types.SpaceView3D.draw_handler_add(_draw, (self, context), 'WINDOW', 'POST_PIXEL')
            except (AttributeError, RuntimeError, ValueError):
                _DRAW[0] = None

    def _unhook(self, context):
        if _DRAW[0] is not None:
            try:
                bpy.types.SpaceView3D.draw_handler_remove(_DRAW[0], 'WINDOW')
            except (AttributeError, RuntimeError, ValueError):
                pass
            _DRAW[0] = None
        try:
            context.area.header_text_set(None)
        except (AttributeError, RuntimeError):
            pass
        _redraw(None, context)

    def _header(self, context):
        st = getattr(context.scene, 'mch_smart', None)
        axes = getattr(st, 'axes', 'BLENDER').title()
        try:
            push = getattr(st, 'push', 'FREE')
            if getattr(st, 'ndof_do', 'MOVE') == 'SIZE':
                what = (f'3D mouse = SIZE about the origin ({getattr(st, "size_space", "LOCAL").title()} axes: push x / y / z = '
                        f'that axis, twist = all; S: back to move)')
            else:
                what = (f'3D mouse: turn about the origin ({axes} axes, speed {getattr(st, "speed", 1.0):.2g})'
                        + ('' if push == 'OFF' else f', push: {push.title()}') + '   S: size')
            context.area.header_text_set(
                f'Smart Move  |  {self.ob_name}  |  LMB on a surface: put it there (origin, same rotation)  |  ' + what
                + '  |  Enter / Space / RMB' + (' / E' if self.from_key else '') + ': keep   Esc: put back   MMB / wheel: view')
        except (AttributeError, RuntimeError):
            pass

    def _object(self):
        return bpy.data.objects.get(self.ob_name) if self.ob_name else None

    def _finish(self, context, keep):
        ob = self._object()
        if not keep and ob is not None and self.orig is not None:
            ob.matrix_world = self.orig
            try:
                for o in context.selected_objects:
                    o.select_set(False)
                for name in self.prev_sel:
                    o = bpy.data.objects.get(name)
                    if o is not None:
                        o.select_set(True)
                act = bpy.data.objects.get(self.prev_active) if self.prev_active else None
                context.view_layer.objects.active = act if act is not None else ob
            except (AttributeError, RuntimeError, ReferenceError):
                pass
        self._unhook(context)
        ACTIVE[0] = None
        return {'FINISHED'} if keep else {'CANCELLED'}

    # ---- one event of the hold ----
    def _place(self, context, xy):
        ob = self._object()
        hit = hit_under(context, xy, skip={self.ob_name})
        if ob is None or hit is None:
            return False
        loc, nor, _target = hit
        st = getattr(context.scene, 'mch_smart', None)
        ob.matrix_world = place(ob.matrix_world, loc, nor, getattr(st, 'lift', 0.0))
        self.last_hit = (loc, nor)
        return True

    def _ndof(self, context, event):
        ob = self._object()
        data = getattr(event, 'ndof_motion', None)
        if ob is None or data is None:
            return False
        st = getattr(context.scene, 'mch_smart', None)
        if getattr(st, 'ndof_do', 'MOVE') == 'SIZE':          # 0.24.126 Smart Size
            size_apply(ob, data, st)
            return True
        ang, _step = ndof_apply(ob, data, st, getattr(context, 'region_data', None),
                                self.last_hit[1] if self.last_hit is not None else None)
        self.turned += abs(ang)
        return True

    def modal(self, context, event):
        ob = self._object()
        if ob is None:                                    # undone away / deleted meanwhile
            return self._finish(context, True)
        try:
            from . import tool_state as ts
            if ts.effective_tool(context) != self.tool0:   # the tool was changed (strip / pie / key): keep as is
                return self._finish(context, True)
        except (AttributeError, KeyError, TypeError, ImportError):
            pass
        et, ev = event.type, event.value
        if getattr(event, 'is_repeat', False):           # (a held E repeats: not a second press)
            return {'RUNNING_MODAL'}
        if et == 'E' and ev == 'PRESS':
            import time
            if time.perf_counter() - self.t_start < 0.25:  # (the press that started the hold, seen again)
                return {'RUNNING_MODAL'}
        if et == 'NDOF_MOTION':
            self._ndof(context, event)
            _redraw(None, context)
            return {'RUNNING_MODAL'}
        if et in NAV_TYPES or et.startswith('NDOF_BUTTON') or (et.startswith('NUMPAD_') and et != 'NUMPAD_ENTER'):
            return {'PASS_THROUGH'}
        if et == 'LEFTMOUSE':
            if ev != 'PRESS':
                return {'RUNNING_MODAL'}
            xy = (event.mouse_region_x, event.mouse_region_y)
            try:
                from . import quick_hud
                if quick_hud.over_ui(context, *xy):
                    return {'PASS_THROUGH'}
            except (AttributeError, ImportError, TypeError):
                pass
            self._place(context, xy)
            self._header(context)
            _redraw(None, context)
            return {'RUNNING_MODAL'}
        if et in CONFIRM_TYPES and ev == 'PRESS':
            return self._finish(context, True)
        if et == 'ESC' and ev == 'PRESS':
            return self._finish(context, False)
        if et == 'S' and ev == 'PRESS':                     # 0.24.126 Move <-> Size for the 3D mouse (Smart Size)
            st = getattr(context.scene, 'mch_smart', None)
            if st is not None:
                st.ndof_do = 'SIZE' if st.ndof_do == 'MOVE' else 'MOVE'
                self._header(context)
                _redraw(None, context)
            return {'RUNNING_MODAL'}
        return {'PASS_THROUGH'}


class MCH_OT_smart_ndof(bpy.types.Operator):
    """3D mouse on the selected part (the corner card's 3D MOUSE: Parts): it turns about its origin and slides, in any
    tool; with View (default) the 3D mouse moves the view as always"""
    bl_idname = 'mch.smart_ndof'
    bl_label = '3D Mouse: Part'
    bl_options = {'INTERNAL'}

    @classmethod
    def poll(cls, context):
        return context.area is not None and context.area.type == 'VIEW_3D' and context.mode == 'OBJECT'

    def invoke(self, context, event):
        if not ndof_parts_on(context) or ACTIVE[0] is not None or not mecha_workspace(context):
            return {'PASS_THROUGH'}
        data = getattr(event, 'ndof_motion', None)
        ob = getattr(context.view_layer.objects, 'active', None)
        try:
            ok = data is not None and ob is not None and ob.select_get() and not ob.hide_get()
        except (AttributeError, RuntimeError, ReferenceError):
            ok = False
        if not ok:
            return {'PASS_THROUGH'}
        st = getattr(context.scene, 'mch_smart', None)
        if getattr(st, 'ndof_do', 'MOVE') == 'SIZE':                # 0.24.126 Smart Size in any tool too
            size_apply(ob, data, st)
        else:
            ndof_apply(ob, data, st, getattr(context, 'region_data', None))
        if getattr(data, 'progress', '') == 'FINISHING':          # one undo step per gesture
            try:
                bpy.ops.ed.undo_push(message='3D Mouse Move')
            except (RuntimeError, AttributeError):
                pass
        _redraw(None, context)
        return {'FINISHED'}


_PREVIEWS = [None]


def axis_icon(key):
    """The icon_value of a cap-motion thumbnail (icons/ndof_<key>.png), 0 when it cannot be loaded."""
    try:
        import os
        import bpy.utils.previews as previews
        if _PREVIEWS[0] is None:
            _PREVIEWS[0] = previews.new()
        pc = _PREVIEWS[0]
        name = 'ndof_' + key
        if name not in pc:
            path = os.path.join(os.path.dirname(__file__), 'icons', name + '.png')
            if not os.path.isfile(path):
                return 0
            pc.load(name, path, 'IMAGE')
        return pc[name].icon_id                        # 0 in a background Blender (no icon system there)
    except (ImportError, AttributeError, KeyError, RuntimeError, OSError):
        return 0


def axis_icon_loads(key):
    """Whether icons/ndof_<key>.png exists and loads as a picture (the icon id itself is 0 in a background Blender)."""
    try:
        import os
        import bpy.utils.previews as previews
        path = os.path.join(os.path.dirname(__file__), 'icons', 'ndof_' + key + '.png')
        if not os.path.isfile(path):
            return False
        pc = previews.new()
        try:
            pc.load('probe', path, 'IMAGE')
            return tuple(pc['probe'].image_size)[0] > 0
        finally:
            previews.remove(pc)
    except (ImportError, AttributeError, KeyError, RuntimeError, OSError):
        return False


def draw_axes_table(layout, st):
    """0.24.127 (user: "내가 보낸 이미지랑 똑같은 썸네일 넣어서 설정창을 좀 분리해 줘") the per-motion table like
    3DxWare's Speed panel: a picture of the cap's motion, Active, Speed, Reverse."""
    head = layout.row(align=True)
    head.label(text='')
    head.label(text='Motion')
    head.label(text='Active')
    head.label(text='Speed')
    head.label(text='Reverse')
    for key, label, _desc in AXES:
        row = layout.row(align=True)
        ic = axis_icon(key)
        if ic:
            row.template_icon(icon_value=ic, scale=3.0)
        else:
            row.label(text='')
        row.label(text=label)
        row.prop(st, f'ax_{key}_on', text='')
        row.prop(st, f'ax_{key}_speed', text='', slider=True)
        row.prop(st, f'ax_{key}_rev', text='')


class MCH_OT_ndof_settings(bpy.types.Operator):
    """3D Mouse settings for Smart Move / Smart Size, in their own window: what it does, the turn axes, push, size,
    and the per-motion table (Active / Speed / Reverse) with pictures like 3DxWare's"""
    bl_idname = 'mch.ndof_settings'
    bl_label = '3D Mouse Settings'
    bl_options = {'INTERNAL'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=520)

    def draw(self, context):
        st = getattr(context.scene, 'mch_smart', None)
        lay = self.layout
        if st is None:
            lay.label(text='No Smart Move settings')
            return
        wm = context.window_manager
        row = lay.row(align=True)
        row.label(text='3D mouse drives')
        if hasattr(wm, 'mch_ndof_parts'):
            row.prop(wm, 'mch_ndof_parts', text='View', toggle=True, invert_checkbox=True)
            row.prop(wm, 'mch_ndof_parts', text='Parts', toggle=True)
        row = lay.row(align=True)
        row.label(text='Does')
        row.prop(st, 'ndof_do', expand=True)
        box = lay.box()
        box.label(text='Move', icon='ORIENTATION_GIMBAL')
        col = box.column(align=True)
        col.label(text='Turn Axes  (Blender = exactly like the view\'s own 3D-mouse navigation)')
        col.row(align=True).prop(st, 'axes', expand=True)
        row = box.row(align=True)
        row.prop(st, 'speed')
        row.prop(st, 'invert', toggle=True)
        row.prop(st, 'turn_single', toggle=True)
        row = box.row(align=True)
        row.label(text='Push')
        row.prop(st, 'push', expand=True)
        if st.push != 'OFF':
            row = box.row(align=True)
            row.label(text='Push Axes')
            row.prop(st, 'push_x', toggle=True)
            row.prop(st, 'push_y', toggle=True)
            row.prop(st, 'push_z', toggle=True)
            box.prop(st, 'push_speed')
        box.prop(st, 'lift')
        box = lay.box()
        box.label(text='Size  (Smart Size: push x / y / z = that axis, twist = all; S while holding)', icon='FULLSCREEN_ENTER')
        row = box.row(align=True)
        row.label(text='Size Axes')
        row.prop(st, 'size_space', expand=True)
        box.prop(st, 'size_speed')
        box = lay.box()
        box.label(text='Cap motions  (like 3DxWare\'s Speed panel; Blender\'s own 3D-mouse preferences apply first)', icon='MOUSE_MOVE')
        draw_axes_table(box, st)

    def execute(self, context):
        return {'FINISHED'}


class MCH_OT_ndof_parts(bpy.types.Operator):
    """What the 3D mouse drives: the view (as always) or the selected part (turned about its origin, slid), in any tool"""
    bl_idname = 'mch.ndof_parts'
    bl_label = '3D Mouse: View / Parts'
    bl_options = {'INTERNAL'}

    on: BoolProperty(default=True)

    def execute(self, context):
        context.window_manager.mch_ndof_parts = bool(self.on)
        self.report({'INFO'}, '3D mouse: ' + ('the selected part (any tool)' if self.on else 'the view'))
        _redraw(None, context)
        return {'FINISHED'}


# ---- the tool ----------------------------------------------------------------------------------------------------------

class MCH_TOOL_smart_move(bpy.types.WorkSpaceTool):
    bl_space_type = 'VIEW_3D'
    bl_context_mode = 'OBJECT'
    bl_idname = 'mecha.smart_move'
    bl_label = 'Mecha Smart Move'
    bl_description = ('0.24.123 Smart Move: click a part to hold it, click a surface - its origin goes there (same\n'
                      'rotation and size); the 3D mouse turns it about its origin.  Enter / Space / RMB keep, Esc back')
    bl_icon = 'ops.transform.translate'
    bl_widget = None
    bl_keymap = (
        ('mch.quick_hud_press', {'type': 'LEFTMOUSE', 'value': 'PRESS'}, None),
        ('mch.smart_move', {'type': 'LEFTMOUSE', 'value': 'PRESS'}, None),
        ('mch.exit_tool', {'type': 'ESC', 'value': 'PRESS'}, None),
    )

    def draw_settings(context, layout, tool):
        region = getattr(context, 'region', None)
        if region is not None and region.type == 'TOOL_HEADER':
            return
        draw(layout, context)


def draw(layout, context):
    st = getattr(context.scene, 'mch_smart', None)
    if st is None:
        return
    box = layout.box()
    row = box.row(align=True)
    row.label(text='Smart Move', icon='OBJECT_ORIGIN')
    row.prop(st, 'show_help', text='', icon='TRIA_DOWN' if st.show_help else 'TRIA_RIGHT', emboss=False)
    if st.show_help:                               # 0.24.124 (user: "기능 설명은 접을 수 있게") folded by default
        col = box.column(align=True)
        col.label(text='Click a part: hold it.  Click a surface: its origin goes there.')
        col.label(text='3D mouse: turn about the origin.  Enter / RMB keep, Esc back.')
        col.label(text='E in any tool: hold the part under the mouse (or the selected one).')
        col.label(text='S while holding: Smart Size (the 3D mouse scales the part).')
    wm = context.window_manager
    if hasattr(wm, 'mch_ndof_parts'):
        row = box.row(align=True)
        row.label(text='3D Mouse')
        row.prop(wm, 'mch_ndof_parts', text='View', toggle=True, invert_checkbox=True)
        row.prop(wm, 'mch_ndof_parts', text='Parts', toggle=True)
    row = box.row(align=True)                      # 0.24.126 Smart Size: what the 3D mouse does to the part
    row.label(text='Does')
    row.prop(st, 'ndof_do', expand=True)
    if st.ndof_do == 'SIZE':
        row = box.row(align=True)
        row.label(text='Size Axes')
        row.prop(st, 'size_space', expand=True)
    row = box.row(align=True)                      # 0.24.127 Blender (like the view) is the default
    row.label(text='Turn Axes')
    row.prop(st, 'axes', expand=True)
    row = box.row(align=True)
    row.prop(st, 'speed')
    row = box.row(align=True)
    row.label(text='Push')
    row.prop(st, 'push', expand=True)
    if st.push != 'OFF':
        box.prop(st, 'push_speed')
    box.prop(st, 'lift')
    # 0.24.127 (user: "설정창을 좀 분리해 줘") everything else - the per-motion table with pictures, push axes, size
    # speed, invert, one axis - in its own window
    box.operator('mch.ndof_settings', text='3D Mouse Settings...', icon='PREFERENCES')


def top_bar_groups(context, tool):
    """0.24.123 the Mecha top bar for Smart Move: Turn axes / speed / invert, Push, Lift."""
    st = getattr(context.scene, 'mch_smart', None)
    if st is None or tool != 'SMART':
        return []
    from .top_bar import _enum_segs, _mini, _seg
    turn = _enum_segs(st, 'axes', (('BLENDER', 'Blender'), ('TURNTABLE', 'Turntable'), ('VIEW', 'View'), ('WORLD', 'World'),
                                   ('LOCAL', 'Local')))
    turn.append(_mini('Speed', st, 'speed', 130))
    turn.append(_seg('Invert', st, 'invert'))
    push = _enum_segs(st, 'push', (('OFF', 'Off'), ('NORMAL', 'Normal'), ('FREE', 'Free')))
    if st.push != 'OFF':
        push.append(_mini('Push Speed', st, 'push_speed', 150))
    size = _enum_segs(st, 'ndof_do', (('MOVE', 'Move'), ('SIZE', 'Size')))       # 0.24.126 Smart Size
    if st.ndof_do == 'SIZE':
        size += _enum_segs(st, 'size_space', (('LOCAL', 'Local'), ('WORLD', 'World')))
        size.append(_mini('Size Speed', st, 'size_speed', 150))
    from .top_bar import _cell
    size.append(_cell('seg', 'Settings...', action=('op', 'mch.ndof_settings', {})))   # 0.24.127 the own window
    return [('3D Mouse', size), ('Turn', turn), ('Push', push), ('Place', [_mini('Lift', st, 'lift', 140)])]


CLASSES = (MCH_PG_Smart, MCH_OT_smart_move, MCH_OT_smart_ndof, MCH_OT_ndof_parts, MCH_OT_ndof_settings)


def register():
    for c in CLASSES:
        bpy.utils.register_class(c)
    bpy.types.Scene.mch_smart = bpy.props.PointerProperty(type=MCH_PG_Smart)
    bpy.types.WindowManager.mch_ndof_parts = BoolProperty(
        name='3D Mouse: Parts', default=False, update=_redraw,
        description='The 3D mouse drives the selected part (turn about its origin, push) in any tool; off = the view')
    try:
        bpy.utils.register_tool(MCH_TOOL_smart_move, after={'mecha.silhouette_move'}, group=False)
    except (ValueError, RuntimeError, KeyError):
        try:
            bpy.utils.register_tool(MCH_TOOL_smart_move, separator=True, group=False)
        except (ValueError, RuntimeError, KeyError):
            pass


def unregister():
    try:
        bpy.utils.unregister_tool(MCH_TOOL_smart_move)
    except (ValueError, RuntimeError, KeyError, AttributeError):
        pass
    if _DRAW[0] is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(_DRAW[0], 'WINDOW')
        except (ValueError, RuntimeError):
            pass
        _DRAW[0] = None
    ACTIVE[0] = None
    if _PREVIEWS[0] is not None:
        try:
            import bpy.utils.previews as previews
            previews.remove(_PREVIEWS[0])
        except (ImportError, RuntimeError, KeyError):
            pass
        _PREVIEWS[0] = None
    for owner, name in ((bpy.types.Scene, 'mch_smart'), (bpy.types.WindowManager, 'mch_ndof_parts')):
        try:
            delattr(owner, name)
        except (AttributeError, RuntimeError):
            pass
    for c in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(c)
        except (RuntimeError, ValueError):
            pass
