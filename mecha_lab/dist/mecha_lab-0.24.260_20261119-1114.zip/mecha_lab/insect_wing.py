"""0.24.173 Insect Wing (user: "이건 시뮬은 필요 없는데 잠자리 날개나 곤충 날개 같은 거 만들 수 있게 내가 그린 영역 내부에
곤충 날개 무늬가 양각으로 드러나게 해 줘"): draw a wing's outline - a thin wing plate in the drawn shape, its veins
raised (embossed) on it, both sides, no simulation.

Where it sits: the plane of the drawing (through the mesh under it, else the 3D cursor), facing the view.  Its root:
the outline's point nearest to a mesh (the body it grows from), else where the drawing started; its tip: the point
farthest from the root; its leading edge: the straighter side (Flip: the other one).  The veins (in the wing's own
frame - along it from the root, across from the leading edge to the trailing edge): the margin, veins along the
leading edge, veins fanning from the root to the margin, cross veins between them, a net of small cells (dragonfly),
the pterostigma.  They are drawn into an image (crisp in the material: dark, opaque, bumped) and the plate's points
take their height from it (raised).  Six presets: Dragonfly, Damselfly, Bee / Wasp, Fly, Lacewing, Cicada.  Live: the
window's sliders lay it again; Enter / Apply keeps it as it is.
"""
from __future__ import annotations

import json
import math
import random

import bmesh
import bpy
import numpy as np
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty, PointerProperty
from mathutils import Vector
from mathutils.kdtree import KDTree

from . import outline_mesh as om

KEY = 'mch_wing'                  # on a live wing: its outline and plane (json)
_BUSY = [False]

# (id, label, spec) - lead: the veins along the leading edge (offsets across, 0 the leading edge .. 1 the trailing),
# long: veins fanning from the root, reach: how far toward the margin they go, fork: the chance a vein forks before the
# margin, cross: cross veins every this much of the length (in zone), cells: a net of cells this big (0 none),
# stigma: (from, to, depth) the pterostigma, inner: a vein along the trailing margin this far in (0 none), width: the
# veins' width (x the length); tint / vein: colours (linear), alpha: the membrane's opacity, film: iridescence (nm)
PRESETS = (
    ('DRAGONFLY', 'Dragonfly', dict(lead=(0.03, 0.07, 0.12), long=7, reach=1.0, fork=0.0, cross=0.022,
                                    zone=(0.03, 0.97), cells=0.024, stigma=(0.84, 0.91, 0.08), inner=0.0, width=0.0035,
                                    tint=(0.8, 0.72, 0.5), vein=(0.025, 0.02, 0.015), alpha=0.16, film=480.0)),
    ('DAMSELFLY', 'Damselfly', dict(lead=(0.035, 0.08), long=5, reach=1.0, fork=0.0, cross=0.03, zone=(0.06, 0.96),
                                    cells=0.032, stigma=(0.86, 0.92, 0.07), inner=0.0, width=0.003,
                                    tint=(0.03, 0.06, 0.08), vein=(0.01, 0.012, 0.015), alpha=0.6, film=650.0)),
    ('BEE', 'Bee / Wasp', dict(lead=(0.03, 0.07), long=4, reach=0.68, fork=0.0, cross=0.08, zone=(0.25, 0.62),
                               cells=0.0, stigma=(0.5, 0.58, 0.07), inner=0.0, width=0.006,
                               tint=(0.6, 0.52, 0.38), vein=(0.1, 0.055, 0.02), alpha=0.25, film=380.0)),
    ('FLY', 'Fly', dict(lead=(0.03,), long=4, reach=1.0, fork=0.0, cross=0.16, zone=(0.42, 0.62), cells=0.0,
                        stigma=None, inner=0.0, width=0.005, tint=(0.4, 0.4, 0.42), vein=(0.04, 0.035, 0.03),
                        alpha=0.3, film=420.0)),
    ('LACEWING', 'Lacewing', dict(lead=(0.03, 0.06), long=8, reach=1.0, fork=0.85, cross=0.03, zone=(0.03, 0.96),
                                  cells=0.0, stigma=(0.8, 0.86, 0.06), inner=0.0, width=0.0025,
                                  tint=(0.55, 0.75, 0.5), vein=(0.12, 0.3, 0.04), alpha=0.14, film=320.0)),
    ('CICADA', 'Cicada', dict(lead=(0.035, 0.075), long=7, reach=0.93, fork=0.0, cross=0.13, zone=(0.2, 0.9),
                              cells=0.0, stigma=None, inner=0.06, width=0.0055, tint=(0.6, 0.52, 0.36),
                              vein=(0.08, 0.1, 0.03), alpha=0.22, film=520.0)),
)
SPEC = {p[0]: p[2] for p in PRESETS}
# 0.24.173 + the user's black-and-white photos (wing_photo): their veins laid on the drawn wing, coloured like a preset
from . import wing_photo as wp  # noqa: E402
PRESET_ITEMS = [(p[0], p[1], '') for p in PRESETS] + [(p[0], p[1], 'Veins from a photo') for p in wp.PHOTOS]
PHOTO_LOOK = {p[0]: p[3] for p in wp.PHOTOS}


def is_wing(ob):
    return ob is not None and KEY in ob.keys()


def active_wing(context):
    ob = getattr(context.view_layer.objects, 'active', None)
    try:
        return ob if is_wing(ob) and ob.select_get() else None
    except (RuntimeError, ReferenceError):
        return None


# ---- the wing's frame ---------------------------------------------------------------------------------------------

class Frame:
    """The wing's own frame on its outline ``P`` (plane coordinates): s along (0 the root .. 1 the tip), across f
    (0 the leading edge .. 1 the trailing edge) at each s."""

    def __init__(self, P, root_i, flip=False):
        self.P = P = np.asarray(P, float)
        self.root = P[root_i]
        d = np.linalg.norm(P - self.root, axis=1)
        tip_i = int(np.argmax(d))
        self.L = max(float(d[tip_i]), 1e-9)
        self.axis = (P[tip_i] - self.root) / self.L
        self.perp = np.array([-self.axis[1], self.axis[0]])
        n = len(P)
        arc1 = [(root_i + k) % n for k in range((tip_i - root_i) % n + 1)]
        arc2 = [(root_i - k) % n for k in range((root_i - tip_i) % n + 1)]
        w1 = np.abs(((P[arc1] - self.root) @ self.perp)).mean()
        w2 = np.abs(((P[arc2] - self.root) @ self.perp)).mean()
        lead = arc1 if w1 <= w2 else arc2               # (the leading edge: the straighter side)
        if flip:
            lead = arc2 if lead is arc1 else arc1
        self.trail_arc = arc2 if lead is arc1 else arc1
        self.lead_arc = lead
        if ((P[lead] - self.root) @ self.perp).mean() < 0:
            self.perp = -self.perp                      # (across: + toward the leading edge)
        sw = self.to_sw(P)
        self.S = np.linspace(0.0, 1.0, 401)
        self.lead_w, self.trail_w = self._margins(sw)

    def to_sw(self, Q):
        R = np.asarray(Q, float) - self.root
        return np.c_[R @ self.axis, R @ self.perp] / self.L

    def _margins(self, sw):
        """The outline's highest / lowest w at each s (where a line across the wing at s meets it)."""
        A, B = sw, np.roll(sw, -1, axis=0)
        hi = np.full(len(self.S), np.nan)
        lo = np.full(len(self.S), np.nan)
        for i, s in enumerate(self.S):
            m = ((A[:, 0] - s) * (B[:, 0] - s)) <= 0
            if not np.any(m):
                continue
            a, b = A[m], B[m]
            ds = b[:, 0] - a[:, 0]
            t = np.where(np.abs(ds) > 1e-12, (s - a[:, 0]) / np.where(np.abs(ds) > 1e-12, ds, 1.0), 0.5)
            w = a[:, 1] + t * (b[:, 1] - a[:, 1])
            hi[i], lo[i] = w.max(), w.min()
        ok = ~np.isnan(hi)
        if not np.any(ok):
            return np.full(len(self.S), 0.1), np.full(len(self.S), -0.1)
        hi = np.interp(self.S, self.S[ok], hi[ok])
        lo = np.interp(self.S, self.S[ok], lo[ok])
        return hi, lo

    def point(self, s, f):
        """Plane coordinates of (s, f) - arrays."""
        s = np.asarray(s, float)
        f = np.asarray(f, float)
        hi = np.interp(s, self.S, self.lead_w)
        lo = np.interp(s, self.S, self.trail_w)
        w = hi + f * (lo - hi)
        return self.root + self.L * (s[..., None] * self.axis + w[..., None] * self.perp)

    def sf(self, Q):
        sw = self.to_sw(Q)
        hi = np.interp(sw[:, 0], self.S, self.lead_w)
        lo = np.interp(sw[:, 0], self.S, self.trail_w)
        return np.c_[sw[:, 0], (hi - sw[:, 1]) / np.maximum(hi - lo, 1e-9)]


def _nsum(a):
    out = np.zeros_like(a)
    out[1:] += a[:-1]
    out[:-1] += a[1:]
    out[:, 1:] += a[:, :-1]
    out[:, :-1] += a[:, 1:]
    return out


def _harmonic(inside, known, value, iters=3000, tol=1e-7):
    """A smooth field inside (a grid): ``value`` where ``known``, between them as smooth as it can be (Laplace, the
    outline a wall - conjugate gradients)."""
    unk = inside & ~known
    deg = _nsum(inside.astype(np.float64)) * inside
    D = np.where(known & inside, value, 0.0)
    b = _nsum(D) * unk
    x = np.zeros_like(D)

    def A(v):
        v = v * unk
        return (deg * v - _nsum(v) * inside) * unk
    r = b - A(x)
    pdir = r.copy()
    rs = float((r * r).sum())
    if rs < 1e-30:
        return np.where(known, D, x)
    for _ in range(iters):
        Ap = A(pdir)
        alpha = rs / max(float((pdir * Ap).sum()), 1e-30)
        x += alpha * pdir
        r -= alpha * Ap
        rs2 = float((r * r).sum())
        if rs2 < tol * tol * max(float((b * b).sum()), 1e-30):
            break
        pdir = r + (rs2 / rs) * pdir
        rs = rs2
    return np.where(known, D, x * unk)


class HFrame(Frame):
    """0.24.174 The wing's own frame from the shape as drawn (user: "인섹트 윙은 내가 그린 대로 안 나와, 혈관이" - a curved, a
    broad or a lobed wing had its veins bunched to one edge, bent or thrown into a notch: they were laid along the
    straight line from the root to the tip).  Now both of its coordinates are solved inside the drawing: along it (s)
    a smooth field from the root (0) to the tip (1) that follows its bends (then even by distance), across it (f) a
    smooth field from the leading edge (0) to the trailing edge (1) - so the veins follow its curve, its width and its
    lobes.  Same use as ``Frame`` (point, sf, P, L, root, axis, trail_arc)."""

    def __init__(self, P, root_i, flip=False, res=170):
        super().__init__(P, root_i, flip)
        P = self.P
        lo, hi = P.min(0), P.max(0)
        area = abs(0.5 * float(np.sum(P[:, 0] * np.roll(P[:, 1], -1) - np.roll(P[:, 0], -1) * P[:, 1])))
        h = min(float((hi - lo).max()) / res, area / max(self.L, 1e-9) / 40.0)   # (40 cells across at least)
        h = max(h, float((hi - lo).max()) / 700.0)
        nx, ny = int(np.ceil((hi[0] - lo[0]) / h)) + 3, int(np.ceil((hi[1] - lo[1]) / h)) + 3
        self.g_lo, self.g_h = lo - h, h
        gx = self.g_lo[0] + (np.arange(nx) + 0.5) * h
        gy = self.g_lo[1] + (np.arange(ny) + 0.5) * h
        X, Y = np.meshgrid(gx, gy)
        C = np.c_[X.ravel(), Y.ravel()]
        inside = om.inside(C, [P]).reshape(ny, nx)
        rim = inside & (_nsum((~inside).astype(np.float64)) > 0)
        # across: 0 on the leading edge, 1 on the trailing edge (each rim cell: which edge is nearer - by its sides,
        # not its corners: a long straight side has no corner along it)
        ri = np.nonzero(rim.ravel())[0]
        d_lead = om.seg_distance(C[ri], P[self.lead_arc], closed=False)
        d_trail = om.seg_distance(C[ri], P[self.trail_arc], closed=False)
        fval = np.zeros(ny * nx)
        fval[ri] = np.where(d_lead <= d_trail, 0.0, 1.0)
        F = _harmonic(inside, rim, fval.reshape(ny, nx))
        # along: 0 round the root, 1 round the tip
        tip = P[int(np.argmax(np.linalg.norm(P - self.root, axis=1)))]
        dr = np.linalg.norm(C - self.root, axis=1).reshape(ny, nx)
        dt = np.linalg.norm(C - tip, axis=1).reshape(ny, nx)
        r0 = max(self.L * 0.045, 2.5 * h)
        known = inside & ((dr < r0) | (dt < r0))
        if not np.any(known & (dr < r0)) or not np.any(known & (dt < r0)):
            ins = np.nonzero(inside.ravel())[0]
            known = known.copy().ravel()
            known[ins[np.argmin(dr.ravel()[ins])]] = True
            known[ins[np.argmin(dt.ravel()[ins])]] = True
            known = known.reshape(ny, nx)
        S0 = _harmonic(inside, known, np.where(dt < dr, 1.0, 0.0))
        # even by distance: the middle of each step of s, how far along
        sv = S0[inside]
        pts = C[inside.ravel()]
        bins = np.clip((sv * 64).astype(int), 0, 63)
        cnt = np.bincount(bins, minlength=64)
        cx = np.bincount(bins, weights=pts[:, 0], minlength=64)
        cy = np.bincount(bins, weights=pts[:, 1], minlength=64)
        ok = cnt > 0
        cen = np.c_[cx[ok] / cnt[ok], cy[ok] / cnt[ok]]
        lev = (np.arange(64)[ok] + 0.5) / 64.0
        cen = np.r_[self.root[None], cen, tip[None]]
        lev = np.r_[0.0, lev, 1.0]
        cum = np.r_[0.0, np.cumsum(np.linalg.norm(np.diff(cen, axis=0), axis=1))]
        cum /= max(cum[-1], 1e-12)
        S = np.where(inside, np.interp(S0, lev, cum), 0.0)
        # out of the drawing: the nearest value inside (for samples just past the edge)
        S, F = self._spread(S, inside), self._spread(F, inside)
        self.gS, self.gF = S, F
        # back from (s, f) to the plane: a table (s x f) of the places inside
        ns_, nf_ = 161, 33
        bs = np.clip((S[inside] * (ns_ - 1)).round().astype(int), 0, ns_ - 1)
        bf = np.clip((F[inside] * (nf_ - 1)).round().astype(int), 0, nf_ - 1)
        k = bs * nf_ + bf
        cnt = np.bincount(k, minlength=ns_ * nf_).astype(float)
        tx = np.bincount(k, weights=pts[:, 0], minlength=ns_ * nf_)
        ty = np.bincount(k, weights=pts[:, 1], minlength=ns_ * nf_)
        has = cnt > 0
        TX = np.where(has, tx / np.maximum(cnt, 1), np.nan).reshape(ns_, nf_)
        TY = np.where(has, ty / np.maximum(cnt, 1), np.nan).reshape(ns_, nf_)
        for T in (TX, TY):
            for i in range(ns_):                      # (gaps filled: along f, then along s)
                ok = ~np.isnan(T[i])
                if ok.sum() >= 1 and not ok.all():
                    T[i] = np.interp(np.arange(nf_), np.nonzero(ok)[0], T[i][ok])
            for j in range(nf_):
                ok = ~np.isnan(T[:, j])
                if ok.sum() >= 1 and not ok.all():
                    T[:, j] = np.interp(np.arange(ns_), np.nonzero(ok)[0], T[:, j][ok])
        TX = np.nan_to_num(TX, nan=float(self.root[0]))
        TY = np.nan_to_num(TY, nan=float(self.root[1]))
        k5 = np.array([1.0, 2.0, 3.0, 2.0, 1.0]) / 9.0     # (smoothed along s: no steps from the grid)
        for T in (TX, TY):
            pad = np.pad(T, ((2, 2), (0, 0)), mode='edge')
            T[:] = sum(pad[i:i + ns_] * k5[i] for i in range(5))
        self.TX, self.TY = TX, TY

    @staticmethod
    def _spread(G, inside):
        G = G.copy()
        have = inside.copy()
        for _ in range(max(G.shape)):
            if have.all():
                break
            s_ = _nsum(np.where(have, G, 0.0))
            c_ = _nsum(have.astype(np.float64))
            new = ~have & (c_ > 0)
            G[new] = s_[new] / c_[new]
            have = have | new
        return G

    def _grid(self, G, Q):
        Q = np.asarray(Q, float)
        x = np.clip((Q[:, 0] - self.g_lo[0]) / self.g_h - 0.5, 0, G.shape[1] - 1.001)
        y = np.clip((Q[:, 1] - self.g_lo[1]) / self.g_h - 0.5, 0, G.shape[0] - 1.001)
        x0, y0 = x.astype(int), y.astype(int)
        fx, fy = x - x0, y - y0
        a = G[y0, x0] * (1 - fx) + G[y0, x0 + 1] * fx
        b = G[y0 + 1, x0] * (1 - fx) + G[y0 + 1, x0 + 1] * fx
        return a * (1 - fy) + b * fy

    def sf(self, Q):
        return np.c_[self._grid(self.gS, Q), self._grid(self.gF, Q)]

    def point(self, s, f):
        s = np.clip(np.asarray(s, float), 0.0, 1.0)
        f = np.clip(np.asarray(f, float), 0.0, 1.0)
        shp = s.shape
        s, f = np.broadcast_arrays(s, f)
        x = s.ravel() * (self.TX.shape[0] - 1)
        y = f.ravel() * (self.TX.shape[1] - 1)
        x0 = np.clip(x.astype(int), 0, self.TX.shape[0] - 2)
        y0 = np.clip(y.astype(int), 0, self.TX.shape[1] - 2)
        fx, fy = (x - x0)[:, None], (y - y0)[:, None]
        T = np.stack([self.TX, self.TY], axis=-1)
        a = T[x0, y0] * (1 - fy) + T[x0, y0 + 1] * fy
        b = T[x0 + 1, y0] * (1 - fy) + T[x0 + 1, y0 + 1] * fy
        out = a * (1 - fx) + b * fx
        return out.reshape(*np.broadcast_shapes(shp, f.shape), 2)


# ---- the veins ----------------------------------------------------------------------------------------------------

def _bezier(p0, p1, p2, n=48):
    t = np.linspace(0.0, 1.0, n)[:, None]
    return (1 - t) ** 2 * np.asarray(p0) + 2 * (1 - t) * t * np.asarray(p1) + t * t * np.asarray(p2)


def veins(fr, spec, density=1.0, seed=0):
    """[(polyline N x 2 in plane coordinates, half-width per point N, closed)], stigma polygon (or None)."""
    rng = random.Random(seed * 7919 + 17)
    L = fr.L
    r0 = spec['width'] * L * 0.5
    out = []
    # the margin: the outline itself
    out.append((fr.P, np.full(len(fr.P), r0 * 0.8), True))
    sf_lines = []                                       # (s, f) polylines, leading edge first, for the cross veins
    for j, f in enumerate(spec['lead']):                # along the leading edge
        s = np.linspace(0.01, 0.985 - 0.035 * j, 90)
        sf = np.c_[s, np.full(len(s), f)]
        sf_lines.append(sf)
        out.append((fr.point(sf[:, 0], sf[:, 1]), np.full(len(s), r0 * (1.35 - 0.15 * j)), False))
    # fanning from the root to the margin (their ends spread from the tip round the trailing edge)
    K = spec['long']
    tr = fr.P[fr.trail_arc[::-1]]                       # (the trailing margin: from the tip back to the root)
    seg = np.r_[0.0, np.cumsum(np.linalg.norm(np.diff(tr, axis=0), axis=1))]
    for k in range(K):
        g = 0.03 + 0.72 * (k / max(K - 1, 1))
        e = np.array([np.interp(g * seg[-1], seg, tr[:, 0]), np.interp(g * seg[-1], seg, tr[:, 1])])
        se, fe = fr.sf(e[None])[0]
        fe = min(max(fe, 0.0), 1.0)
        s0 = 0.02 + 0.03 * k / max(K - 1, 1)
        f0 = 0.17 + 0.3 * k / max(K - 1, 1)
        end = np.array([s0 + (se - s0) * spec['reach'], f0 + (fe - f0) * spec['reach']])
        mid = np.array([s0 + (end[0] - s0) * 0.55, f0 + (end[1] - f0) * 0.22])
        sf = _bezier((s0, f0), mid, end)
        sf_lines.append(sf)
        taper = np.linspace(1.15, 0.6, len(sf))
        out.append((fr.point(sf[:, 0], sf[:, 1]), r0 * taper, False))
        if spec['fork'] > 0 and rng.random() < spec['fork'] and spec['reach'] >= 0.99:
            g2 = min(g + 0.035, 0.98)                   # (a fork near the margin)
            e2 = np.array([np.interp(g2 * seg[-1], seg, tr[:, 0]), np.interp(g2 * seg[-1], seg, tr[:, 1])])
            s2, f2 = fr.sf(e2[None])[0]
            at = sf[int(len(sf) * 0.8)]
            br = _bezier(at, (at + np.array([s2, f2])) / 2, (s2, min(max(f2, 0), 1)), 16)
            out.append((fr.point(br[:, 0], br[:, 1]), np.full(len(br), r0 * 0.55), False))
    if spec['inner'] > 0:                               # a vein along the trailing margin, cells to the margin
        s = np.linspace(0.25, 0.95, 70)
        sf = np.c_[s, np.full(len(s), 1.0 - spec['inner'])]
        out.append((fr.point(sf[:, 0], sf[:, 1]), np.full(len(s), r0 * 0.7), False))
        for s_ in np.arange(0.27, 0.95, 0.045 / density):
            out.append((fr.point(np.array([s_, s_]), np.array([1.0 - spec['inner'], 1.0])),
                        np.full(2, r0 * 0.5), False))
    # cross veins between neighbouring veins (by their place across at mid length)
    if spec['cross'] > 0:
        order = sorted(range(len(sf_lines)), key=lambda i: float(np.interp(0.5, sf_lines[i][:, 0], sf_lines[i][:, 1])))
        step = spec['cross'] / max(density, 0.05)
        z0, z1 = spec['zone']
        for a_i, b_i in zip(order, order[1:]):
            A, B = sf_lines[a_i], sf_lines[b_i]
            lo = max(A[:, 0].min(), B[:, 0].min(), z0)
            hi = min(A[:, 0].max(), B[:, 0].max(), z1)
            s_ = lo + step * rng.uniform(0.2, 0.8)
            while s_ < hi:
                sa = s_ + rng.uniform(-0.25, 0.25) * step
                sb = s_ + rng.uniform(-0.25, 0.25) * step
                if lo <= sa <= hi and lo <= sb <= hi:
                    fa = np.interp(sa, A[:, 0], A[:, 1])
                    fb = np.interp(sb, B[:, 0], B[:, 1])
                    out.append((fr.point(np.array([sa, sb]), np.array([fa, fb])), np.full(2, r0 * 0.5), False))
                s_ += step * rng.uniform(0.8, 1.2)
    # a net of small cells (dragonflies): the edges of the cells round scattered points
    if spec['cells'] > 0:
        c = spec['cells'] * L / max(density, 0.05)
        lo, hi = fr.P.min(0), fr.P.max(0)
        xs = np.arange(lo[0], hi[0] + c, c)
        ys = np.arange(lo[1], hi[1] + c, c * 0.866)
        G = np.array([(x + (0.5 * c if r % 2 else 0.0), y) for r, y in enumerate(ys) for x in xs], float)
        nr = np.random.default_rng(seed + 3)
        G = G + nr.uniform(-0.3, 0.3, G.shape) * c
        G = G[om.inside(G, [fr.P])]
        if len(G) >= 4:
            from mathutils.geometry import delaunay_2d_cdt
            vv, _e, ff, vo, _eo, _fo = delaunay_2d_cdt([Vector(p) for p in G], [], [], 0, 1e-9, True)
            V = np.array([tuple(v) for v in vv], float)
            tris = np.array([f for f in ff if len(f) == 3], int).reshape(-1, 3)
            a, b, cc = V[tris[:, 0]], V[tris[:, 1]], V[tris[:, 2]]
            dd = 2 * (a[:, 0] * (b[:, 1] - cc[:, 1]) + b[:, 0] * (cc[:, 1] - a[:, 1]) + cc[:, 0] * (a[:, 1] - b[:, 1]))
            dd = np.where(np.abs(dd) < 1e-18, 1e-18, dd)
            A2, B2, C2 = (a * a).sum(1), (b * b).sum(1), (cc * cc).sum(1)
            ux = (A2 * (b[:, 1] - cc[:, 1]) + B2 * (cc[:, 1] - a[:, 1]) + C2 * (a[:, 1] - b[:, 1])) / dd
            uy = (A2 * (cc[:, 0] - b[:, 0]) + B2 * (a[:, 0] - cc[:, 0]) + C2 * (b[:, 0] - a[:, 0])) / dd
            CC = np.c_[ux, uy]
            edge_tri = {}
            for t_i, (i, j, k) in enumerate(tris):
                for e_ in ((i, j), (j, k), (k, i)):
                    edge_tri.setdefault((min(e_), max(e_)), []).append(t_i)
            segs = [(CC[ts[0]], CC[ts[1]]) for ts in edge_tri.values() if len(ts) == 2]
            if segs:
                S0 = np.array([s_[0] for s_ in segs])
                S1 = np.array([s_[1] for s_ in segs])
                ok = om.inside(S0, [fr.P]) & om.inside(S1, [fr.P])
                sf0 = fr.sf(S0)
                ok &= sf0[:, 0] > 0.07                    # (none right at the root)
                ok &= np.linalg.norm(S1 - S0, axis=1) < c * 2.5
                for p0, p1 in zip(S0[ok], S1[ok]):
                    out.append((np.array([p0, p1]), np.full(2, r0 * 0.42), False))
    stigma = None
    if spec.get('stigma'):
        a_, b_, dpt = spec['stigma']
        s = np.linspace(a_, b_, 8)
        top = fr.point(s, np.full(len(s), 0.0))
        bot = fr.point(s[::-1], np.full(len(s), dpt))
        stigma = np.r_[top, bot]
    return out, stigma


def raster(fr, vlist, stigma, px):
    """The veins drawn into a height field (H x W: R the veins' height 0..1, round in section, the thicker ones
    higher; G the pterostigma) over the outline's bounds, ``px`` plane units a pixel.  Returns (img, lo)."""
    lo = fr.P.min(0) - px * 4
    hi = fr.P.max(0) + px * 4
    R = om.raster_lines(lo, hi, px, vlist)
    H, W = R.shape
    G = np.zeros((H, W), np.float32)
    if stigma is not None:
        x0, y0 = ((stigma.min(0) - lo) / px).astype(int)
        x1, y1 = ((stigma.max(0) - lo) / px).astype(int) + 2
        gx = lo[0] + np.arange(x0, x1) * px
        gy = lo[1] + np.arange(y0, y1) * px
        X, Y = np.meshgrid(gx, gy)
        m = om.inside(np.c_[X.ravel(), Y.ravel()], [stigma]).reshape(X.shape)
        G[y0:y1, x0:x1] = np.maximum(G[y0:y1, x0:x1], m.astype(np.float32))
        R[y0:y1, x0:x1] = np.maximum(R[y0:y1, x0:x1], 0.55 * m.astype(np.float32))
    return np.stack([R, G], axis=-1), lo


def bend_twist(V, fr, bend, twist):
    """0.24.173 (user: "벌레 날개는 뿌리 부분을 기준으로 밴드랑 트위스트도 추가해 줘"): the wing (plane x, y + height z)
    twisted round its long axis and bent along it, more and more from the root (nothing at the root) to the tip
    (``twist`` / ``bend`` there, radians; bend + : toward the view)."""
    R = V[:, :2] - fr.root
    a = R @ fr.axis
    c = R @ fr.perp
    z = V[:, 2].copy()
    s = np.clip(a / fr.L, 0.0, None)
    phi = twist * s                                    # (round the long axis)
    c, z = c * np.cos(phi) - z * np.sin(phi), c * np.sin(phi) + z * np.cos(phi)
    if abs(bend) > 1e-9:                               # (along it: an arc, the root's end flat)
        rr = fr.L / bend
        th = np.clip(a, 0.0, None) / rr
        out = a > 0
        a = np.where(out, rr * np.sin(th) - z * np.sin(th), a)
        z = np.where(out, rr * (1.0 - np.cos(th)) + z * np.cos(th), z)
    xy = fr.root + a[:, None] * fr.axis + c[:, None] * fr.perp
    return np.c_[xy, z]


def photo_field(fr, pid, px, vein_width, spec):
    """A photo's veins (white) laid on the drawn wing: each texel's place along / across the wing found in the photo's
    wing.  Returns (img H x W x 2, lo) as ``raster``."""
    pfr, pfield = wp.load(pid)
    lo = fr.P.min(0) - px * 4
    hi = fr.P.max(0) + px * 4
    W = int(math.ceil((hi[0] - lo[0]) / px)) + 1
    H = int(math.ceil((hi[1] - lo[1]) / px)) + 1
    gx = lo[0] + np.arange(W) * px
    gy = lo[1] + np.arange(H) * px
    X, Y = np.meshgrid(gx, gy)
    sf = fr.sf(np.c_[X.ravel(), Y.ravel()])
    v = wp.sample(pfield, pfr.point(sf[:, 0], sf[:, 1])).reshape(H, W)
    t0 = min(max(0.25 / max(vein_width, 0.05), 0.02), 0.8)      # (Vein Width: more of the grey counts as vein)
    R = np.clip((v - t0) / (1.0 - t0), 0.0, 1.0).astype(np.float32)
    rim = om.raster_lines(lo, hi, px, [(fr.P, np.full(len(fr.P), spec['width'] * fr.L * 0.4 * vein_width), True)])
    R = np.maximum(R, rim[:H, :W] * 0.8)
    return np.stack([R, np.zeros_like(R)], axis=-1), lo


def sample(img, lo, px, Q):
    """Bilinear: the field at the plane points ``Q``."""
    H, W = img.shape[:2]
    x = np.clip((Q[:, 0] - lo[0]) / px, 0, W - 1.001)
    y = np.clip((Q[:, 1] - lo[1]) / px, 0, H - 1.001)
    x0, y0 = x.astype(int), y.astype(int)
    fx, fy = (x - x0)[:, None], (y - y0)[:, None]
    a = img[y0, x0] * (1 - fx) + img[y0, x0 + 1] * fx
    b = img[y0 + 1, x0] * (1 - fx) + img[y0 + 1, x0 + 1] * fx
    return a * (1 - fy) + b * fy


# ---- the material --------------------------------------------------------------------------------------------------

def wing_material(ob, image, spec):
    name = f'MCH Wing ({ob.name})'
    m = ob.data.materials[0] if len(ob.data.materials) and ob.data.materials[0] is not None and \
        ob.data.materials[0].get('mch_wing_mat') else None
    if m is None:
        m = bpy.data.materials.new(name)
        m['mch_wing_mat'] = 1
        ob.data.materials.clear()
        ob.data.materials.append(m)
    m.use_nodes = True
    nt = m.node_tree
    nt.nodes.clear()
    out = nt.nodes.new('ShaderNodeOutputMaterial')
    pb = nt.nodes.new('ShaderNodeBsdfPrincipled')
    nt.links.new(pb.outputs[0], out.inputs['Surface'])
    tx = nt.nodes.new('ShaderNodeTexImage')
    tx.image = image
    tx.interpolation = 'Linear'
    tx.extension = 'EXTEND'
    sep = nt.nodes.new('ShaderNodeSeparateColor')
    nt.links.new(tx.outputs['Color'], sep.inputs[0])

    def math_(op, a, b=None, clamp=False):
        n = nt.nodes.new('ShaderNodeMath')
        n.operation = op
        n.use_clamp = clamp
        for i, v in enumerate((a, b)):
            if v is None:
                continue
            if isinstance(v, bpy.types.NodeSocket):
                nt.links.new(v, n.inputs[i])
            else:
                n.inputs[i].default_value = v
        return n.outputs[0]
    vein = math_('MAXIMUM', math_('MULTIPLY', sep.outputs[0], 3.0, clamp=True), sep.outputs[1])
    mix = nt.nodes.new('ShaderNodeMix')
    mix.data_type = 'RGBA'
    sock = {i.identifier: i for i in mix.inputs}
    nt.links.new(vein, sock['Factor_Float'])
    sock['A_Color'].default_value = (*spec['tint'], 1.0)
    sock['B_Color'].default_value = (*spec['vein'], 1.0)
    nt.links.new(next(o for o in mix.outputs if o.identifier == 'Result_Color'), pb.inputs['Base Color'])
    alpha = math_('ADD', spec['alpha'], math_('MULTIPLY', vein, 1.0 - spec['alpha']), clamp=True)
    nt.links.new(alpha, pb.inputs['Alpha'])
    bump = nt.nodes.new('ShaderNodeBump')
    bump.inputs['Strength'].default_value = 0.6
    bump.inputs['Distance'].default_value = 0.002
    nt.links.new(sep.outputs[0], bump.inputs['Height'])
    nt.links.new(bump.outputs['Normal'], pb.inputs['Normal'])
    pb.inputs['Roughness'].default_value = 0.12
    for k, v in (('Thin Film Thickness', spec['film']), ('Thin Film IOR', 1.45)):
        try:
            pb.inputs[k].default_value = v
        except KeyError:
            pass
    try:
        m.surface_render_method = 'DITHERED'
    except (AttributeError, TypeError):
        pass
    m.diffuse_color = (*[min(1.0, 0.25 + c) for c in spec['tint']], 1.0)     # (the Solid view: a light tint)
    return m


# ---- the wing object ---------------------------------------------------------------------------------------------

def data(ob):
    try:
        return json.loads(ob[KEY])
    except (KeyError, ValueError, TypeError):
        return None


def attach_map(context, P2, origin, X, Y, N, L):
    """0.24.176 (user: "곤충 날개도 크리쳐 클로스처럼 메쉬에 붙게 할 수 있어?"): where the drawn wing lies over a mesh -
    the wing's plane in cells L / 80 apart; for each cell over a mesh near the plane (within 0.3 L either side, looked at
    from in front: the side facing you) how far that surface is from the plane (along N, + toward you) and which mesh.
    Returns dict(step, cells [[x, y, disp, host]], hosts [names]) or None (nothing under it)."""
    from . import creature_membrane as cm
    dg = context.evaluated_depsgraph_get()
    skip = cm._skip_names(context)
    P2 = np.asarray(P2, float)
    step = L / 80.0
    lo, hi = P2.min(0), P2.max(0)
    gx = lo[0] + (np.arange(int(math.ceil((hi[0] - lo[0]) / step)) + 1) + 0.5) * step - step
    gy = lo[1] + (np.arange(int(math.ceil((hi[1] - lo[1]) / step)) + 1) + 0.5) * step - step
    G = np.stack(np.meshgrid(gx, gy), -1).reshape(-1, 2)
    sel = om.inside(G, [P2]) | (om.seg_distance(G, P2) < step)
    band = 0.3 * L
    cells, hosts = [], []
    for k in np.nonzero(sel)[0]:
        p = origin + X * float(G[k, 0]) + Y * float(G[k, 1])
        h = cm._cast(context, dg, p + N * band, -N, skip)
        if h is None or h[0] > 2.0 * band:
            continue
        name = h[2].name
        if name not in hosts:
            hosts.append(name)
        cells.append([round(float(G[k, 0]), 7), round(float(G[k, 1]), 7), round(band - h[0], 7), hosts.index(name)])
    return dict(step=step, cells=cells, hosts=hosts) if cells else None


def attach_disp(pts, A, L):
    """(how far each point of the wing moves along its plane's normal, the mesh holding it: host index or -1): the
    points over a mesh onto it, the rest of the wing easing back into its plane within a quarter of its length."""
    cells = np.asarray(A['cells'], float)
    step = float(A['step'])
    n = len(pts)
    out = np.zeros(n)
    held = np.full(n, -1, np.int64)
    if not len(cells):
        return out, held
    kd = KDTree(len(cells))
    for i, c in enumerate(cells):
        kd.insert((float(c[0]), float(c[1]), 0.0), i)
    kd.balance()
    blend = 0.25 * L
    eps = (0.25 * step) ** 2
    for i in range(n):
        near = kd.find_n((float(pts[i][0]), float(pts[i][1]), 0.0), 6)
        d0 = near[0][2]
        if d0 >= blend:
            continue
        w = [1.0 / (dd * dd + eps) for _c, _j, dd in near]
        val = sum(wi * cells[j, 2] for wi, (_c, j, _dd) in zip(w, near)) / sum(w)
        if d0 <= 0.75 * step:
            out[i] = val
            held[i] = int(cells[near[0][1], 3])
        else:
            f = 1.0 - (d0 - 0.75 * step) / (blend - 0.75 * step)
            out[i] = val * f * f * (3.0 - 2.0 * f)
    return out, held


def main_host(A):
    """The mesh holding most of it (the one it is parented to)."""
    if not A or not A.get('cells'):
        return None
    k = np.bincount(np.asarray([c[3] for c in A['cells']], np.int64)).argmax()
    return bpy.data.objects.get(A['hosts'][int(k)])


def follow(ob, A):
    """The wing a child of the mesh holding most of it, where it is (moved / turned with it)."""
    host = main_host(A)
    if host is None or ob.parent is not None or host == ob:
        return host
    mw = ob.matrix_world.copy()
    ob.parent = host
    ob.matrix_parent_inverse = host.matrix_world.inverted_safe()
    ob.matrix_world = mw
    return host


def build(ob, context=None):
    """The wing laid from its outline and its settings (mesh, veins image, material).  Returns faces."""
    d = data(ob)
    if d is None:
        return 0
    p = ob.mch_wing
    photo = p.preset in PHOTO_LOOK
    spec = SPEC.get(PHOTO_LOOK.get(p.preset, p.preset), SPEC['DRAGONFLY'])
    P = np.array(d['outline'], float)
    fr = HFrame(P, int(d['root']) % len(P), p.flip)       # 0.24.174 its frame from the shape as drawn
    px = fr.L / 1400.0
    if photo:
        img, lo = photo_field(fr, p.preset, px, p.vein_width, spec)
    else:
        vl, stigma = veins(fr, spec, p.density, p.seed)
        if abs(p.vein_width - 1.0) > 1e-6:
            vl = [(q, r * p.vein_width, c) for q, r, c in vl]
        img, lo = raster(fr, vl, stigma, px)
    spacing = fr.L / max(p.detail, 20)
    pts, tris, nb = om.even_mesh(P, spacing)
    hv = sample(img, lo, px, pts)[:, 0]
    L = fr.L
    t = L * p.thickness / 100.0 * 0.5
    H = L * p.vein_height / 100.0
    zt = t + H * hv
    zb = -(t + 0.6 * H * hv)
    n = len(pts)
    V = np.r_[np.c_[pts, zt], np.c_[pts, zb]]
    if abs(p.bend) > 1e-6 or abs(p.twist) > 1e-6:
        V = bend_twist(V, fr, p.bend, p.twist)
    held = None
    A = d.get('attach')
    if A and p.stick:                                  # 0.24.176 the part over a mesh on it, the rest easing back
        disp, held = attach_disp(pts, A, fr.L)
        V[:n, 2] += disp
        V[n:, 2] += disp
        follow(ob, A)
    faces = [tuple(f) for f in tris.tolist()] + [tuple(int(i) + n for i in f[::-1]) for f in tris.tolist()]
    faces += [(i, (i + 1) % nb, (i + 1) % nb + n, i + n) for i in range(nb)]
    if 'lo' in d:                                      # 0.24.176 its plane in its own space: moved with what holds it
        M = np.array([d['lx'], d['ly'], d['ln']], float)
        Lc = V @ M + np.array(d['lo'], float)
    else:                                              # (a wing from before: its plane in the world)
        O = Vector(d['origin'])
        X, Y, N = Vector(d['x']), Vector(d['y']), Vector(d['n'])
        M = np.array([tuple(X), tuple(Y), tuple(N)], float)
        W3 = V @ M + np.array(tuple(O))
        inv = ob.matrix_world.inverted()
        Ml = np.array(inv)
        Lc = W3 @ Ml[:3, :3].T + Ml[:3, 3]
    me = ob.data
    bm = bmesh.new()
    vs = [bm.verts.new(tuple(c)) for c in Lc]
    for f in faces:
        try:
            bm.faces.new([vs[i] for i in f])
        except ValueError:
            pass
    top = [f for f in bm.faces if all(v.index < n for v in f.verts)]
    bot = [f for f in bm.faces if all(v.index >= n for v in f.verts)]
    bmesh.ops.join_triangles(bm, faces=top, angle_face_threshold=math.radians(20), angle_shape_threshold=math.radians(35))
    bmesh.ops.join_triangles(bm, faces=[f for f in bot if f.is_valid], angle_face_threshold=math.radians(20),
                             angle_shape_threshold=math.radians(35))
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
    uvl = bm.loops.layers.uv.new('UVMap')
    Hh, Ww = img.shape[:2]
    bm.verts.ensure_lookup_table()
    for f in bm.faces:
        for lp in f.loops:
            i = lp.vert.index % n if lp.vert.index < 2 * n else 0
            q = pts[i]
            lp[uvl].uv = ((q[0] - lo[0]) / px / (Ww - 1), (q[1] - lo[1]) / px / (Hh - 1))
    bm.to_mesh(me)
    bm.free()
    for poly in me.polygons:
        poly.use_smooth = True
    me.update()
    from . import creature_membrane as cm             # (which mesh holds which points: a Hook to each other one on Enter)
    for vg in [g for g in ob.vertex_groups if g.name.startswith(cm.HOST_PREFIX)]:
        ob.vertex_groups.remove(vg)
    if held is not None:
        for hi_, name in enumerate(A['hosts']):
            idx = [int(i) for i in np.nonzero(held == hi_)[0]]
            if idx:
                ob.vertex_groups.new(name=cm.HOST_PREFIX + name).add(idx + [i + n for i in idx], 1.0, 'REPLACE')
    # the veins' image (crisp in the material)
    iname = f'MCH Wing Veins ({ob.name})'
    im = bpy.data.images.get(iname)
    if im is not None and (im.size[0] != Ww or im.size[1] != Hh):
        bpy.data.images.remove(im)
        im = None
    if im is None:
        im = bpy.data.images.new(iname, Ww, Hh, alpha=True, float_buffer=True)
        im.colorspace_settings.name = 'Non-Color'
    rgba = np.zeros((Hh, Ww, 4), np.float32)
    rgba[..., 0] = img[..., 0]
    rgba[..., 1] = img[..., 1]
    rgba[..., 3] = 1.0
    im.pixels.foreach_set(rgba.ravel())
    im.update()
    try:
        im.pack()
    except RuntimeError:
        pass
    wing_material(ob, im, spec)
    ob['mch_wing_size'] = L
    return len(me.polygons)


def _upd(self, context):
    if _BUSY[0]:
        return
    ob = self.id_data
    if isinstance(ob, bpy.types.Object) and is_wing(ob):
        build(ob, context)
        sc = getattr(context, 'scene', None)
        if sc is not None and hasattr(sc, 'mch_wing'):
            _BUSY[0] = True
            try:
                for k in LIVE:
                    setattr(sc.mch_wing, k, getattr(self, k))
            finally:
                _BUSY[0] = False


LIVE = ('preset', 'vein_height', 'vein_width', 'density', 'thickness', 'detail', 'seed', 'flip', 'bend', 'twist', 'stick')


class MCH_PG_Wing(bpy.types.PropertyGroup):
    preset: EnumProperty(name='Wing', items=PRESET_ITEMS, default='DRAGONFLY', update=_upd)
    vein_height: FloatProperty(name='Vein Height %', default=0.6, min=0.0, max=5.0, soft_max=2.0, update=_upd,
                               description='How far the veins stand out (raised), % of the wing\'s length')
    vein_width: FloatProperty(name='Vein Width', default=1.0, min=0.2, max=4.0, update=_upd)
    density: FloatProperty(name='Vein Density', default=1.0, min=0.3, max=3.0, update=_upd,
                           description='More cross veins and smaller cells')
    thickness: FloatProperty(name='Thickness %', default=0.15, min=0.01, max=3.0, update=_upd,
                             description='The membrane\'s thickness, % of the wing\'s length')
    detail: IntProperty(name='Detail', default=220, min=40, max=600, update=_upd,
                        description='Points along the wing\'s length (more: sharper raised veins, heavier)')
    seed: IntProperty(name='Seed', default=0, min=0, update=_upd)
    bend: FloatProperty(name='Bend', default=0.0, min=-math.radians(150), max=math.radians(150), subtype='ANGLE',
                        update=_upd, description='Bent along its length from the root (+: toward you)')
    twist: FloatProperty(name='Twist', default=0.0, min=-math.radians(120), max=math.radians(120), subtype='ANGLE',
                         update=_upd, description='Twisted round its length from the root')
    flip: BoolProperty(name='Flip Leading Edge', default=False, update=_upd,
                       description='The veins along the other edge')
    stick: BoolProperty(name='Stick to Mesh', default=True, update=_upd,
                        description='As Creature Cloth: the part drawn over a mesh sits on it, the rest eases back into the '
                                    'wing; the wing follows that mesh (its child; on Enter a Hook to each other mesh it is on)')


# ---- drawing -------------------------------------------------------------------------------------------------------

def perform(context, loops, projector, start=None):
    """``start``: where the drawing was started (screen; else the first drawn point) - 0.24.176 (user: "벌레 날개도 처음
    선 긋는 부분이 벌레 날개 [뿌리] 되게 해 줘") the wing's root is there, always (before: the point nearest a mesh)."""
    from . import base_mesh
    from . import core_geometry as cg
    if start is None:
        try:
            start = tuple(loops[0][0])
        except (IndexError, TypeError):
            start = None
    groups = cg.prepare_loops(loops)
    if not groups:
        raise cg.CutError('Draw a bigger wing')
    outer = max((g[0] for g in groups), key=lambda lp: abs(cg.signed_area(lp)))   # (a sketch: its biggest shape)
    origin, X, Y, N = base_mesh.plane_frame(context, projector, groups)
    P3, P2, Q = [], [], []
    for q in outer:
        o, dvec = projector.ray(q)
        o, dvec = Vector(o), Vector(dvec)
        den = dvec.dot(N)
        if abs(den) < 1e-9:
            continue
        p = o + dvec * ((origin - o).dot(N) / den)
        P3.append(tuple(p))
        P2.append(((p - origin).dot(X), (p - origin).dot(Y)))
        Q.append((float(q[0]), float(q[1])))
    if len(P2) < 3:
        raise cg.CutError('Draw the wing facing you')
    P2 = np.array(P2, float)
    step = max(1, len(P2) // 400)
    P2, P3, Q = P2[::step], P3[::step], np.array(Q[::step], float)
    length = float(np.linalg.norm(P2 - P2[:, None], axis=2).max()) if len(P2) < 2000 else float(np.ptp(P2, axis=0).max())
    if length < 1e-6:
        raise cg.CutError('Draw a bigger wing')
    if start is not None:                              # (the drawn outline point nearest where it was started)
        root = int(np.argmin(((Q - np.array(start[:2], float)) ** 2).sum(1)))
    else:
        root = 0
    st = context.scene.mch_wing
    A = attach_map(context, P2, origin, X, Y, N, length)       # 0.24.176 (before it exists: not on itself)
    me = bpy.data.meshes.new('Insect Wing')
    ob = bpy.data.objects.new('Insect Wing', me)
    (context.collection or context.scene.collection).objects.link(ob)
    ob.matrix_world = __import__('mathutils').Matrix.Translation(Vector(P3[root]))
    Mi = ob.matrix_world.inverted()
    R = Mi.to_3x3()
    ob[KEY] = json.dumps(dict(outline=P2.round(7).tolist(), root=int(root),
                              origin=tuple(origin), x=tuple(X), y=tuple(Y), n=tuple(N),
                              lo=tuple(Mi @ origin), lx=tuple(R @ X), ly=tuple(R @ Y), ln=tuple(R @ N), attach=A))
    _BUSY[0] = True
    try:
        for k in LIVE:
            setattr(ob.mch_wing, k, getattr(st, k))
    finally:
        _BUSY[0] = False
    nf = build(ob, context)
    for o in context.selected_objects:
        o.select_set(False)
    ob.select_set(True)
    context.view_layer.objects.active = ob
    where = 'its root where you started drawing'
    if A and ob.mch_wing.stick and ob.parent is not None:
        others = [h for h in A['hosts'] if h != ob.parent.name]
        where += f', on {ob.parent.name}' + (f' (+ {", ".join(others)})' if others else '') + ' - it follows it'
    return (f'{ob.name}: a {dict((i[0], i[1]) for i in PRESET_ITEMS)[ob.mch_wing.preset]} wing ({nf:,} faces), {where} '
            f'- Enter: keep')


def apply_wing(ob, context=None):
    """Kept as it is (no longer live); 0.24.176 the points on other meshes than the one it is a child of: a Hook to
    each (as Creature Cloth).  Returns those meshes' names."""
    hooked = []
    if context is not None and ob.parent is not None and ob.mch_wing.stick:
        from . import creature_membrane as cm
        hooked = cm.hook_hosts(context, ob)
    for k in (KEY, 'mch_wing_size'):
        if k in ob.keys():
            del ob[k]
    ob['mch_wing_done'] = 1
    return hooked


def apply_targets(context):
    sel = [o for o in getattr(context, 'selected_objects', []) or [] if is_wing(o)]
    return sel or ([active_wing(context)] if active_wing(context) is not None else [])


class MCH_OT_wing_apply(bpy.types.Operator):
    """The selected insect wings kept as they are (no longer live)"""
    bl_idname = 'mch.wing_apply'
    bl_label = 'Apply Insect Wing'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and bool(apply_targets(context))

    def execute(self, context):
        obs = apply_targets(context)
        hooked = []
        for ob in obs:
            hooked += apply_wing(ob, context)
        self.report({'INFO'}, 'Insect Wing kept: ' + ', '.join(o.name for o in obs)
                    + (f' (also held by {", ".join(hooked)}: hooks)' if hooked else ''))
        return {'FINISHED'}


class MCH_OT_wing_preset(bpy.types.Operator):
    """This kind of wing (the selected wing too)"""
    bl_idname = 'mch.wing_preset'
    bl_label = 'Insect Wing Preset'
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}
    preset: EnumProperty(items=PRESET_ITEMS)

    def execute(self, context):
        ob = active_wing(context)
        (ob.mch_wing if ob is not None else context.scene.mch_wing).preset = self.preset
        if ob is not None:
            _BUSY[0] = True
            try:
                context.scene.mch_wing.preset = self.preset
            finally:
                _BUSY[0] = False
        return {'FINISHED'}


def draw(layout, context):
    st = context.scene.mch_wing
    ob = active_wing(context)
    pg = ob.mch_wing if ob is not None else st
    col = layout.column(align=True)
    col.label(text=f'{ob.name}: {len(ob.data.polygons):,} faces (live)' if ob is not None else 'The next wing')
    g = layout.grid_flow(row_major=True, columns=3, even_columns=True, align=True)
    for pid, label, _s in PRESETS:
        g.operator('mch.wing_preset', text=label, depress=pg.preset == pid).preset = pid
    layout.label(text='From photos (white = raised vein)')
    g = layout.grid_flow(row_major=True, columns=2, even_columns=True, align=True)
    for pid, label, *_r in wp.PHOTOS:
        g.operator('mch.wing_preset', text=label.replace(' (Photo)', ' Photo'), depress=pg.preset == pid).preset = pid
    col = layout.column(align=True)
    for k in ('bend', 'twist', 'vein_height', 'vein_width', 'density', 'thickness', 'detail', 'seed'):
        col.prop(pg, k)
    col.prop(pg, 'flip')
    col.prop(pg, 'stick')                              # 0.24.176
    if ob is not None:
        layout.operator('mch.wing_apply', text='Apply (Enter)', icon='CHECKMARK')
    col = layout.column(align=True)
    for line in HELP:
        col.label(text=line)


HELP = ('Draw a wing\'s outline: the veins raised inside it',
        'Its root: where you start drawing',
        'Drawn over a mesh: it sits on it and follows it (Stick to Mesh)',
        'Select a wing: its sliders lay it again;  Enter: keep')

CLASSES = (MCH_PG_Wing, MCH_OT_wing_apply, MCH_OT_wing_preset)


def register():
    for c in CLASSES:
        bpy.utils.register_class(c)
    bpy.types.Scene.mch_wing = PointerProperty(type=MCH_PG_Wing)
    bpy.types.Object.mch_wing = PointerProperty(type=MCH_PG_Wing)


def unregister():
    for T in (bpy.types.Scene, bpy.types.Object):
        if hasattr(T, 'mch_wing'):
            delattr(T, 'mch_wing')
    for c in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(c)
        except RuntimeError:
            pass
