"""0.24.73 Mesh Tools (sidebar, Mecha Lab tab): the ZBrush shelf's DynaMesh, Decimate, Quad Remesh, Edge Mesh and Hard
Edges in Object Mode, on every selected mesh at once - the same settings as the shelf (``scene.mch_zb``), so a part
started on the ZBrush screen goes on here and the other way round.  One undo step for the whole run; a mesh that
can't be done is skipped with its reason (the others still run).
"""
from __future__ import annotations

import math

import bpy
from bpy.props import StringProperty

ACTIONS = {'DYNAMESH': 'DynaMesh', 'DECIMATE': 'Decimate', 'QUAD_REMESH': 'Quad Remesh', 'EDGE_MESH': 'Edge Mesh',
           'HE_FIND': 'Find Edges', 'HE_APPLY': 'Apply', 'HE_CLEAR': 'Clear', 'FIX_MESH': 'Fix Mesh', 'REFIX': 'Re-Fix',
           'BAKE_HP': 'Bake High Poly', 'BAKE_HP_KEEP': 'Bake High Poly (Keep Bevels)',
           'BAKE_HP_ROUND': 'Bake High Poly (Round Bevels)', 'BAKE_HP_DIVIDE': 'Bake High Poly (Divide)'}
HEAVY = {'DYNAMESH', 'DECIMATE', 'QUAD_REMESH', 'EDGE_MESH', 'HE_FIND', 'HE_APPLY', 'REFIX', 'BAKE_HP', 'BAKE_HP_KEEP',
         'BAKE_HP_ROUND', 'BAKE_HP_DIVIDE'}
BAKE_MODES = {'BAKE_HP_KEEP': 'KEEP', 'BAKE_HP_ROUND': 'ROUND', 'BAKE_HP_DIVIDE': 'DIVIDE'}   # 0.24.95 the right-click buttons (user: "라운드도 우클릭
#                                                               팝업에 등록해 줘, 킵이랑"): the Bevels setting, then Bake HP


class MCH_OT_bake_copy_toggle(bpy.types.Operator):
    """0.24.95 Bake High Poly Copy on / off from the right-click menus (user: "왜 복사가 돼? 그것도 버튼으로 끌 수 있게")"""
    bl_idname = 'mch.bake_copy_toggle'
    bl_label = 'Bake HP Copy'
    bl_description = ('Bake High Poly: on = a "<part>_BakeHP" copy (the part hidden); off = the part itself becomes the '
                      'high poly (Ctrl+Z gets it back)')
    bl_options = {'REGISTER'}

    def execute(self, context):
        zb = context.scene.mch_zb
        zb.bk_copy = not zb.bk_copy
        self.report({'INFO'}, 'Bake High Poly: ' + ('makes a copy' if zb.bk_copy else 'changes the part itself (no copy)'))
        return {'FINISHED'}


def bake_mode(zb, action):
    """BAKE_HP_KEEP / _ROUND set the Bake High Poly Bevels setting (it stays, the panel shows it); True for any Bake HP."""
    if action in BAKE_MODES:
        zb.bk_bevels = BAKE_MODES[action]
    return action == 'BAKE_HP' or action in BAKE_MODES


def _targets(context):
    return [o for o in context.selected_objects if o.type == 'MESH']


def run_one(context, ob, zb, action):
    """``action`` on mesh object ``ob`` (Object Mode).  Returns a message; raises RuntimeError when it can't."""
    from . import edge_mesh as em
    from . import fast_decimate as fd
    from . import hard_edges as he
    from . import quad_field as qf
    from . import zb_sculpt as zs
    if zs.multires(ob) is not None:
        raise RuntimeError('has subdivision levels (Multires) - apply or remove them first')
    if action == 'DYNAMESH':
        from . import voxel_for_points
        v = voxel_for_points(context, ob, zb.points)
        if v <= 0.0:
            raise RuntimeError('no surface')
        ob.data.remesh_voxel_size = v
        from . import edge_memory as em
        kept = em.remember(ob.data)                  # 0.24.95
        with context.temp_override(object=ob, active_object=ob, selected_objects=[ob],
                                   selected_editable_objects=[ob]):
            bpy.ops.object.voxel_remesh()
        n_mem = em.restore(ob.data, kept)
        return f'DynaMesh: {len(ob.data.vertices):,} points' + (f', {n_mem:,} remembered edges back' if n_mem else '')
    if action == 'DECIMATE':
        if not fd.available():
            msg = fd.blender_decimate(context, ob, zb.decimate)
        else:
            msg = fd.decimate_object(ob, zb.decimate, even=zb.dec_even, quads=zb.dec_quads, keep_mask=zb.dec_mask,
                                     keep_groups=zb.dec_groups, keep_borders=zb.dec_borders)
        zs.shade_result(ob, zb)                      # 0.24.85
        return msg
    if action == 'QUAD_REMESH':
        bg = zs.background_job(context, ob, zb, 'QUAD_REMESH')     # 0.24.86
        if bg:
            return bg
        msg = qf.remesh_object(ob, max(1, int(round(zb.qr_target * 1000))), all_quads=zb.qr_mode == 'ALL',
                               crease_deg=math.degrees(zb.qr_angle), flow=zb.qr_flow)
        zs.shade_result(ob, zb)
        return msg + qf.set_subdiv(ob, zb.qr_subd)
    if action == 'EDGE_MESH':
        if not fd.available():
            raise RuntimeError('the Fast Decimate engine is not available on this system')
        return em.build(context, ob, zb)
    if action == 'HE_FIND':
        if len(ob.data.polygons) > he.MAX_POLYS:
            raise RuntimeError(f'{len(ob.data.polygons):,} polygons - Decimate, Quad Remesh or Edge Mesh first')
        if ob.data.shape_keys is not None:
            raise RuntimeError('remove the shape keys first')
        n, _f0, _f1 = he.find(ob, zb)
        he.set_live(ob, zb)
        return f'Hard Edges: {n:,} edges'
    if action == 'HE_APPLY':
        k = he.apply_live(context, ob, zb)
        ob.pop(he.KEY, None)
        return f'Hard Edges: applied, {len(ob.data.polygons):,} polygons' if k else 'Hard Edges: nothing to apply'
    if action == 'HE_CLEAR':
        he.clear(ob)
        return 'Hard Edges: cleared'
    if action == 'REFIX':                            # 0.24.84 DynaMesh > clean Decimate / Quad Remesh
        from . import refix
        bg = zs.background_job(context, ob, zb, 'REFIX')          # 0.24.86
        if bg:
            return bg
        return refix.run(context, ob, zb)
    if bake_mode(zb, action):                        # 0.24.95 hard edges fixed, the rest subdivided + rounded
        from . import bake_highpoly as bk
        return bk.run(context, ob, zb)
    if action == 'FIX_MESH':                         # 0.24.76 like ZBrush's Fix Mesh
        from . import mesh_fix
        if ob.data.shape_keys is not None:
            raise RuntimeError('remove the shape keys first')
        return mesh_fix.report(mesh_fix.fix_part(context, ob))    # 0.24.95 a live Mirror's holes too
    raise RuntimeError(f'unknown action {action}')


class MCH_OT_mesh_tool(bpy.types.Operator):
    """DynaMesh / Decimate / Quad Remesh / Edge Mesh / Hard Edges on the selected meshes (Object Mode; the ZBrush
    shelf's settings)"""
    bl_idname = 'mch.mesh_tool'
    bl_label = 'Mesh Tool'
    bl_options = {'REGISTER', 'UNDO'}
    action: StringProperty()

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and hasattr(context.scene, 'mch_zb') and bool(_targets(context))

    @classmethod
    def description(cls, context, props):
        if props.action == 'DECIMATE':                       # 0.24.143 (the right-click button)
            zb = getattr(context.scene, 'mch_zb', None)
            keep = zb.decimate if zb is not None else 20
            return (f'Decimate the selected meshes: keep {keep}% of their faces (detail stays where the shape needs it) - '
                    f'the % is Mesh Tools\' Decimate % in the sidebar')
        return f'{ACTIONS.get(props.action, props.action)} on the selected meshes (settings shared with the ZBrush shelf)'

    def execute(self, context):
        zb = context.scene.mch_zb
        obs = _targets(context)
        name = ACTIONS.get(self.action, self.action)
        if self.action in HEAVY:
            try:
                from . import safety_save
                safety_save.before_risky('Mesh Tools ' + name)
            except (ImportError, AttributeError, RuntimeError):
                pass
        wm = context.window_manager
        done, last, skipped = 0, '', []
        wm.progress_begin(0, len(obs))
        try:
            from . import armor_shell
            for k, ob in enumerate(obs):
                try:
                    armor_shell.bake_live(context, ob)      # 0.24.80 a live Armor Shell: on the shell, not its base
                    last = run_one(context, ob, zb, self.action)
                    done += 1
                except (RuntimeError, ValueError, MemoryError) as ex:
                    skipped.append(f'{ob.name}: {str(ex).splitlines()[0] if str(ex) else type(ex).__name__}')
                wm.progress_update(k + 1)
        finally:
            wm.progress_end()
        if not done:
            self.report({'WARNING'}, f'{name}: ' + ('; '.join(skipped[:3]) or 'nothing done'))
            return {'CANCELLED'}
        msg = last if len(obs) == 1 else f'{name}: {done} of {len(obs)} meshes'
        if skipped:
            msg += f' - skipped {len(skipped)}: ' + '; '.join(skipped[:3])
        self.report({'WARNING'} if skipped else {'INFO'}, msg)
        return {'FINISHED'}


def qf_options(layout, zb, ob):
    """0.24.281 Quad Remesh: Hard Edges (how sharp a fold is a fixed line), Flow (how much the softer folds steer the
    quads), Subdivision (levels of a Subdivision Surface on the result; the result's own modifier when it has one)."""
    col = layout.column(align=True)
    col.prop(zb, 'qr_angle', text='Hard Edges')
    col.prop(zb, 'qr_flow', slider=True)
    r = col.row(align=True)
    r.prop(zb, 'qr_subd')
    from . import quad_field as qf
    mod = qf.subdiv_modifier(ob)
    if mod is not None:
        r.prop(mod, 'levels', text='Now')
        r.operator('mch.quad_subdiv', text='', icon='X').levels = 0


class MCH_OT_quad_subdiv(bpy.types.Operator):
    """Quad Remesh Subdivision on the selected parts now (0: take it off)"""
    bl_idname = 'mch.quad_subdiv'
    bl_label = 'Quad Remesh Subdivision'
    bl_options = {'REGISTER', 'UNDO'}
    levels: bpy.props.IntProperty(min=0, max=4)

    def execute(self, context):
        from . import quad_field as qf
        for o in _targets(context):
            qf.set_subdiv(o, self.levels)
        return {'FINISHED'}


def draw(layout, context):
    zb = getattr(context.scene, 'mch_zb', None)
    if zb is None:
        return

    def op(row, text, action):
        row.operator('mch.mesh_tool', text=text).action = action
    box = layout.box()
    box.label(text='MESH TOOLS  (selected meshes)', icon='MOD_REMESH')
    r = box.row(align=True)
    op(r, 'DynaMesh', 'DYNAMESH')
    r.prop(zb, 'points', text='Points')
    box.row(align=True).operator('mch.mesh_tool', text='Fix Mesh (cracks, slivers, inside walls, holes, mirror holes)',
                                 icon='TOOL_SETTINGS').action = 'FIX_MESH'
    from . import refix
    refix.draw_row(box, zb)                          # 0.24.84 Re-Fix
    col = box.column(align=True)
    r = col.row(align=True)
    op(r, 'Decimate', 'DECIMATE')
    r.prop(zb, 'decimate', text='%')
    r = col.row(align=True)
    r.prop(zb, 'dec_even', toggle=True)
    r.prop(zb, 'dec_quads', toggle=True)
    r.prop(zb, 'dec_borders', toggle=True)
    col.row(align=True).prop(zb, 'result_shade', expand=True)     # 0.24.85 result shading (export-ready)
    col = box.column(align=True)
    r = col.row(align=True)
    op(r, 'Quad Remesh', 'QUAD_REMESH')
    r.prop(zb, 'qr_target', text='Target')
    r.prop(zb, 'bg_jobs', text='Background', toggle=True)        # 0.24.86
    from . import bg_jobs
    bg_jobs.draw_status(col, context.active_object)
    col.row(align=True).prop(zb, 'qr_mode', expand=True)
    qf_options(col, zb, context.active_object)          # 0.24.281 Hard Edges / Flow / Subdivision
    col = box.column(align=True)
    r = col.row(align=True)
    op(r, 'Edge Mesh', 'EDGE_MESH')
    r.prop(zb, 'em_detail', text='Detail')
    r = col.row(align=True)
    r.prop(zb, 'em_auto', toggle=True)
    r.prop(zb, 'em_tolerance')
    r = col.row(align=True)
    r.prop(zb, 'em_adaptive', toggle=True)
    r.prop(zb, 'em_straight', toggle=True)
    r = col.row(align=True)
    r.prop(zb, 'he_fit', toggle=True)
    r.prop(zb, 'he_match', toggle=True)
    col = box.column(align=True)
    r = col.row(align=True)
    op(r, 'Find Edges', 'HE_FIND')
    r.prop(zb, 'he_angle')
    col.row(align=True).prop(zb, 'he_style', expand=True)
    r = col.row(align=True)
    r.prop(zb, 'he_width')
    r.prop(zb, 'he_segments')
    r = col.row(align=True)
    r.prop(zb, 'he_subdiv')
    r.prop(zb, 'he_client', toggle=True)
    r = col.row(align=True)
    op(r, 'Apply', 'HE_APPLY')
    op(r, 'Clear', 'HE_CLEAR')
    from . import bake_highpoly as bk                # 0.24.95
    col = box.column(align=True)
    bk.draw_rows(col, zb, op)
    from . import bake_maps                          # 0.24.95 bake the high onto the low (Normal / AO / Color)
    bake_maps.draw(layout, context)
    from . import final_export                       # 0.24.95 high copies at the Final Resolution + low / high FBX
    final_export.draw(layout, context)


class MCH_PT_mesh_tools(bpy.types.Panel):
    bl_idname = 'MCH_PT_mesh_tools'
    bl_label = 'Mesh Tools'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Mecha Lab'
    bl_order = 79

    @classmethod
    def poll(cls, context):
        from . import tool_state as ts
        return context.mode == 'OBJECT' and ts.sidebar_select(context)

    def draw(self, context):
        draw(self.layout, context)


CLASSES = (MCH_OT_mesh_tool, MCH_OT_bake_copy_toggle, MCH_PT_mesh_tools, MCH_OT_quad_subdiv)


def register():
    for c in CLASSES:
        bpy.utils.register_class(c)


def unregister():
    for c in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(c)
        except RuntimeError:
            pass
