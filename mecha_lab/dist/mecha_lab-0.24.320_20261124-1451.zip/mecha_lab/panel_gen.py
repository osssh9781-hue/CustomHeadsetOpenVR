"""Panel generator shared by Face Extract (Basic) and Armor Sculpt.

Not an Extrude + Bevel modifier chain: the solid is BUILT from a cross-section
profile, so chamfer width, angle and depth, the chamfer direction and the
outer (base) edge are controlled independently and exactly.

Input: a copy of the selected face region (any curvature, holes allowed) and
the surrounding surface (for projecting rings that go outward).

    top cap  - the region, shrunk to make room for the edge band, lifted along
               the surface normals by the height field
    top band - rings following the TOP EDGE profile (chamfer / bevel fillets)
    wall     - the side wall down to the base
    bottom   - rings following the OUTER (BASE) EDGE profile + bottom cap
               (omitted when Thickness > 0: the part becomes a shell, closed
               by a Solidify modifier)

Every ring has exactly one vertex per boundary vertex, so the result is built
from index tables and is always a closed, consistently oriented solid.

Cross-section coordinates per boundary vertex ("column"): ``s`` = distance
INTO the region along the surface (negative = outward), ``z`` = height above
the surface (plus Surface Offset).

Armor Sculpt adds a local N/E/S/W frame (average normal + principal axis,
user rotation / scale / offset / mirror): every edge setting and the top
height are blended between the four directions with a smooth partition of
unity, and a centre-line ridge field (6 presets) changes the real top
heights.  Pure functions here; Blender data handling is in face_extract.py.
"""
from __future__ import annotations

import heapq
import math
import random

import bmesh
from mathutils import Matrix, Vector
from mathutils.bvhtree import BVHTree

DIRS = ('N', 'E', 'S', 'W')
DIR_ANGLE = {'E': 0.0, 'N': math.pi / 2, 'W': math.pi, 'S': 1.5 * math.pi}


class PanelError(Exception):
    pass


# =============================================================================
# Small math helpers
# =============================================================================


def dir_weights(theta):
    """Smooth partition of unity over the 4 local directions (sum = 1)."""
    c, s = math.cos(theta), math.sin(theta)
    return {'E': max(c, 0.0) ** 2, 'W': max(-c, 0.0) ** 2, 'N': max(s, 0.0) ** 2, 'S': max(-s, 0.0) ** 2}


def smoothstep(t):
    t = min(1.0, max(0.0, t))
    return t * t * (3.0 - 2.0 * t)


def smooth_max(a, b, k):
    """Polynomial smooth maximum (k = blend width, 0 = hard max)."""
    if k <= 1e-9:
        return max(a, b)
    h = max(k - abs(a - b), 0.0) / k
    return max(a, b) + h * h * k * 0.25


def _resample(points, n):
    """Resample a polyline to ``n`` points by arc length (keeps both ends)."""
    if n <= 1 or len(points) == 1:
        return [points[0]] * max(n, 1) if n > 1 and len(points) == 1 else list(points[:1])
    acc = [0.0]
    for i in range(1, len(points)):
        acc.append(acc[-1] + math.dist(points[i - 1], points[i]))
    total = acc[-1]
    if total < 1e-12:
        return [points[0]] * n
    out, j = [], 0
    for k in range(n):
        t = total * k / (n - 1)
        while j < len(acc) - 2 and acc[j + 1] < t:
            j += 1
        span = acc[j + 1] - acc[j] or 1.0
        f = (t - acc[j]) / span
        a, b = points[j], points[j + 1]
        out.append((a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f))
    return out


def _fillet(prev_pt, corner, next_pt, size, segments, profile):
    """Rounded corner points between segments prev->corner->next.
    profile 0.5 = round, 1 = boxy, 0 = straight chamfer."""
    a = Vector((corner[0] - prev_pt[0], corner[1] - prev_pt[1]))
    b = Vector((next_pt[0] - corner[0], next_pt[1] - corner[1]))
    la, lb = a.length, b.length
    if size <= 1e-9 or la < 1e-9 or lb < 1e-9 or segments < 1:
        return [corner]
    t = min(size, la * 0.5, lb * 0.5)
    a.normalize()
    b.normalize()
    p1 = Vector(corner) - a * t
    p2 = Vector(corner) + b * t
    mid = (p1 + p2) * 0.5
    ctrl = mid + (Vector(corner) - mid) * (2.0 * max(0.0, min(1.0, profile)))
    pts = []
    for k in range(segments + 1):
        u = k / segments
        q = p1 * (1 - u) ** 2 + ctrl * (2 * u * (1 - u)) + p2 * u * u
        pts.append((q.x, q.y))
    return pts


def edge_molding_profiles(p, height, top, bot, shell=False):
    """0.24.298 Top / Bottom Edge Molding on the plate's outer wall: the top profile (wall -> cap, z from the top) and
    the bottom one (wall -> base, z from the base) with a band standing out ``emold_out`` at the top (+ a Lip up round
    the top face) and a flange at the bottom.  The profiles as they were when both are off."""
    top_on = bool(getattr(p, 'emold_top', False))
    bot_on = bool(getattr(p, 'emold_bottom', False)) and not shell
    if not (top_on or bot_on) or height <= 1e-9:
        return top, bot
    t = float(getattr(p, 'emold_out', 0.0))           # (0.24.302 < 0: in)
    band = float(getattr(p, 'emold_band', 0.0)) or height * 0.25
    band = min(band, height * (0.45 if top_on and bot_on else 0.9))
    shape = getattr(p, 'emold_shape', 'SQUARE')
    ws = top[0][0]
    k = 6
    if top_on:
        if shape == 'SLOPE':
            nt = [(ws, -band)]                          # 0.24.302 straight from the wall to the top edge
        elif shape == 'CHAMFER':
            c = min(abs(t), band * 0.6)
            nt = [(ws, -band), (ws - t, -band + c)]
        elif shape == 'ROUND':
            nt = [(ws - t * math.sin(math.pi / 2 * j / k), -band * math.cos(math.pi / 2 * j / k)) for j in range(k)]
        else:
            nt = [(ws, -band), (ws - t, -band)]
        lip = float(getattr(p, 'emold_lip', 0.0))
        if lip > 0.0:
            rim = max(abs(t) * 1.5, band * 0.25)
            nt += [(ws - t, lip), (ws - t + rim, lip), (ws - t + rim, 0.0)]
        else:
            nt.append((ws - t, 0.0))
        top = nt
    if bot_on:
        if shape == 'SLOPE':
            bot = [(ws, band), (ws - t, 0.0)]
        elif shape == 'CHAMFER':
            c = min(abs(t), band * 0.6)
            bot = [(ws, band), (ws - t, band - c), (ws - t, 0.0)]
        elif shape == 'ROUND':
            bot = [(ws - t * math.sin(math.pi / 2 * j / k), band * math.cos(math.pi / 2 * j / k)) for j in range(k + 1)]
        else:
            bot = [(ws, band), (ws - t, band), (ws - t, 0.0)]
    return top, bot


def edge_profile(width, depth, direction='IN', bevel=0.0, segments=0, profile=0.5, wall_room=1e9):
    """Cross-section of an edge as (s, z) points from the wall end to the cap
    end.  The flat face is z = 0 for s >= end, the wall is at the first point's
    ``s`` going to z -> -inf.  Chamfer: horizontal ``width`` x vertical
    ``depth``; IN cuts into the face, OUT flares outward (wall moves out)."""
    width = max(0.0, width)
    depth = max(0.0, min(depth, wall_room * 0.95))
    if direction == 'OUT' and width > 0 and depth > 0:
        corners = [(-width, -depth), (0.0, 0.0)]
        wall_s = -width
    elif width > 0 and depth > 0:
        corners = [(0.0, -depth), (width, 0.0)]
        wall_s = 0.0
    else:
        corners = [(0.0, 0.0)]
        wall_s = 0.0
    far = 1e3
    chain = [(wall_s, -far)] + corners + [(corners[-1][0] + far, 0.0)]
    bevel = max(0.0, bevel)
    if bevel > 0 and segments >= 1:
        # a fillet on the wall side may not run below the available wall height
        out = [chain[0]]
        for k in range(1, len(chain) - 1):
            size = bevel
            if k == 1:
                size = min(bevel, max(wall_room * 0.9 - depth, 0.0))
            out.extend(_fillet(chain[k - 1], chain[k], chain[k + 1], size, segments, profile))
        out.append(chain[-1])
        chain = out
    pts = chain[1:-1]
    return pts


# =============================================================================
# Region analysis
# =============================================================================


def fix_bowties(bm):
    """0.24.292 (user: armor plate "Plate could not be built: the selection touches itself at a single vertex") a
    region drawn on a dense sculpt often meets itself at one point (two face fans sharing a corner): the point is
    split so each fan has its own, and bits hanging on by such a point (under 5 % of the biggest piece) are dropped.
    Returns the number of points split."""
    n = 0
    for _round in range(3):
        bad = []
        for v in bm.verts:
            bnd = [e for e in v.link_edges if len(e.link_faces) == 1]
            if len(bnd) > 2:
                bad.append((v, bnd))
        if not bad:
            break
        for v, bnd in bad:
            if v.is_valid:
                bmesh.utils.vert_separate(v, [e for e in bnd if e.is_valid])
                n += 1
    if n:
        islands, seen = [], set()
        for f in bm.faces:
            if f in seen:
                continue
            stack, isl = [f], []
            seen.add(f)
            while stack:
                g = stack.pop()
                isl.append(g)
                for e in g.edges:
                    for h in e.link_faces:
                        if h not in seen:
                            seen.add(h)
                            stack.append(h)
            islands.append(isl)
        big = max(len(i) for i in islands)
        drop = [f for i in islands if len(i) < 0.05 * big for f in i]
        if drop:
            bmesh.ops.delete(bm, geom=drop, context='FACES')
        bm.verts.ensure_lookup_table()
        bm.normal_update()
    return n


def _fill_inside(bm, n=16):
    """0.24.299 The region split into small triangles (about ``n`` across) when it has (almost) no points inside its
    outline - on a flat face it was one big face round the outline: nothing to raise for a Top Dome."""
    inner = [v for v in bm.verts if not v.is_boundary]
    if len(inner) >= max(8, len(bm.verts) // 4):
        return
    lo = Vector([min(v.co[i] for v in bm.verts) for i in range(3)])
    hi = Vector([max(v.co[i] for v in bm.verts) for i in range(3)])
    step = max((hi - lo).length / n, 1e-6)
    bmesh.ops.triangulate(bm, faces=bm.faces[:], quad_method='BEAUTY', ngon_method='BEAUTY')
    for _ in range(6):
        long_ = [e for e in bm.edges if e.calc_length() > step]
        if not long_:
            break
        bmesh.ops.subdivide_edges(bm, edges=long_, cuts=1, use_grid_fill=False)
        bmesh.ops.triangulate(bm, faces=[f for f in bm.faces if len(f.verts) > 3])
    bm.verts.ensure_lookup_table()
    bm.normal_update()


def boundary_loops(bm, faces):
    """Ordered boundary loops of a face set (region on the LEFT of each loop
    w.r.t. the face normals).  Returns lists of BMVerts."""
    fset = set(faces)
    nxt = {}
    for f in faces:
        for lp in f.loops:
            e = lp.edge
            if sum(1 for lf in e.link_faces if lf in fset) == 1:
                a, b = lp.vert, lp.link_loop_next.vert
                if a in nxt:
                    raise PanelError('The selection touches itself at a single vertex; select a cleaner region.')
                nxt[a] = b
    loops, seen = [], set()
    for start in list(nxt):
        if start in seen:
            continue
        loop, v = [], start
        while v not in seen:
            seen.add(v)
            loop.append(v)
            v = nxt.get(v)
            if v is None:
                raise PanelError('Open boundary could not be followed.')
        loops.append(loop)
    if not loops:
        raise PanelError('The selection has no boundary (a closed surface cannot be extracted as a panel).')
    return loops


def facet_lines(style, count, seed, rotation, pts2d, radius, offset=0.0):
    """0.19.2 surface lines: crease lines across the plate top in the frame
    plane.  ``pts2d`` = region vertices in frame coordinates (x, y).  Returns
    [(px, py, angle, sign)]: a line through (px, py) at ``angle``; sign +1 =
    raised ridge, -1 = sunken valley."""
    if style == 'NONE' or not pts2d:
        return []
    n = len(pts2d)
    mx = sum(p[0] for p in pts2d) / n
    my = sum(p[1] for p in pts2d) / n
    sxx = sum((p[0] - mx) ** 2 for p in pts2d)
    syy = sum((p[1] - my) ** 2 for p in pts2d)
    sxy = sum((p[0] - mx) * (p[1] - my) for p in pts2d)
    a = 0.5 * math.atan2(2.0 * sxy, sxx - syy) + rotation       # long axis
    mx, my = mx - math.sin(a) * offset, my + math.cos(a) * offset  # 0.19.4: move across the main line
    if style == 'CENTER':
        return [(mx, my, a, 1.0)]
    if style == 'CROSS':
        return [(mx, my, a, 1.0), (mx, my, a + math.pi / 2, 1.0)]
    rng = random.Random(int(seed))
    out = []
    for _i in range(max(1, int(count))):
        ang = a + rng.uniform(-math.pi / 2, math.pi / 2)
        off = rng.uniform(-0.55, 0.55) * radius
        out.append((mx - math.sin(ang) * off, my + math.cos(ang) * off, ang, rng.choice((1.0, -1.0))))
    return out


def line_dist(line, x, y):
    px, py, ang, _s = line
    return (x - px) * -math.sin(ang) + (y - py) * math.cos(ang)


def facet_value(lines, x, y, fall, half=0.0):
    """Tent field: +-1 on a line (a flat band of half width ``half``), falling
    linearly to 0 at ``fall`` beyond the band."""
    return sum(l[3] * max(0.0, 1.0 - max(0.0, abs(line_dist(l, x, y)) - half) / fall) for l in lines)


def region_frame(verts, faces):
    """Centre, unit normal, tangent T, bitangent B, radius."""
    area_n = Vector()
    cen = Vector()
    tot = 0.0
    for f in faces:
        a = f.calc_area()
        area_n += f.normal * a
        cen += f.calc_center_median() * a
        tot += a
    if tot <= 1e-12 or area_n.length < 1e-12:
        raise PanelError('Selected faces have no area.')
    cen /= tot
    n = area_n.normalized()
    # principal axis of the projected vertices
    pts = [(v.co - cen) - n * (v.co - cen).dot(n) for v in verts]
    sxx = sum(p.x * p.x for p in pts)
    syy = sum(p.y * p.y for p in pts)
    szz = sum(p.z * p.z for p in pts)
    sxy = sum(p.x * p.y for p in pts)
    sxz = sum(p.x * p.z for p in pts)
    syz = sum(p.y * p.z for p in pts)
    cov = Matrix(((sxx, sxy, sxz), (sxy, syy, syz), (sxz, syz, szz)))
    t = Vector((1.0, 0.3, 0.1))
    for _ in range(40):                  # power iteration
        t = cov @ t
        t -= n * t.dot(n)
        if t.length < 1e-12:
            break
        t.normalize()
    if t.length < 1e-6:
        t = n.orthogonal()
    t = (t - n * t.dot(n)).normalized()
    b = n.cross(t).normalized()
    radius = max((p.length for p in pts), default=1.0) or 1.0
    return cen, n, t, b, radius


def distance_from_boundary(bm_verts, boundary_set):
    """Dijkstra edge-length distance of every vertex to the boundary."""
    dist = {v: (0.0 if v in boundary_set else math.inf) for v in bm_verts}
    heap = [(0.0, id(v), v) for v in boundary_set]
    heapq.heapify(heap)
    vset = set(bm_verts)
    while heap:
        d, _i, v = heapq.heappop(heap)
        if d > dist[v]:
            continue
        for e in v.link_edges:
            w = e.other_vert(v)
            if w not in vset:
                continue
            nd = d + e.calc_length()
            if nd < dist[w]:
                dist[w] = nd
                heapq.heappush(heap, (nd, id(w), w))
    return dist


# =============================================================================
# Centre line (ridge) guide
# =============================================================================

PRESETS = ('STRAIGHT', 'CROSS', 'Y', 'X', 'S', 'Z')


def _card(theta, p, name):
    """Blend a per-direction value (N/E/S/W) at angle theta."""
    w = dir_weights(theta)
    return sum(w[d] * getattr(p, f'cl_{d.lower()}_{name}') for d in DIRS)


def guide_branches(p):
    """Centre-line polylines in normalized local units (radius = 1) with a
    width factor per polyline: [(points, width_factor)]."""
    preset = p.cl_preset
    out = []

    def ray(angle):
        L = _card(angle, p, 'length')
        W = _card(angle, p, 'width')
        return ([(0.0, 0.0), (math.cos(angle) * L, math.sin(angle) * L)], W)
    if preset == 'STRAIGHT':
        out = [ray(math.pi / 2), ray(1.5 * math.pi)]
    elif preset == 'CROSS':
        out = [ray(a) for a in (0.0, math.pi / 2, math.pi, 1.5 * math.pi)]
    elif preset == 'Y':
        spread = p.cl_branch_angle
        out = [ray(1.5 * math.pi), ray(math.pi / 2 - spread), ray(math.pi / 2 + spread)]
    elif preset == 'X':
        spread = p.cl_branch_angle
        out = [ray(a) for a in (spread, math.pi - spread, math.pi + spread, 2 * math.pi - spread)]
    elif preset == 'S':
        ln, ls = p.cl_n_length, p.cl_s_length
        be, bw = p.cl_e_length * p.cl_curvature, p.cl_w_length * p.cl_curvature
        p0, p1, p2, p3 = Vector((0, -ls)), Vector((be, -ls / 3)), Vector((-bw, ln / 3)), Vector((0, ln))
        pts = []
        for k in range(33):
            u = k / 32
            q = p0 * (1 - u) ** 3 + p1 * 3 * u * (1 - u) ** 2 + p2 * 3 * u * u * (1 - u) + p3 * u ** 3
            pts.append((q.x, q.y))
        out = [(pts, 0.5 * (p.cl_n_width + p.cl_s_width))]
    elif preset == 'Z':
        ln, ls, le, lw = p.cl_n_length, p.cl_s_length, p.cl_e_length, p.cl_w_length
        out = [([(-lw, ln), (le, ln)], p.cl_n_width), ([(le, ln), (-lw, -ls)], 0.5 * (p.cl_e_width + p.cl_w_width)),
               ([(-lw, -ls), (le, -ls)], p.cl_s_width)]
    if p.cl_symmetry:
        out = out + [([(-x, y) for x, y in pts], w) for pts, w in out]
    # global transform (independent of the directional lengths)
    rot = p.cl_rotation
    c, s = math.cos(rot), math.sin(rot)
    res = []
    for pts, w in out:
        tp = []
        for x, y in pts:
            x, y = x * p.cl_scale_x, y * p.cl_scale_y
            tp.append((x * c - y * s + p.cl_offset_x, x * s + y * c + p.cl_offset_y))
        res.append((tp, w))
    return res


def _seg_dist(px, py, a, b):
    ax, ay = a
    bx, by = b
    dx, dy = bx - ax, by - ay
    L2 = dx * dx + dy * dy
    t = 0.0 if L2 < 1e-18 else max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / L2))
    return math.hypot(px - (ax + dx * t), py - (ay + dy * t))


def ridge_profile(kind, t, p):
    """Normalized ridge height (signed) at t = distance / half width."""
    if t >= 1.0:
        return 0.0
    sharp = max(0.0, p.cl_sharpness)
    rnd = max(0.0, min(1.0, p.cl_roundness))
    slope = max(0.02, min(0.9, 0.35 / max(math.tan(max(p.cl_angle, 0.05)), 0.05)))
    if kind == 'SHARP':
        base = (1.0 - t) ** (1.0 + sharp * 3.0)
        return base * (1 - rnd) + (1.0 - t * t) * rnd
    if kind == 'ROUND':
        return math.sqrt(max(0.0, 1.0 - t * t))
    if kind == 'FLAT':
        plateau = max(0.05, 1.0 - slope)
        return 1.0 if t <= plateau else smoothstep((1.0 - t) / max(1.0 - plateau, 1e-6)) * (1 - rnd) + \
            (1.0 - (t - plateau) / max(1.0 - plateau, 1e-6)) * rnd
    if kind == 'BOX':
        edge = 1.0 - slope * 0.5
        if t <= edge:
            return 1.0
        f = (1.0 - t) / max(1.0 - edge, 1e-6)
        return f * (1 - rnd) + smoothstep(f) * rnd
    if kind == 'GROOVE':
        return -math.sqrt(max(0.0, 1.0 - t * t)) * (1 - rnd) - (1.0 - t) * rnd
    if kind == 'SPLIT':
        return -((1.0 - t) ** (1.0 + sharp * 2.0)) * 2.0      # narrow deep V: panels look separated
    return 0.0


def ridge_value(u, v, branches, p, radius):
    """Signed ridge height at normalized (u, v)."""
    if p.cl_preset == 'NONE' or not branches:
        return 0.0
    kind = p.ridge_profile
    k = p.transition_smoothness * 0.5
    best = None
    for pts, wfac in branches:
        hw = max(1e-4, p.cl_width * wfac)
        d = min(_seg_dist(u, v, pts[i], pts[i + 1]) for i in range(len(pts) - 1))
        val = ridge_profile(kind, d / hw, p)
        if best is None:
            best = val
        elif val >= 0 or best >= 0:
            best = smooth_max(best, val, k) if val >= 0 and best >= 0 else (val if abs(val) > abs(best) else best)
        else:
            best = min(best, val)
    h = (best or 0.0) * p.cl_height * p.cl_strength
    return -h if p.cl_invert else h


# =============================================================================
# Parameters per column / vertex
# =============================================================================


def _blend(p, theta, name):
    w = dir_weights(theta)
    return sum(w[d] * getattr(p, f'{d.lower()}_{name}') for d in DIRS)


def chamfer_wd(width, angle, depth, mode):
    """(width, depth) of a chamfer from any two of width / angle / depth."""
    if mode == 'WIDTH_DEPTH':
        return width, depth
    if mode == 'DEPTH_ANGLE':
        return (depth / math.tan(angle) if math.tan(angle) > 1e-6 else 0.0), depth
    return width, width * math.tan(max(0.0, min(angle, math.radians(89.0))))


def column_params(p, theta, armor):
    """Edge parameters of one boundary column (top + base edge).  Segment counts x the global Resolution."""
    from . import tool_state as _ts
    if armor:
        thick = _blend(p, theta, 'thickness')
        cw = _blend(p, theta, 'chamfer_width')
        ca = _blend(p, theta, 'chamfer_angle')
        bw = _blend(p, theta, 'bevel_width')
        w = dir_weights(theta)
        seg = _ts.res_n(max(int(round(getattr(p, f'{d.lower()}_bevel_segments'))) for d in DIRS if w[d] > 0.02))
        cw, cd = chamfer_wd(cw, ca, 0.0, 'WIDTH_ANGLE')
        return {'height': thick, 'cw': cw, 'cd': cd, 'dir': 'IN', 'bw': bw, 'seg': seg,
                'prof': p.bevel_profile, 'ow': p.outer_chamfer_width,
                'od': p.outer_chamfer_width * math.tan(p.outer_chamfer_angle), 'obw': p.outer_bevel_width,
                'oseg': _ts.res_n(p.bevel_segments)}
    cw, cd = chamfer_wd(p.chamfer_width, p.chamfer_angle, p.chamfer_depth, p.chamfer_mode)
    return {'height': p.extract_height, 'cw': cw, 'cd': cd, 'dir': p.chamfer_direction,
            'bw': p.bevel_width, 'seg': _ts.res_n(p.bevel_segments), 'prof': p.bevel_profile,
            'ow': p.outer_chamfer_width, 'od': p.outer_chamfer_width * math.tan(p.outer_chamfer_angle),
            'obw': p.outer_bevel_width, 'oseg': _ts.res_n(p.bevel_segments)}


def directional_height(p, theta, r):
    """Armor top height: centre height blended to the per-direction edge
    thickness with per-direction slope (reach) and roundness."""
    hc = p.extract_height
    w = dir_weights(theta)
    tension = max(0.05, 1.0 + p.surface_tension)
    h = hc
    for d in DIRS:
        if w[d] <= 0:
            continue
        reach = max(0.02, min(1.0, getattr(p, f'{d.lower()}_slope')))
        rnd = max(0.0, min(1.0, getattr(p, f'{d.lower()}_roundness')))
        t = (r - (1.0 - reach)) / reach
        t = min(1.0, max(0.0, t)) ** tension
        g = t * (1 - rnd) + smoothstep(t) * rnd
        h += w[d] * (getattr(p, f'{d.lower()}_thickness') - hc) * g
    return h


# =============================================================================
# Builder
# =============================================================================


def build(region_mesh, context_mesh, p, armor=False, notes=None):
    """Return a BMesh of the panel (in the region's coordinate space)."""
    notes = notes if notes is not None else []
    bm = bmesh.new()
    bm.from_mesh(region_mesh)
    try:
        return _build(bm, context_mesh, p, armor, notes)
    except Exception:
        bm.free()
        raise


def _project_factory(context_mesh, bm_region):
    src = context_mesh if context_mesh is not None and len(context_mesh.polygons) else None
    if src is not None:
        cbm = bmesh.new()
        cbm.from_mesh(src)
        tree = BVHTree.FromBMesh(cbm)
        cbm.free()
    else:
        tree = BVHTree.FromBMesh(bm_region)

    def project(co, nrm=None):
        """Onto the surface along the normal; off the surface (outward rings
        past the mesh edge) the point stays on the tangent-plane extension."""
        if nrm is None or nrm.length < 1e-12:
            hit = tree.find_nearest(co)
            return hit[0] if hit and hit[0] is not None else co
        best = None
        for d in (nrm, -nrm):
            loc, _n, _i, dist = tree.ray_cast(co - d * 1e-6, d)
            if loc is not None and (best is None or dist < best[0]):
                best = (dist, loc)
        # 0.19.2: on a sharp outside edge (cylinder rim) the normal ray can miss the near face and hit the
        # far side of the mesh -> spike.  Much farther than the nearest surface point = use that point.
        near = tree.find_nearest(co)
        if near and near[0] is not None and (best is None or best[0] > near[3] * 3.0 + 1e-6):
            return near[0] if best is not None or near[3] < 1e-4 else co
        return best[1] if best is not None else co
    return project


ROOM_SHARE = 0.3        # an edge band may use this part of the width across a narrow neck


def _build(bm, context_mesh, p, armor, notes):
    bm.verts.ensure_lookup_table()
    if not bm.faces:
        raise PanelError('No faces selected.')
    levels = max(0, int(p.resolution))
    if levels:
        for _ in range(levels):
            bmesh.ops.subdivide_edges(bm, edges=bm.edges[:], cuts=1, use_grid_fill=True)
    if getattr(p, 'emold_dome', 0.0) > 0.0:
        _fill_inside(bm)        # 0.24.299 Top Dome: points inside the outline to raise (a flat face gave none)
    bm.normal_update()
    # 0.19.2 surface lines: cut the region along each crease line first, so the
    # crease is a real edge (sharp, even on a light plate)
    lines, fcen, ft, fb, fall, half, crease_h = [], None, None, None, 1.0, 0.0, 0.0
    style = getattr(p, 'facet_style', 'NONE')
    if style != 'NONE' and abs(getattr(p, 'facet_depth', 0.0)) > 1e-9:
        fcen, fn, ft, fb, frad = region_frame(list(bm.verts), list(bm.faces))
        pts = [((v.co - fcen).dot(ft), (v.co - fcen).dot(fb)) for v in bm.verts]
        lines = facet_lines(style, getattr(p, 'facet_count', 3), getattr(p, 'facet_seed', 1),
                            getattr(p, 'facet_rotation', 0.0), pts, frad, getattr(p, 'facet_offset', 0.0) * frad)
        fall = frad * 1.1
        half = max(0.0, getattr(p, 'facet_width', 0.0)) * frad * 0.5
        crease_h = p.facet_depth * frad * 0.1       # 0.19.4: part of the plate SIZE, not of its height
        for ln in lines:
            px, py, ang, _sg = ln
            d3 = ft * math.cos(ang) + fb * math.sin(ang)
            nrm = fn.cross(d3)
            for side in ((-half, half) if half > 0 else (0.0,)):
                co = fcen + ft * px + fb * py + nrm.normalized() * side * (1 if nrm.length > 0 else 0)
                geom = bm.verts[:] + bm.edges[:] + bm.faces[:]
                bmesh.ops.bisect_plane(bm, geom=geom, dist=frad * 1e-6, plane_co=co, plane_no=nrm)
        bm.verts.ensure_lookup_table()
        bm.normal_update()

    def fxy(co):
        d = co - fcen
        return d.dot(ft), d.dot(fb)
    fix_bowties(bm)
    project = _project_factory(context_mesh, bm)
    faces = list(bm.faces)
    loops = boundary_loops(bm, faces)
    verts = list(bm.verts)
    cen, n_avg, t_ax, b_ax, radius = region_frame(verts, faces)
    # user rotation / mirror of the local frame (around the average normal)
    rot = getattr(p, 'dir_rotation', 0.0)
    q = Matrix.Rotation(rot, 3, n_avg)
    t_ax, b_ax = q @ t_ax, q @ b_ax
    sx = max(1e-3, getattr(p, 'dir_scale_x', 1.0))
    sy = max(1e-3, getattr(p, 'dir_scale_y', 1.0))
    ox, oy = getattr(p, 'dir_offset_x', 0.0), getattr(p, 'dir_offset_y', 0.0)
    mirror = -1.0 if getattr(p, 'dir_mirror', False) else 1.0

    def local_uv(co):
        d = co - cen
        u = (d.dot(t_ax) / radius - ox) / sx * mirror
        v = (d.dot(b_ax) / radius - oy) / sy
        return u, v

    bset = {v for lp in loops for v in lp}
    dist = distance_from_boundary(verts, bset)
    dmax = max((d for d in dist.values() if d < math.inf), default=0.0) or 1.0
    vnorm = {v: (v.normal.copy() if v.normal.length > 1e-9 else n_avg.copy()) for v in verts}
    # 0.19.3: a light (low poly) region has noisy vertex normals -> smooth them a little, and a tall
    # part rises more and more along the average normal (raised along each normal it fanned out and
    # buckled on a curved surface such as a shoulder)
    nbr_all = {v: [e.other_vert(v) for e in v.link_edges] for v in verts}
    for _ in range(3):
        nxt = {}
        for v in verts:
            acc = vnorm[v] * 2.0
            for w in nbr_all[v]:
                acc += vnorm[w]
            nxt[v] = acc.normalized() if acc.length > 1e-9 else vnorm[v]
        vnorm = nxt
    tall = min(0.9, 1.2 * max(p.extract_height, 0.0) / max(radius, 1e-9))
    updir = {}
    for v in verts:
        d = vnorm[v] * (1.0 - tall) + n_avg * tall
        updir[v] = d.normalized() if d.length > 1e-9 else n_avg.copy()
    offset = p.surface_offset
    shell = p.thickness > 1e-9
    branches = guide_branches(p) if armor else []
    trans_w = max(1e-3, getattr(p, 'transition_width', 0.25))

    # ---- columns ---------------------------------------------------------------
    columns = []                 # per loop: list of dicts
    min_inr = min((math.dist(v.co, cen) for v in bset), default=radius)
    width_cap = max(1e-5, 0.45 * min(min_inr, dmax * 2.0))
    clamp_hit = False
    for lp in loops:
        cols = []
        n = len(lp)
        for i, v in enumerate(lp):
            p0, p1, p2 = lp[i - 1].co, v.co, lp[(i + 1) % n].co
            nv = vnorm[v]
            e1, e2 = (p1 - p0), (p2 - p1)
            l1 = nv.cross(e1)
            l2 = nv.cross(e2)
            l1 = l1.normalized() if l1.length > 1e-12 else Vector()
            l2 = l2.normalized() if l2.length > 1e-12 else Vector()
            inward = l1 + l2
            if inward.length < 1e-9:
                inward = l1 if l1.length else nv.orthogonal()
            inward.normalize()
            miter = 1.0 / max(0.35, inward.dot(l1) if l1.length else 1.0)
            if l1.length and e2.length > 1e-12 and e2.dot(l1) < 0:
                miter = min(miter, 1.0)      # 0.19.2 reflex (inward) corner: no long miter spike
            # turning angle (for side edge bevel)
            turn = 0.0
            if e1.length > 1e-12 and e2.length > 1e-12:
                turn = e1.normalized().angle(e2.normalized(), 0.0)
            u, w_ = local_uv(p1)
            theta = math.atan2(w_, u)
            cp = column_params(p, theta, armor)
            cols.append({'v': v, 'inward': inward, 'miter': miter, 'normal': nv, 'theta': theta, 'turn': turn,
                         'cp': cp})
        columns.append(cols)

    # ---- profiles ----------------------------------------------------------------
    def top_profile(cp):
        h = max(1e-5, cp['height'])
        room = h * (0.9 if shell else 0.9)
        cw, cd, bw = cp['cw'], cp['cd'], cp['bw']
        # bottom (outer) edge takes part of the wall height
        od, obw = cp['od'], cp['obw']
        need = cd + bw + od + obw
        if need > room and need > 0:
            f = room / need
            cd, bw, od, obw = cd * f, bw * f, od * f, obw * f
            nonlocal clamp_hit
            clamp_hit = True
        cw = min(cw, width_cap)
        top = edge_profile(cw, cd, cp['dir'], bw, cp['seg'] if bw > 0 else 0, cp['prof'],
                           wall_room=max(h - od - obw, 1e-5))
        return top, (od, obw)

    def bottom_profile(cp, wall_s, od, obw):
        ow = min(cp['ow'], width_cap)
        if shell:
            return [(wall_s, 0.0)]
        pts = edge_profile(ow, od, 'IN', obw, cp['oseg'] if obw > 0 else 0, cp['prof'], wall_room=1e9)
        return [(s + wall_s, -z) for s, z in pts]       # mirrored: z goes up the wall

    # 0.19.2 local room: where the outline gets narrow (a neck) or turns sharply inward, a wide
    # chamfer / bevel from both sides crossed over and crumpled the part.  Each column's edge band is
    # scaled to fit 40 % of the distance to the boundary across the neck.
    from mathutils.kdtree import KDTree
    allb = [(li, ci, c['v'].co.copy()) for li, cols in enumerate(columns) for ci, c in enumerate(cols)]
    arc = {}
    for li, cols in enumerate(columns):
        acc = 0.0
        for ci, c in enumerate(cols):
            if ci:
                acc += (c['v'].co - cols[ci - 1]['v'].co).length
            arc[(li, ci)] = acc
        arc[(li, 'len')] = acc + ((cols[0]['v'].co - cols[-1]['v'].co).length if cols else 0.0)
    kd = KDTree(len(allb))
    for k, (_li, _ci, co) in enumerate(allb):
        kd.insert(co, k)
    kd.balance()

    def room(li, ci, reach):
        co = columns[li][ci]['v'].co
        best = math.inf
        total = arc[(li, 'len')]
        for _p, k, dist in kd.find_range(co, reach):
            lj, cj, _co = allb[k]
            if lj == li:
                da = abs(arc[(li, ci)] - arc[(lj, cj)])
                da = min(da, total - da)
                if da < dist * 2.0 + 1e-9:          # a neighbour along the same edge, not across a neck
                    continue
            best = min(best, dist)
        return best

    def fit(prof, f):
        return [(sv * f, zv) for sv, zv in prof]

    squeezed = 0
    prof_top, prof_bot = [], []
    n_top = n_bot = 1
    for li, cols in enumerate(columns):
        pt, pb, need, fac = [], [], [], []
        for ci, c in enumerate(cols):
            top, (od, obw) = top_profile(c['cp'])
            wall_s = top[0][0]
            bot = bottom_profile(c['cp'], wall_s, od, obw)
            top, bot = edge_molding_profiles(p, c['cp']['height'], top, bot, shell)      # 0.24.298
            pt.append(top)
            pb.append(bot)
            nd = max(abs(sv) for sv, _z in top + bot) * c['miter']
            need.append(nd)
            f = 1.0
            if nd > 1e-9:
                rm = room(li, ci, nd / ROOM_SHARE)
                if rm < nd / ROOM_SHARE:
                    f = max(0.05, ROOM_SHARE * rm / nd)
            fac.append(f)
        n = len(cols)
        # spread each narrowing to the neighbours: no twisted band where one column shrinks alone
        smooth = [min(fac[(ci + k) % n] for k in range(-3, 4)) for ci in range(n)]
        for ci in range(n):
            if smooth[ci] < 1.0:
                pt[ci], pb[ci] = fit(pt[ci], smooth[ci]), fit(pb[ci], smooth[ci])
                squeezed += 1
            n_top = max(n_top, len(pt[ci]))
            n_bot = max(n_bot, len(pb[ci]))
        prof_top.append(pt)
        prof_bot.append(pb)
    if clamp_hit:
        notes.append('edge sizes reduced to fit the part height')
    if squeezed:
        notes.append(f'edge band narrowed at {squeezed} point(s) where the outline is narrow')
    # equal row counts everywhere: give sharp columns a tiny chamfer, then resample
    eps = max(radius * 2e-3, 1e-5)
    for li, cols in enumerate(columns):
        for ci in range(len(cols)):
            for prof, nrow, sign in ((prof_top, n_top, 1), (prof_bot, n_bot, -1)):
                pr = prof[li][ci]
                if len(pr) == 1 and nrow > 1:
                    s0, z0 = pr[0]
                    pr = [(s0, z0 - eps * sign), (s0 + eps, z0)]
                prof[li][ci] = _resample(pr, nrow) if nrow > 1 else pr

    # ---- cap shrink (harmonic displacement of the region) --------------------------
    cap_s = {}
    for li, cols in enumerate(columns):
        for ci, c in enumerate(cols):
            cap_s[c['v']] = (prof_top[li][ci][-1][0], prof_bot[li][ci][-1][0])

    def shrink(which):
        disp = {}
        for li, cols in enumerate(columns):
            for c in cols:
                s = cap_s[c['v']][which]
                disp[c['v']] = c['inward'] * c['miter'] * s
        if all(d.length < 1e-12 for d in disp.values()):
            return {v: v.co.copy() for v in verts}
        field = {v: disp.get(v, Vector()) for v in verts}
        interior = [v for v in verts if v not in bset]
        nbrs = {v: [e.other_vert(v) for e in v.link_edges] for v in interior}
        for _ in range(min(200, 20 + len(interior) // 4)):
            new = {}
            delta = 0.0
            for v in interior:
                acc = Vector()
                for w in nbrs[v]:
                    acc += field[w]
                acc /= max(len(nbrs[v]), 1)
                delta = max(delta, (acc - field[v]).length)
                new[v] = acc
            field.update(new)
            if delta < radius * 1e-5:
                break
        return {v: project(v.co + field[v], vnorm[v]) for v in verts}

    top_pos = shrink(0)
    bot_pos = top_pos if all(abs(a - b) < 1e-12 for a, b in cap_s.values()) else shrink(1)

    # ---- heights ------------------------------------------------------------------------
    # 0.19.4 edge rims: the border band of the chosen sides (N / E / S / W of the part frame) rises
    rims = [k for k in DIRS if getattr(p, f'rim_{k.lower()}', False)]
    rim_w = max(1e-6, getattr(p, 'rim_width', 0.15) * radius)
    rim_h = getattr(p, 'rim_height', 0.5) * radius * 0.1
    rim_slope = max(0.02, getattr(p, 'rim_slope', 0.3))
    rim_kind = getattr(p, 'rim_profile', 'CHAMFER')
    rim_segs = []
    if getattr(p, 'rim_random', False):
        rng = random.Random(int(getattr(p, 'rim_seed', 1)))
        rim_segs = [(rng.uniform(0.0, 2.0 * math.pi), rng.uniform(0.15, 0.55))
                    for _i in range(max(1, int(getattr(p, 'rim_count', 3))))]

    def rim_profile(d):
        """1 on the border band, then down to 0 over the slope: chamfer (straight) or bevel (round)."""
        if d <= rim_w:
            return 1.0
        t = min(1.0, (d - rim_w) / (rim_slope * rim_w))
        return 0.5 * (1.0 + math.cos(math.pi * t)) if rim_kind == 'BEVEL' else 1.0 - t
    dome_h = float(getattr(p, 'emold_dome', 0.0))       # (0.24.299 on its own too)

    def top_height(v, co_for_uv):
        r = 1.0 - min(dist[v], dmax) / dmax
        u, w_ = local_uv(co_for_uv)
        theta = math.atan2(w_, u)
        if armor:
            h = directional_height(p, theta, r)
            if branches:
                fade = 1.0 - smoothstep((r - (1.0 - trans_w)) / trans_w)
                h += ridge_value(u, w_, branches, p, radius) * fade
        else:
            h = p.extract_height
        if rims or rim_segs:
            d = dist[v]
            if d < rim_w * (1.0 + rim_slope):
                share = 0.0
                if rims:
                    wt = dir_weights(theta)
                    w2 = {k: x_ ** 2 for k, x_ in wt.items()}       # sharper split between the 4 sides
                    share = sum(w2[k] for k in rims) / (sum(w2.values()) or 1.0)
                for c0, hw in rim_segs:                            # random pieces along the border
                    da = abs((theta - c0 + math.pi) % (2.0 * math.pi) - math.pi)
                    share = max(share, max(0.0, min(1.0, 1.0 - (da - hw) / 0.12)))
                h += rim_h * share * rim_profile(d)
        if lines:
            x, y = fxy(co_for_uv)
            h = max(p.extract_height * 0.15, h + crease_h * facet_value(lines, x, y, fall, half))
        if dome_h > 0.0:                            # 0.24.299 Top Dome (with the Top Edge Molding)
            t_ = min(1.0, dist[v] / max(dmax * 0.35, 1e-9))
            h += dome_h * math.sqrt(max(0.0, 1.0 - (1.0 - t_) ** 2))     # (the edge rolls over round)
        return h

    # ---- assemble -----------------------------------------------------------------------------
    out = bmesh.new()
    smooth_faces = getattr(p, 'smooth_shading', True)
    vt, vb = {}, {}
    for v in verts:
        h = top_height(v, v.co)
        vt[v] = out.verts.new(top_pos[v] + vnorm[v] * offset + updir[v] * h)
        if not shell:
            vb[v] = out.verts.new(bot_pos[v] + vnorm[v] * offset)
    for f in faces:
        nf = out.faces.new([vt[v] for v in f.verts])
        nf.smooth = smooth_faces
        if not shell:
            nf2 = out.faces.new([vb[v] for v in reversed(f.verts)])
            nf2.smooth = smooth_faces
    weight_edges = []
    for li, cols in enumerate(columns):
        n = len(cols)
        col_verts = []
        for ci, c in enumerate(cols):
            v = c['v']
            base = v.co
            ht = top_height(v, base)      # edge height (r = 1)
            nv = c['normal']
            chain = [vt[v]]
            # top band from inner to outer (the cap point itself is vt[v])
            top = prof_top[li][ci]
            def at(s):
                return project(base + c['inward'] * c['miter'] * s, nv)
            up = updir[v]
            vt[v].co = at(top[-1][0]) + nv * offset + up * (ht + top[-1][1])
            for s, z in reversed(top[:-1]):
                chain.append(out.verts.new(at(s) + nv * offset + up * (ht + z)))
            bot = prof_bot[li][ci]
            for s, z in bot[:-1] if not shell else bot:
                chain.append(out.verts.new(at(s) + nv * (offset + z)))
            if not shell:
                s, z = bot[-1]
                vb[v].co = at(s) + nv * (offset + z)
                chain.append(vb[v])
            col_verts.append(chain)
        rows = len(col_verts[0])
        for ci in range(n):
            a, b = col_verts[ci], col_verts[(ci + 1) % n]
            for k in range(rows - 1):
                quad = (b[k], a[k], a[k + 1], b[k + 1])
                if len({id(x) for x in quad}) < 4:
                    continue
                try:
                    f = out.faces.new(quad)
                    f.smooth = smooth_faces
                except ValueError:
                    pass
        # side edges: vertical wall edges at sharp boundary corners (bevel by angle)
        thr = getattr(p, 'bevel_angle', math.radians(30.0))
        nt = len(prof_top[li][0])
        for ci, c in enumerate(cols):
            if c['turn'] >= thr:
                chain = col_verts[ci]
                k0 = nt - 1          # wall top (outermost top point)
                k1 = k0 + 1          # wall bottom (first bottom point)
                if k1 < len(chain):
                    weight_edges.append((chain[k0], chain[k1]))
    crease_pairs = []
    if lines:
        tol = radius * 1e-4
        on = {v: {i for i, ln in enumerate(lines) if abs(abs(line_dist(ln, *fxy(v.co))) - half) < tol} for v in verts}
        for e in {e for f in faces for e in f.edges}:
            a, b = e.verts
            if on[a] & on[b]:
                crease_pairs.append((vt[a], vt[b]))
    out.verts.index_update()
    bmesh.ops.remove_doubles(out, verts=out.verts[:], dist=radius * 1e-7)
    layer = out.edges.layers.float.get('bevel_weight_edge') or out.edges.layers.float.new('bevel_weight_edge')
    for a, b in weight_edges:
        if a.is_valid and b.is_valid:
            e = out.edges.get((a, b))
            if e is not None:
                e[layer] = 1.0
    if crease_pairs:
        cl = out.edges.layers.float.get('mch_crease') or out.edges.layers.float.new('mch_crease')
        for a, b in crease_pairs:
            if a.is_valid and b.is_valid:
                e = out.edges.get((a, b))
                if e is not None:
                    e[cl] = 1.0
    out.normal_update()
    bad = [e for e in out.edges if not e.is_manifold]
    if not shell and bad:
        notes.append(f'{len(bad)} non-manifold edges (selection boundary too complex)')
    if not shell and out.calc_volume(signed=True) < 0:
        bmesh.ops.reverse_faces(out, faces=out.faces[:])
    bm.free()
    return out
