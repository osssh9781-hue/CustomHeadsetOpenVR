"""0.16 Armor Plate: draw a lasso on a mesh, get a separate armour plate.

No retopology needed.  The plate does NOT reuse the faces of the mesh under the
lasso: a NEW clean patch is built inside the drawn outline and laid onto the
surface (like a shrinkwrap):

    1. the outline (screen pixels) is resampled densely, so the plate edge
       follows the drawn line exactly (corners kept);
    2. an even grid of points fills the inside, a constrained Delaunay
       triangulation joins them, triangles are paired into quads;
    3. every point is projected through the view onto the mesh it was drawn
       on (the surface normal is kept); points that miss land on the plane
       through the hits.

The patch then goes through the Face Extract / Armor Sculpt engine
(``panel_gen``): height, thickness, chamfer, bevel, outer edge and the live
part settings work exactly as for an extracted part, and the mesh you drew on
is never changed.

While drawing, the mouse wheel steps through the plate profiles.  Profile
sizes scale with the plate (Auto Size), so a small plate gets a small bevel.

Pure helpers (``resample_loop``, ``screen_patch``, ``preset_values``) are
tested headless; the stroke itself shares the Cut / Base Mesh lasso.
"""
from __future__ import annotations

from .i18n import tr as _tr
import json
import math
import time
import zlib

import bmesh
import bpy
import numpy as np
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty
from mathutils import Matrix, Quaternion, Vector
from mathutils.bvhtree import BVHTree
from mathutils.geometry import delaunay_2d_cdt

from . import target_rules
from . import core_geometry as cg
from . import tool_state as ts
from .light_copies import full as _lc_full  # 0.24.136 a part's own geometry, never its light copy

# Profile presets: values are FRACTIONS of the plate size (bounding diagonal)
# when Auto Size is on; angles in degrees.  Everything not listed is reset.
PRESETS = (
    ('FLAT', 'Flat Plate', 'Plain plate, sharp edges', dict(extract_height=0.03)),
    ('CHAMFER', 'Chamfer 45', 'Top edge cut at 45 deg', dict(extract_height=0.04, chamfer_width=0.02,
                                                              chamfer_angle=45)),
    ('STEEP', 'Steep Chamfer', 'Narrow, steep top chamfer', dict(extract_height=0.05, chamfer_width=0.012,
                                                                  chamfer_angle=70)),
    ('SOFT', 'Soft Bevel', 'Small rounded top edge', dict(extract_height=0.04, bevel_width=0.012,
                                                           bevel_segments=3)),
    ('ROUND', 'Round Edge', 'Fully rounded top edge', dict(extract_height=0.05, bevel_width=0.025,
                                                            bevel_segments=6)),
    ('CHAMFER_BEVEL', 'Chamfer + Bevel', 'Chamfer with softened lines', dict(extract_height=0.05,
                                                                             chamfer_width=0.02,
                                                                             chamfer_angle=45, bevel_width=0.006,
                                                                             bevel_segments=2)),
    ('FLARED', 'Flared', 'Chamfer flaring outward beyond the outline', dict(extract_height=0.04,
                                                                           chamfer_width=0.02,
                                                                           chamfer_angle=45,
                                                                           chamfer_direction='OUT')),
    ('SHELL', 'Thin Shell', 'Thin plate shell (open underneath)', dict(extract_height=0.025, thickness=0.008)),
    ('HEAVY', 'Heavy Armor', 'Thick plate, wide chamfer', dict(extract_height=0.08, chamfer_width=0.03,
                                                                chamfer_angle=50, bevel_width=0.004,
                                                                bevel_segments=2)),
    ('STEPPED', 'Stepped Edge', 'Top chamfer + base chamfer', dict(extract_height=0.05, chamfer_width=0.015,
                                                                    chamfer_angle=45, outer_chamfer_width=0.015,
                                                                    outer_chamfer_angle=45)),
    ('CLOTH', 'Soft Cloth', 'Soft padded edge (tactical cloth)', dict(extract_height=0.035, bevel_width=0.03,
                                                                       bevel_segments=8, bevel_profile=0.3)),
    ('RIDGE', 'Center Ridge', 'Armor Sculpt plate with a ridge down the middle',
     dict(mode='ARMOR', extract_height=0.05, n_thickness=0.03, e_thickness=0.03, s_thickness=0.03,
          w_thickness=0.03, cl_preset='STRAIGHT', cl_height=0.02)),
    # 0.24.24 mechanical faceted ridge (its own live plate: mech_ridge.py)
    ('MRIDGE', 'Mech Ridge', 'Every edge slopes up to sharp ridge lines (a box gives a hip roof); Chamfer / Bevel '
     'for the ridge lines and the outer edge', dict()),
)
PRESET_IDS = tuple(p[0] for p in PRESETS)
LENGTH_KEYS = {'extract_height', 'thickness', 'surface_offset', 'bevel_width', 'chamfer_width', 'chamfer_depth',
               'outer_bevel_width', 'outer_chamfer_width', 'cl_height', 'n_thickness', 'e_thickness',
               's_thickness', 'w_thickness'}
ANGLE_KEYS = {'chamfer_angle', 'outer_chamfer_angle', 'bevel_angle'}
RESET = dict(mode='BASIC', thickness=0.0, surface_offset=0.0, bevel_width=0.0, bevel_segments=3, bevel_profile=0.5,
             chamfer_width=0.0, chamfer_angle=45, chamfer_direction='IN', chamfer_mode='WIDTH_ANGLE',
             outer_bevel_width=0.0, outer_chamfer_width=0.0, outer_chamfer_angle=45, cl_preset='NONE')
MAX_POINTS = 9000


def preset_values(preset, size, auto=True):
    """Settings dict for a profile: lengths scaled by the plate size (Auto
    Size), angles converted to radians, the rest reset to plain values."""
    spec = next((p[3] for p in PRESETS if p[0] == preset), PRESETS[0][3])
    out = dict(RESET)
    out.update(spec)
    for k, v in list(out.items()):
        if k in ANGLE_KEYS:
            out[k] = math.radians(v)
        elif k in LENGTH_KEYS and auto:
            out[k] = v * size
        elif k in LENGTH_KEYS and not auto:
            out.pop(k)                         # manual size: keep the user's own value
    return out


# -----------------------------------------------------------------------------
# 2D patch (screen pixels)
# -----------------------------------------------------------------------------


def resample_loop(loop, step):
    """Closed loop with extra points every ``step`` px; the drawn points
    (corners) are all kept."""
    out = []
    n = len(loop)
    for i in range(n):
        a, b = loop[i], loop[(i + 1) % n]
        out.append((float(a[0]), float(a[1])))
        d = math.dist(a, b)
        k = int(d // step)
        for j in range(1, k + 1):
            t = j / (k + 1)
            out.append((a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t))
    return out


def _seg_dist(p, a, b):
    ax, ay = b[0] - a[0], b[1] - a[1]
    L = ax * ax + ay * ay
    if L < 1e-12:
        return math.dist(p, a)
    t = max(0.0, min(1.0, ((p[0] - a[0]) * ax + (p[1] - a[1]) * ay) / L))
    return math.dist(p, (a[0] + ax * t, a[1] + ay * t))


def screen_patch(groups, spacing=14.0, min_spacing=2.0):
    """Clean triangulation of the outline groups [(outer, [holes])] in pixels.

    Returns (points, triangles, boundary_count): the first ``boundary_count``
    points lie on the outline (in loop order, outer then holes)."""
    spacing = max(min_spacing, float(spacing))
    loops = [lp for outer, holes in groups for lp in [outer] + list(holes)]
    area = sum(abs(cg.signed_area(o)) - sum(abs(cg.signed_area(h)) for h in hs) for o, hs in groups)
    while area / (spacing * spacing) > MAX_POINTS:      # keep big plates light
        spacing *= 1.25
    rings = [resample_loop(lp, spacing * 0.5) for lp in loops]
    pts, edges = [], []
    for r in rings:
        start = len(pts)
        pts += r
        edges += [(start + i, start + (i + 1) % len(r)) for i in range(len(r))]
    nb = len(pts)
    segs = [(r[i], r[(i + 1) % len(r)]) for r in rings for i in range(len(r))]
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    row = 0
    y = min(ys) + spacing * 0.5
    while y < max(ys):
        x = min(xs) + spacing * (0.5 + 0.5 * (row % 2))       # staggered rows: even triangles
        while x < max(xs):
            q = (x, y)
            if cg.point_in_loops(q, [g for o, hs in groups for g in [o] + list(hs)]) and \
                    min(_seg_dist(q, a, b) for a, b in segs) > spacing * 0.45:
                pts.append(q)
            x += spacing
        y += spacing * 0.866
        row += 1
    vs = [Vector(p) for p in pts]
    out_v, _e, out_f, out_vo, _eo, _fo = delaunay_2d_cdt(vs, edges, [], 0, 1e-6, True)
    remap = {}
    for new_i, orig in enumerate(out_vo):
        if orig:
            remap[new_i] = orig[0]
    tris = []
    all_loops = [g for o, hs in groups for g in [o] + list(hs)]
    for f in out_f:
        if len(f) != 3 or any(i not in remap for i in f):
            continue
        a, b, c = (remap[i] for i in f)
        cen = ((pts[a][0] + pts[b][0] + pts[c][0]) / 3, (pts[a][1] + pts[b][1] + pts[c][1]) / 3)
        if not cg.point_in_loops(cen, all_loops):
            continue
        ar = (pts[b][0] - pts[a][0]) * (pts[c][1] - pts[a][1]) - (pts[b][1] - pts[a][1]) * (pts[c][0] - pts[a][0])
        if abs(ar) < 1e-9:
            continue
        tris.append((a, b, c) if ar > 0 else (a, c, b))
    return pts, tris, nb


# -----------------------------------------------------------------------------
# Surface projection
# -----------------------------------------------------------------------------


def is_plate_or_part(ob):
    ex = getattr(ob, 'mch_extract', None)
    if ex is not None and ex.is_part:
        return True
    try:
        # 0.20: live cloth wrinkle layers are skipped too (0.24.20 and live Creature Plates)
        return bool(ob.get('mch_wrinkle')) or bool(ob.get('mch_cplate_src')) or bool(ob.get('mch_flower_src')) \
            or bool(ob.get('mch_bridge_src'))
    except (AttributeError, TypeError, ReferenceError):
        return False


def pick_surface(context, projector, groups):
    """The mesh under the outline (armour parts / plates are skipped)."""
    outer = groups[0][0]
    probes = [(sum(q[0] for q in outer) / len(outer), sum(q[1] for q in outer) / len(outer))] + list(outer[::4])
    dg = context.evaluated_depsgraph_get()
    counts = {}
    for xy in probes:
        o, d = projector.ray(xy)
        for _ in range(16):
            hit, loc, _n, _i, ob, _m = target_rules.scene_ray(context, dg, o, d)
            if not hit or ob is None:
                break
            real = bpy.data.objects.get(ob.name)
            if real is not None and real.type == 'MESH' and not is_plate_or_part(real):
                counts[real.name] = counts.get(real.name, 0) + 1
                break
            o = loc + d * 1e-4
    if not counts:
        return None
    return bpy.data.objects[max(counts, key=counts.get)]


class _FaceList:
    """The target's faces as index lists, read from flat numpy arrays on demand (a million-face body is not kept
    as a million Python tuples)."""
    __slots__ = ('flat', 'starts', 'sizes')

    def __init__(self, flat, starts, sizes):
        self.flat, self.starts, self.sizes = flat, starts, sizes

    def __len__(self):
        return len(self.sizes)

    def __getitem__(self, i):
        if isinstance(i, slice):
            return [self[j] for j in range(*i.indices(len(self)))]
        if i < 0:
            i += len(self)
        if i < 0 or i >= len(self):
            raise IndexError(i)
        a = int(self.starts[i])
        return self.flat[a:a + int(self.sizes[i])].tolist()

    def __iter__(self):
        for i in range(len(self)):
            yield self[i]


_BVH_CACHE = {}            # one target: dict(sig, time, bvh, wverts, faces)
BVH_TTL = 30.0             # s: a live plate's sliders rebuild from the same surface many times within this


def _mat_np(m):
    return (np.array([[m[i][j] for j in range(3)] for i in range(3)], dtype=np.float64),
            np.array([m[i][3] for i in range(3)], dtype=np.float64))


def _target_bvh(context, ob):
    """BVH of ``ob`` (with its modifiers) in WORLD space, its world points (numpy N x 3) and its faces (index lists).
    0.24.131 (user: "플레이트 올리면 개 오래 걸려") numpy instead of a Python loop over every point and face, and a
    short cache per target keyed by a checksum of the points + the matrix: a million-point DynaMesh body took seconds
    on every plate and on every slider step of a live plate."""
    dg = context.evaluated_depsgraph_get()
    ev = _lc_full(ob, dg)
    me = ev.to_mesh()
    try:
        mw = ev.matrix_world
        nv, nf, nl = len(me.vertices), len(me.polygons), len(me.loops)
        co = np.empty(nv * 3, dtype=np.float32)
        me.vertices.foreach_get('co', co)
        sig = (nv, nf, zlib.crc32(co.tobytes()), tuple(round(x, 6) for row in mw for x in row))
        hit = _BVH_CACHE.get(ob.name)
        if hit is not None and hit['sig'] == sig and time.monotonic() - hit['time'] < BVH_TTL:
            hit['time'] = time.monotonic()
            return hit['bvh'], hit['wverts'], hit['faces']
        M, t = _mat_np(mw)
        wv = co.reshape(-1, 3).astype(np.float64) @ M.T + t
        lv = np.empty(nl, dtype=np.int32)
        me.loops.foreach_get('vertex_index', lv)
        starts = np.empty(nf, dtype=np.int32)
        me.polygons.foreach_get('loop_start', starts)
        sizes = np.empty(nf, dtype=np.int32)
        me.polygons.foreach_get('loop_total', sizes)
    finally:
        ev.to_mesh_clear()
    if nf and bool((sizes == sizes[0]).all()):
        poly_list = lv.reshape(nf, int(sizes[0])).tolist()
    else:
        poly_list = [q.tolist() for q in np.split(lv, starts[1:])] if nf else []
    bvh = BVHTree.FromPolygons(wv.tolist(), poly_list)
    del poly_list
    faces = _FaceList(lv, starts, sizes)
    _BVH_CACHE.clear()
    _BVH_CACHE[ob.name] = dict(sig=sig, time=time.monotonic(), bvh=bvh, wverts=wv, faces=faces)
    return bvh, wv, faces


def forget_bvh(name=None):
    """Drop the cached target BVH (all of them when ``name`` is None)."""
    if name is None:
        _BVH_CACHE.clear()
    else:
        _BVH_CACHE.pop(name, None)


def project_patch(points, projector, bvh):
    """World positions + normals of 2D points on the surface (view rays).
    Misses go to the depth of the nearest hits.  Returns (cos, normals, misses)."""
    cos, nrms, missing = [None] * len(points), [None] * len(points), []
    for i, xy in enumerate(points):
        o, d = projector.ray(xy)
        loc, n, _i, _dist = bvh.ray_cast(o, d)
        if loc is None:
            missing.append(i)
            continue
        # second, short cast from just in front of the hit: a view ray starts far away and the first
        # hit is only float-precise to ~1e-4
        loc2, n2, _i2, _d2 = bvh.ray_cast(loc - d * 0.05, d, 0.1)
        if loc2 is not None:
            loc, n = loc2, n2
        if n.dot(d) > 0:
            n = -n
        cos[i], nrms[i] = loc, n.normalized()
    hits = [i for i in range(len(points)) if cos[i] is not None]
    if not hits:
        raise cg.CutError('The outline is not on a mesh: draw over the surface you want the plate on.')
    if missing:
        # 0.19.2: a point past the surface edge goes to the depth of the nearest hits on screen (a plane
        # facing the view), not onto one plane through all hits - that made spikes past a silhouette
        from mathutils.kdtree import KDTree
        kd = KDTree(len(hits))
        for i in hits:
            kd.insert((points[i][0], points[i][1], 0.0), i)
        kd.balance()
        for i in missing:
            o, d = projector.ray(points[i])
            near = kd.find_n((points[i][0], points[i][1], 0.0), min(3, len(hits)))
            wsum = t = 0.0
            n = Vector()
            for _co, j, dist in near:
                w = 1.0 / max(dist, 1e-6)
                t += (cos[j] - o).dot(d) * w
                n += nrms[j] * w
                wsum += w
            cos[i] = o + d * (t / wsum)
            nrms[i] = n.normalized() if n.length > 1e-9 else -projector.view_dir
    return cos, nrms, missing


def build_region(points, tris, cos_local, nrms_local, quads=True):
    """Region mesh (object space of the surface) with outward faces."""
    bm = bmesh.new()
    try:
        vs = [bm.verts.new(c) for c in cos_local]
        for a, b, c in tris:
            try:
                bm.faces.new((vs[a], vs[b], vs[c]))
            except ValueError:
                pass
        bm.normal_update()
        agree = sum(1 for f in bm.faces
                    if f.normal.dot(sum((nrms_local[v.index] for v in f.verts), Vector())) > 0)
        if agree < len(bm.faces) / 2:
            bmesh.ops.reverse_faces(bm, faces=bm.faces[:])
        if quads and bm.faces:
            bmesh.ops.join_triangles(bm, faces=bm.faces[:], angle_face_threshold=math.radians(25),
                                     angle_shape_threshold=math.radians(40))
        loose = [v for v in bm.verts if not v.link_faces]
        if loose:
            bmesh.ops.delete(bm, geom=loose, context='VERTS')
        me = bpy.data.meshes.new('MCH_PlateRegion')
        bm.to_mesh(me)
        from . import edge_memory as _em; _em.mark_generated(me)   # 0.24.95 Edge Memory: the part's own lines
    finally:
        bm.free()
    me.update()
    return me


def _face_arrays(polys):
    if isinstance(polys, _FaceList):
        return polys.flat, polys.starts, polys.sizes
    sizes = np.fromiter((len(q) for q in polys), dtype=np.int64, count=len(polys))
    flat = np.fromiter((i for q in polys for i in q), dtype=np.int64, count=int(sizes.sum()))
    starts = np.concatenate(([0], np.cumsum(sizes)[:-1])).astype(np.int64) if len(sizes) else np.zeros(0, np.int64)
    return flat, starts, sizes


def surround_mesh(verts_world, polys, inv, lo, hi):
    """Faces of the surface near the plate (object space), for outward rings.  0.24.131 numpy: every face with a
    point inside the box is kept (as before), without a Python loop over the whole body (2.2 s -> 0.05 s at 400 k)."""
    V = verts_world if isinstance(verts_world, np.ndarray) else np.array([tuple(v) for v in verts_world], dtype=np.float64)
    flat, starts, sizes = _face_arrays(polys)
    me = bpy.data.meshes.new('MCH_PlateSurround')
    nf = len(sizes)
    if nf and len(V):
        lo_a = np.array([lo[0], lo[1], lo[2]], dtype=np.float64)
        hi_a = np.array([hi[0], hi[1], hi[2]], dtype=np.float64)
        inside = np.all((V >= lo_a) & (V <= hi_a), axis=1)
        fid = np.repeat(np.arange(nf), sizes)
        keep_f = np.bincount(fid, weights=inside[flat].astype(np.float64), minlength=nf) > 0
        kept = np.nonzero(keep_f)[0]
        if len(kept):
            cmask = keep_f[fid]
            kc = flat[cmask]
            ksz = sizes[kept]
            uniq, remap = np.unique(kc, return_inverse=True)
            Mi, ti = _mat_np(inv)
            coords = V[uniq] @ Mi.T + ti
            faces = [f.tolist() for f in np.split(remap, np.cumsum(ksz)[:-1])]
            me.from_pydata(coords.tolist(), [], faces)
    me.update()
    return me


# -----------------------------------------------------------------------------
# Create
# -----------------------------------------------------------------------------


def plate_meshes(context, target, groups, projector, spacing):
    """Region + surround meshes (object space of ``target``) for the outline
    groups.  Returns (region, surround, local_size, missing)."""
    pts, tris, _nb = screen_patch(groups, spacing)
    if not tris:
        raise cg.CutError('The outline is too small for a plate.')
    bvh, wverts, polys = _target_bvh(context, target)
    cos, nrms, missing = project_patch(pts, projector, bvh)
    inv = target.matrix_world.inverted_safe()
    rot = inv.to_3x3()
    cos_l = [inv @ c for c in cos]
    nrm_l = [(rot @ n).normalized() for n in nrms]
    region = build_region(pts, tris, cos_l, nrm_l)
    lo = Vector([min(c[k] for c in cos) for k in range(3)])
    hi = Vector([max(c[k] for c in cos) for k in range(3)])
    size = max((hi - lo).length, 1e-6)
    pad = Vector((size * 0.25,) * 3)
    surround = surround_mesh(wverts, polys, inv, lo - pad, hi + pad)
    scale = target.matrix_world.to_scale()
    local_size = size / max(1e-9, (abs(scale.x) + abs(scale.y) + abs(scale.z)) / 3.0)
    return region, surround, local_size, missing



def through_plate_meshes(context, target, groups, projector, spacing, crease):
    """0.23.7 Through: [(region, surround, local_size)] - one per panel (front / back / creases)."""
    from . import through_region as tr
    panels = tr.panels_for(context, target, groups, projector, spacing, crease)
    _bvh, wverts, polys = _target_bvh(context, target)
    inv = target.matrix_world.inverted_safe()
    rot = inv.to_3x3()
    scale = target.matrix_world.to_scale()
    out = []
    for pn in panels:
        cos, nrms = pn['cos'], pn['nrms']
        region = build_region(cos, pn['tris'], [inv @ c for c in cos], [(rot @ n).normalized() for n in nrms])
        lo = Vector([min(c[k] for c in cos) for k in range(3)])
        hi = Vector([max(c[k] for c in cos) for k in range(3)])
        size = max((hi - lo).length, 1e-6)
        pad = Vector((size * 0.25,) * 3)
        surround = surround_mesh(wverts, polys, inv, lo - pad, hi + pad)
        local_size = size / max(1e-9, (abs(scale.x) + abs(scale.y) + abs(scale.z)) / 3.0)
        out.append((region, surround, local_size))
    return out

def perform_plate(context, loops, projector, preset=None, spacing=None):
    """Lasso -> new armour plate object (a live Face Extract part).  Returns
    a report; raises cg.CutError with the scene unchanged.

    0.19: the outline and the view are kept on the plate (``SRC_KEY``) until
    Apply, so Face Size / height / chamfer / profile change it live (HUD).
    ``spacing``: its own Face Size (px) instead of the window's (0.24.174 Weathering: finer, so it follows a
    curved body - the window's value untouched: setting it would lay the selected plate again)."""
    scene = context.scene
    st = scene.mch_plate
    preset = preset or st.preset
    face_px = int(spacing) if spacing else int(st.spacing)
    if preset == 'MRIDGE':
        from . import mech_ridge
        return mech_ridge.perform(context, loops, projector)
    groups = cg.prepare_loops(loops)
    target = pick_surface(context, projector, groups)
    if target is None:
        raise cg.CutError('Draw the plate over a mesh (armour parts and plates are skipped).')
    brush = getattr(scene, 'mch_brush', None)
    if getattr(brush, 'through_mode', False):
        return _perform_through(context, loops, projector, preset, target, groups, st, brush)
    from . import ramp_edit
    _old = ramp_edit.live_target(context, ('platecarve',))
    if _old is not None:
        ramp_edit.finish(_old)                   # 0.24.293 a new plate: the live Alt carve is kept as it is
    region, surround, local_size, missing = plate_meshes(context, target, groups, projector, face_px)
    part = create_plate(context, target, region, surround, preset, local_size, st.auto_size)
    frozen = freeze_projector(projector)
    recalled = False
    if frozen is not None:
        part[SRC_KEY] = json.dumps({'loops': [[[float(x), float(y)] for x, y in lp] for lp in loops],
                                    'proj': frozen, 'spacing': face_px, 'size': local_size})
        recalled = recall_plate(part, local_size, preset)      # 0.20.2 last used profile / lines / rims
        from . import tool_state as _ts_, mold_cut as _mcm
        if not _ts_.mold_on(context) and _mcm.strip(part.mch_extract):   # 0.24.305 (a remembered molding: off here)
            from . import face_extract as _fx
            _fx.rebuild(part)
    scene.mch_extract_last = part
    if getattr(st, 'creature', False):
        from . import creature_shell
        creature_shell.attach(part, -Vector(projector.view_dir), local_size)
    for o in context.selected_objects:
        o.select_set(False)
    part.select_set(True)
    context.view_layer.objects.active = part
    name = dict((p_[0], p_[1]) for p_ in PRESETS)[preset]
    extra = f' | {len(missing)} point(s) past the surface edge' if missing else ''
    return f'Armor plate "{part.name}" on {target.name} ({name}, {len(region.polygons)} clean faces){extra}'



def heights_above(verts, bvh):
    """(surface point, normal, height above it) for every point (None for a point with no surface)."""
    out = []
    for v in verts:
        loc, nrm, _i, _d = bvh.find_nearest(v)
        if loc is None:
            out.append(None)
            continue
        n = nrm.normalized()
        out.append((loc, n, (Vector(v) - loc).dot(n)))
    return out


def mirrored_into(verts, bvh, lift, scale=1.0):
    """Every point mirrored through the surface under it (``bvh``, world): what stood out of the surface now goes
    as deep into it (x ``scale``: 0.24.42 Carve Depth).  Points on / just under the surface come out ``lift``
    above it, so the opening is clean."""
    out = []
    for v, h in zip(verts, heights_above(verts, bvh)):
        if h is None:
            out.append(Vector(v))
            continue
        loc, n, d = h
        p = loc - n * (d * scale)
        out.append(p + n * lift if d < lift else p)
    return out


def _densify(me, n=24):
    """0.24.291 the region mesh split into small triangles (about ``n`` across): on a flat face the region was one
    big face round the outline - no point inside to raise the Center Ridge, the plate came out flat."""
    bm = bmesh.new()
    try:
        bm.from_mesh(me)
        if not bm.faces:
            return
        lo = Vector([min(v.co[i] for v in bm.verts) for i in range(3)])
        hi = Vector([max(v.co[i] for v in bm.verts) for i in range(3)])
        step = max((hi - lo).length / n, 1e-6)
        bmesh.ops.triangulate(bm, faces=bm.faces[:], quad_method='BEAUTY', ngon_method='BEAUTY')
        for _ in range(6):
            long_ = [e for e in bm.edges if e.calc_length() > step]
            if not long_:
                break
            bmesh.ops.subdivide_edges(bm, edges=long_, cuts=1, use_grid_fill=False)
            bmesh.ops.triangulate(bm, faces=[f for f in bm.faces if len(f.verts) > 3])
        bm.to_mesh(me)
    finally:
        bm.free()


def _carve_mirror(context, target, part, remove, st):
    """0.24.291 the ridge presets (Center Ridge, Mech Ridge): the plate turned the other way - mirrored through the
    surface into the mesh - and carved out: its ridge becomes a valley (the deepest along the ridge line).  part:
    the plate just made, taken away with remove.  Returns the depth."""
    scene = context.scene
    try:
        dg = context.evaluated_depsgraph_get()
        dg.update()
        ev = _lc_full(part, dg)
        pm = ev.to_mesh()
        try:
            mw = ev.matrix_world
            verts = [mw @ v.co for v in pm.vertices]
            faces = [tuple(p.vertices) for p in pm.polygons]
        finally:
            ev.to_mesh_clear()
    finally:
        remove(part)
    if not faces:
        raise cg.CutError('The plate came out empty; nothing was carved.')
    tev = _lc_full(target, context.evaluated_depsgraph_get())
    tme = tev.to_mesh()
    try:
        tw = tev.matrix_world
        bvh = BVHTree.FromPolygons([tw @ v.co for v in tme.vertices], [tuple(p.vertices) for p in tme.polygons])
    finally:
        tev.to_mesh_clear()
    lo = Vector([min(v[i] for v in verts) for i in range(3)])
    hi = Vector([max(v[i] for v in verts) for i in range(3)])
    lift = max((hi - lo).length * 0.004, 1e-5)
    tall = max((h[2] for h in heights_above(verts, bvh) if h is not None), default=0.0)
    depth = getattr(st, 'carve_depth', 0.0)
    scale = depth / tall if depth > 0 and tall > 1e-9 else 1.0          # Carve Depth: 0 = as tall as the plate
    world = mirrored_into(verts, bvh, lift, scale)
    inv = target.matrix_world.inverted()
    me = bpy.data.meshes.new('MCH_PlateCarve')
    me.from_pydata([tuple(inv @ v) for v in world], [], faces)
    me.validate()
    bm = bmesh.new()
    try:
        bm.from_mesh(me)
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
        bm.to_mesh(me)
    finally:
        bm.free()
    cutter = cg.link_temp_object(context, me, 'MCH_Cutter_Plate')
    cutter.matrix_world = target.matrix_world.copy()
    cut = scene.mch_cut
    try:
        res, _solver = cg.boolean_result(context, target, cutter, 'DIFFERENCE', cut.solver, cut.hole_tolerant)
        try:
            cg.commit_mesh(target, res, cut.shared_mesh)
        finally:
            if res.users == 0:
                bpy.data.meshes.remove(res)
    finally:
        cg.remove_object_and_mesh(cutter)
    return tall * scale


def px_per_world(projector, target):
    """Screen px per world unit at ``target`` (0.0: unknown)."""
    if hasattr(projector, 'ppu'):
        return float(projector.ppu)
    try:
        c = target.matrix_world @ (sum((Vector(b) for b in target.bound_box), Vector()) / 8.0)
        right = projector.rv3d.view_rotation @ Vector((1.0, 0.0, 0.0))
        step = max(1e-4, 0.01 * max(target.dimensions))
        a, b = projector.to_screen(c), projector.to_screen(c + right * step)
        return math.hypot(b[0] - a[0], b[1] - a[1]) / step if a is not None and b is not None else 0.0
    except (AttributeError, ReferenceError, ValueError, ZeroDivisionError, TypeError):
        return 0.0


def _area2(lp):
    return sum(lp[i - 1][0] * lp[i][1] - lp[i][0] * lp[i - 1][1] for i in range(len(lp)))


def _crosses(lp):
    """The closed outline crosses itself (any two edges that are not neighbours intersect)."""
    n = len(lp)

    def ccw(a, b, c):
        return (c[1] - a[1]) * (b[0] - a[0]) - (b[1] - a[1]) * (c[0] - a[0])
    segs = [(lp[i], lp[(i + 1) % n]) for i in range(n)]
    for i in range(n):
        a, b = segs[i]
        for j in range(i + 2, n):
            if i == 0 and j == n - 1:
                continue
            c, d = segs[j]
            if max(a[0], b[0]) < min(c[0], d[0]) or max(c[0], d[0]) < min(a[0], b[0]):
                continue
            if max(a[1], b[1]) < min(c[1], d[1]) or max(c[1], d[1]) < min(a[1], b[1]):
                continue
            if ccw(a, b, c) * ccw(a, b, d) < 0 and ccw(c, d, a) * ccw(c, d, b) < 0:
                return True
    return False


def step_loops(loops, inset_px):
    """0.24.296 the drawn outline(s) moved in by ``inset_px`` on the screen (a step of a stepped carve), or None when
    the shape is too small for it.  An even inset where it stays a clean outline; where it would cross itself (tight
    lobes of a wiggly outline) the outline drawn in toward its middle instead."""
    from .base_mesh import offset_outline
    out = []
    for lp in loops:
        lp = [tuple(q) for q in lp]
        if len(lp) >= 3 and math.dist(lp[0], lp[-1]) < 1e-6:
            lp = lp[:-1]
        if len(lp) < 3:
            return None
        a0 = _area2(lp)
        ccw = lp if a0 > 0 else lp[::-1]
        inner = offset_outline(ccw, -inset_px, limit=2.0)
        if _area2(inner) <= abs(a0) * 0.04 or _crosses(inner):
            cx = sum(q[0] for q in lp) / len(lp)
            cy = sum(q[1] for q in lp) / len(lp)
            rad = sum(math.hypot(q[0] - cx, q[1] - cy) for q in lp) / len(lp)
            s = 1.0 - inset_px / max(rad, 1e-9)
            if s < 0.2:
                return None
            inner = [(cx + (q[0] - cx) * s, cy + (q[1] - cy) * s) for q in ccw]
        out.append(inner if a0 > 0 else inner[::-1])
    return out


def carve_warp(projector, loops, target, depth, angle):
    """0.24.295 Alt carve Wall Angle: the cutter's far cap drawn in toward the shape's middle by depth x tan(angle) (on
    the screen, as Press Cut's Wall Angle): a function xy -> xy, or None (straight walls)."""
    if angle < 1e-4 or depth <= 0.0:
        return None
    pts = [p for lp in loops for p in lp]
    if not pts:
        return None
    pxw = px_per_world(projector, target)
    cx = sum(p[0] for p in pts) / len(pts)
    cy = sum(p[1] for p in pts) / len(pts)
    rad = sum(math.hypot(p[0] - cx, p[1] - cy) for p in pts) / len(pts)
    if pxw <= 0.0 or rad <= 1e-6:
        return None
    s = max(0.15, 1.0 - depth * math.tan(angle) * pxw / rad)
    return lambda xy: (cx + (xy[0] - cx) * s, cy + (xy[1] - cy) * s)


def carve_profile(preset, size, auto=True, memory=None, scale=1.0):
    """0.24.290 the Alt carve's recess from the plate profile: (depth, edge finish 'NONE' / 'CHAMFER' / 'BEVEL', width,
    segments, profile) in world units for a plate ``size`` (world) - what the plate has at its top edge goes on the
    recess's opening (a Chamfer plate: a chamfered opening, a Round one: a rounded opening, Stepped: a wide chamfer)."""
    vals = dict(preset_values(preset, size, auto))
    for k, v in (memory or {}).items():          # (what you changed on the last plate of this profile: local units)
        vals[k] = v * scale if k in LENGTH_KEYS and isinstance(v, (int, float)) else v
    depth = float(vals.get('extract_height', 0.03 * size)) + float(vals.get('thickness', 0.0) or 0.0) * 0.0
    cw = float(vals.get('chamfer_width', 0.0) or 0.0) + float(vals.get('outer_chamfer_width', 0.0) or 0.0)
    bw = float(vals.get('bevel_width', 0.0) or 0.0)
    if cw > 1e-9:
        kind, width, segs = 'CHAMFER', cw, 1
    elif bw > 1e-9:
        kind, width, segs = 'BEVEL', bw, int(vals.get('bevel_segments', 3) or 3)
    else:
        kind, width, segs = 'NONE', 0.0, 1
    return depth, kind, width, segs, float(vals.get('bevel_profile', 0.5) or 0.5)


def perform_plate_carve(context, loops, projector, preset=None, target=None, live=None):
    """0.24.293 (user: "알트 눌러서 빼는 거 뺀 이후에 실시간으로 조정하는 거 왜 안 돼?") the carve stays live like the
    Cut tool's last cut (ramp_edit 'platecarve'): the mesh before it is kept; Alt Carve Depth / Floor and the profile
    carve it again from that mesh until the next carve / plate (or an edit of the mesh).  ``target``: carve into
    this part (a re-carve); ``live``: None = the Live Last Cut preference."""
    from . import ramp_edit
    groups = cg.prepare_loops(loops)
    if target is None:
        target = pick_surface(context, projector, groups)
    if target is None:
        raise cg.CutError('Alt + draw carves a plate into a mesh: draw over one (armour parts and plates are '
                          'skipped).')
    if live is None:
        from .workspace_ui import pref
        live = bool(pref('live_last_cut', True))
    if live:
        cg.check_target(target)
        ramp_edit.begin(context, target, loops, projector, kind='platecarve', extra={'preset': preset or ''})
    try:
        msg = _plate_carve(context, loops, projector, preset, target, groups)
    except Exception:
        if live:
            ramp_edit.finish(target)
        raise
    if live:
        ramp_edit.stamp(target)
        msg += ' | live: Alt Carve Depth / Floor / profile carve it again'
    return msg


def _plate_carve(context, loops, projector, preset, target, groups):
    """0.24.42 Alt + draw with the Armor Plate tool: a recess in the shape drawn, as deep as the plate would be tall.
    0.24.290 (user: "알트로 빼는 거는 왜 아머 플레이트 프리셋 고른 거랑 상관없이 다 똑같은 모양으로 빠져?") - it was the plate
    mirrored through the surface, so the profile's top edge went to the bottom of the recess and every opening was the
    same sharp hole: now the outline is cut in From Surface and the profile's top edge (Chamfer / Bevel / Round /
    Stepped ...) is the opening's edge.  Returns a report; raises cg.CutError (the mesh unchanged)."""
    scene = context.scene
    st = scene.mch_plate
    cg.check_target(target)
    preset = preset or st.preset
    from . import mold_cut as _mc
    mcs_ = _mc.settings(context)                     # 0.24.304 Mold Cut (the carve's own moldings)
    molded_ = mcs_ is not None
    if preset in {'RIDGE', 'MRIDGE'} or (molded_ and preset != 'MRIDGE'):
        # 0.24.300 (user: "왜 컷할 때는 림이랑 몰드가 적용이 안 돼?" / "당연히 빠지는 걸로") a plate with Edge Molding / a
        # Top Dome is carved the same way: the plate turned the other way - its flange a wide step at the opening,
        # its top band an undercut by the floor, the Lip Rim a ring groove round the floor, the Dome a bowl
        # 0.24.291 (user: "릿지는?") a ridge's shape is its whole top, not an edge: the plate turned the other way
        from . import face_extract as fx
        if preset == 'MRIDGE':
            from . import mech_ridge
            before = set(bpy.data.objects)
            mech_ridge.perform(context, loops, projector)
            made = [o for o in bpy.data.objects if o not in before]
            if not made:
                raise cg.CutError('The ridge came out empty; nothing was carved.')
            part = made[0]

            def remove(o):
                me_ = o.data
                bpy.data.objects.remove(o, do_unlink=True)
                if me_ is not None and me_.users == 0:
                    bpy.data.meshes.remove(me_)
        else:
            region, surround, local_size, _m = plate_meshes(context, target, groups, projector, st.spacing)
            _densify(region)
            part = create_plate(context, target, region, surround, preset, local_size, st.auto_size)
            remove = fx._remove_part
            pe_ = part.mch_extract                   # 0.24.304 the Mold Cut's molding, not the plates' Edge Molding
            for k_ in _mc.KEYS:
                setattr(pe_, k_, getattr(mcs_, k_) if mcs_ is not None else (False if k_ in {'emold_top', 'emold_bottom'}
                                                                             else getattr(pe_, k_)))
            if mcs_ is None:
                pe_.emold_dome = 0.0
            fx.rebuild(part)
        deep = _carve_mirror(context, target, part, remove, st)
        for o in context.selected_objects:
            o.select_set(False)
        target.select_set(True)
        context.view_layer.objects.active = target
        name = dict((p_[0], p_[1]) for p_ in PRESETS)[preset]
        return f'Armor plate carved into "{target.name}" (Alt: {name} the other way round - a valley, {deep:.3g} deep)'
    region, surround, local_size, _missing = plate_meshes(context, target, groups, projector, st.spacing)
    for me_ in (region, surround):
        if me_ is not None and me_.users == 0:
            bpy.data.meshes.remove(me_)
    sc = target.matrix_world.to_scale()
    scale = (abs(sc.x) + abs(sc.y) + abs(sc.z)) / 3.0
    depth, kind, width, segs, prof = carve_profile(preset, local_size * scale, st.auto_size,
                                                   plate_memory(scene).get(preset, {}), scale)
    if getattr(st, 'carve_depth', 0.0) > 0.0:     # Carve Depth: 0 = as deep as the plate is tall
        depth = float(st.carve_depth)
    width = min(width, depth * 0.95)
    from . import cut_engine as ce
    cut = scene.mch_cut
    keep = (cut.depth_mode, cut.depth, cut.edge_finish, cut.gn_finish, cut.gn_width, cut.gn_segments, cut.gn_ramp,
            cut.depth_floor)
    steps_done = [0]
    try:
        cut.depth_mode, cut.depth = 'SURFACE', max(depth, 1e-5)
        cut.edge_finish = 'NONE'
        # (the GN Edge: the profile swept along the opening only, its full width - the plain bevel was clamped by
        #  the short walls to a sliver)
        cut.gn_ramp = False
        # 0.24.291 (user: "표면 따라서 들어가야지 왜 한쪽이 깊게 들어가?") the floor follows the surface under the
        # shape (a flat floor went deeper on one side of a slanted / curved surface)
        cut.depth_floor = getattr(st, 'carve_floor', 'FOLLOW')
        cut.gn_finish = kind if width > 1e-9 else 'NONE'
        cut.gn_width, cut.gn_segments = width, max(2, segs) if kind == 'BEVEL' else 1
        cg.WARP[0] = carve_warp(projector, loops, target, depth, getattr(st, 'carve_wall', 0.0))   # 0.24.295
        ce.perform_closed(context, 'CUT', [target], loops, projector)
        # 0.24.296 (user: "알트로 빼낼 때 바닥 쪽에 계단처럼 한 단 더 파이면서 들어가는 것") Steps: the floor carved again,
        # the outline moved in by Step Inset, Step Depth deeper (from the floor: From Surface follows it), as often as
        # Steps says; the edge the same kind as the opening's, no wider than the step is deep
        n_steps = int(getattr(st, 'carve_steps', 0))
        if n_steps > 0:
            pxw = px_per_world(projector, target)
            sdepth = float(getattr(st, 'step_depth', 0.0)) or depth * 0.5
            sinset = float(getattr(st, 'step_inset', 0.0))
            cur = loops
            if pxw > 0.0:
                pts = [q for lp in loops for q in lp]
                cx = sum(q[0] for q in pts) / len(pts)
                cy = sum(q[1] for q in pts) / len(pts)
                rad = sum(math.hypot(q[0] - cx, q[1] - cy) for q in pts) / len(pts)
                inset_px = sinset * pxw if sinset > 0.0 else rad * 0.22
                inset_px = max(inset_px, width * pxw + 2.0)       # (past the opening's edge finish)
                for k_ in range(n_steps):
                    nxt = step_loops(loops, inset_px * (k_ + 1))     # (each step from the drawn outline)
                    if nxt is None:
                        break
                    cur = nxt
                    cut.depth = max(sdepth, 1e-5)
                    sw = min(width, sdepth * 0.95)
                    cut.gn_finish = kind if sw > 1e-9 else 'NONE'
                    cut.gn_width = sw
                    cg.WARP[0] = carve_warp(projector, cur, target, sdepth, getattr(st, 'carve_wall', 0.0))
                    ce.perform_closed(context, 'CUT', [target], cur, projector)
                    steps_done[0] += 1
    finally:
        cg.WARP[0] = None
        (cut.depth_mode, cut.depth, cut.edge_finish, cut.gn_finish, cut.gn_width, cut.gn_segments,
         cut.gn_ramp, cut.depth_floor) = keep
    for o in context.selected_objects:
        o.select_set(False)
    target.select_set(True)
    context.view_layer.objects.active = target
    name = dict((p_[0], p_[1]) for p_ in PRESETS)[preset]
    edge = {'CHAMFER': 'chamfered', 'BEVEL': 'rounded'}.get(kind, 'sharp') if width > 1e-9 else 'sharp'
    st_ = f', {steps_done[0]} step{"s" if steps_done[0] != 1 else ""} more' if steps_done[0] else ''
    return f'Armor plate carved into "{target.name}" (Alt: {name}, {depth:.3g} deep, {edge} opening{st_})'


def _perform_through(context, loops, projector, preset, target, groups, st, brush):
    """0.23.7 Through: one plate per panel (front / back / creases), each keeps its outline for Face Size."""
    crease = float(getattr(brush, 'through_crease', 50.0))
    made = through_plate_meshes(context, target, groups, projector, st.spacing, crease)
    frozen = freeze_projector(projector)
    parts = []
    for k, (region, surround, local_size) in enumerate(made):
        part = create_plate(context, target, region, surround, preset, local_size, st.auto_size)
        if frozen is not None:
            part[SRC_KEY] = json.dumps({'loops': [[[float(x), float(y)] for x, y in lp] for lp in loops],
                                        'proj': frozen, 'spacing': int(st.spacing), 'size': local_size,
                                        'through': k, 'crease': crease})
            recall_plate(part, local_size, preset)
        if getattr(st, 'creature', False):
            from . import creature_shell
            nr = sum((Vector(p_.normal) for p_ in region.polygons), Vector())
            up = target.matrix_world.to_3x3() @ nr if nr.length > 1e-9 else -Vector(projector.view_dir)
            creature_shell.attach(part, up, local_size)
        parts.append(part)
    context.scene.mch_extract_last = parts[0]
    for o in context.selected_objects:
        o.select_set(False)
    for part in parts:
        part.select_set(True)
    context.view_layer.objects.active = parts[0]
    name = dict((p_[0], p_[1]) for p_ in PRESETS)[preset]
    return f'Armor plate through {target.name}: {len(parts)} plate(s) ({name}, front / back / creases)'


# -----------------------------------------------------------------------------
# 0.19 live plate: the drawn outline + a frozen view, rebuilt on demand
# -----------------------------------------------------------------------------

SRC_KEY = 'mch_plate_src'


class FrozenProjector:
    """A viewport projection saved as plain numbers (perspective matrix +
    region size), so the plate can be re-projected after the view moved."""

    def __init__(self, data):
        self.pers = Matrix(data['pers'])
        self.inv = self.pers.inverted_safe()
        self.w, self.h = float(data['w']), float(data['h'])
        self.is_perspective = bool(data['persp'])
        self.eye = Vector(data['eye'])
        self.view_dir = Vector(data['dir']).normalized()

    def _un(self, nx, ny, z):
        v = self.inv @ Vector((nx, ny, z, 1.0))
        return v.xyz / (v.w if abs(v.w) > 1e-12 else 1e-12)

    def ray(self, xy):
        nx, ny = 2.0 * xy[0] / self.w - 1.0, 2.0 * xy[1] / self.h - 1.0
        a, b = self._un(nx, ny, -1.0), self._un(nx, ny, 1.0)
        d = (b - a).normalized()
        return (self.eye.copy() if self.is_perspective else a), d

    def to_screen(self, co):
        p = self.pers @ Vector((co[0], co[1], co[2], 1.0))
        if p.w <= 1e-9:
            return None
        return ((p.x / p.w + 1.0) * self.w / 2.0, (p.y / p.w + 1.0) * self.h / 2.0)


def freeze_projector(pr):
    if isinstance(pr, cg.OrthoProjector):
        return {'kind': 'ortho', 'rot': list(pr.rot.to_quaternion()), 'center': list(pr.center), 'ppu': pr.ppu,
                'size': list(pr.size)}
    rv3d, region = getattr(pr, 'rv3d', None), getattr(pr, 'region', None)
    if rv3d is None or region is None:
        return None
    return {'kind': 'view', 'pers': [list(r) for r in rv3d.perspective_matrix], 'w': region.width,
            'h': region.height, 'persp': bool(pr.is_perspective), 'eye': list(pr.eye), 'dir': list(pr.view_dir)}


def thaw_projector(data):
    if data.get('kind') == 'ortho':
        return cg.OrthoProjector(Quaternion(data['rot']), Vector(data['center']), data['ppu'], tuple(data['size']))
    return FrozenProjector(data)


def plate_source(ob):
    """The saved outline of a plate still waiting for Apply (or None)."""
    if ob is None or not is_plate_or_part(ob):
        return None
    try:
        raw = ob.get(SRC_KEY)
    except (TypeError, ReferenceError):
        return None
    if not raw:
        return None
    try:
        return json.loads(raw)
    except (TypeError, ValueError):
        return None


def rebuild_plate(context, ob, spacing=None):
    """New faces for a live plate from its saved outline (Face Size changed).
    The profile settings stay as they are.  Returns True when rebuilt."""
    from . import face_extract as fx
    src = plate_source(ob)
    p = ob.mch_extract
    target = p.source
    if src is None or target is None or target.name not in bpy.data.objects:
        return False
    spacing = int(src.get('spacing', 120) if spacing is None else spacing)
    groups = cg.prepare_loops([[tuple(q) for q in lp] for lp in src['loops']])
    try:
        if src.get('through') is not None:
            made = through_plate_meshes(context, target, groups, thaw_projector(src['proj']), spacing,
                                        float(src.get('crease', 50.0)))
            k = int(src['through'])
            if k >= len(made):
                return False
            region, surround = made[k][0], made[k][1]
            for j, (r_, s_, _z) in enumerate(made):
                if j != k:
                    bpy.data.meshes.remove(r_)
                    bpy.data.meshes.remove(s_)
        else:
            region, surround, _size, _miss = plate_meshes(context, target, groups, thaw_projector(src['proj']),
                                                          spacing)
    except cg.CutError:
        return False
    old = (p.region, p.surround)
    p.region, p.surround = region, surround
    for m in old:
        if m is not None and m.users == 0:
            bpy.data.meshes.remove(m)
    src['spacing'] = spacing
    ob[SRC_KEY] = json.dumps(src)
    fx.rebuild(ob)
    return True


BAKED_KEY = 'mch_plate_baked'


def _settings(p):
    from . import face_extract as fx
    out = {}
    for k in fx.SETTING_KEYS:
        v = getattr(p, k)
        if isinstance(v, (bool, int, float, str)):
            out[k] = v
    return out


def plate_hp_data(ob):
    """Everything needed to rebuild a plate densely: outline, view, target and
    profile settings (live plate, or a plate applied since 0.19.2)."""
    src = plate_source(ob)
    if src is not None and ob.mch_extract.source is not None:
        return dict(src, target=ob.mch_extract.source.name, settings=_settings(ob.mch_extract))
    try:
        raw = ob.get(BAKED_KEY)
        return json.loads(raw) if raw else None
    except (TypeError, ValueError, ReferenceError):
        return None


def dense_plate_mesh(context, ob, spacing=10):
    """0.19.2 High Poly of a plate: the SAME plate rebuilt with small faces from
    its outline (or, for other live parts, with a finer resolution), so the
    shape and the crisp edges are kept.  Returns a new mesh or None."""
    from . import face_extract as fx
    data = plate_hp_data(ob)
    p = ob.mch_extract
    live_part = p.is_part and p.region is not None
    if data is None and not live_part:
        return None
    me_tmp = bpy.data.meshes.new('MCH_HPtmp')
    tmp = bpy.data.objects.new('MCH_HPtmp', me_tmp)
    context.scene.collection.objects.link(tmp)
    tmp.matrix_world = ob.matrix_world.copy()
    tp = tmp.mch_extract
    made = []
    try:
        for k, v in (data['settings'] if data else _settings(p)).items():
            try:
                setattr(tp, k, v)
            except (TypeError, AttributeError, ValueError):
                pass
        if tp.bevel_width > 0:
            tp.bevel_segments = max(tp.bevel_segments, 6)
        target = bpy.data.objects.get(data['target']) if data else None
        if data and target is not None:
            groups = cg.prepare_loops([[tuple(q) for q in lp] for lp in data['loops']])
            region, surround, _s, _m = plate_meshes(context, target, groups, thaw_projector(data['proj']), spacing)
            tp.resolution = 0
            tp.source = target
        elif live_part:
            region = p.region.copy()
            surround = p.surround.copy() if p.surround is not None else None
            tp.resolution = min(4, p.resolution + 2)
            tp.source = p.source
        else:
            return None
        made = [region, surround]
        tp.region, tp.surround = region, surround
        if not fx.rebuild(tmp):
            return None
        dg = context.evaluated_depsgraph_get()
        return bpy.data.meshes.new_from_object(_lc_full(tmp, dg), depsgraph=dg)
    except cg.CutError:
        return None
    finally:
        bpy.data.objects.remove(tmp)
        for m in [me_tmp] + made:
            if m is not None and m.users == 0:
                bpy.data.meshes.remove(m)


def apply_plate(ob):
    """Apply: the plate becomes a plain mesh (modifiers applied, no live part).
    The outline + settings are kept (``BAKED_KEY``) for Make High Poly."""
    p = ob.mch_extract
    data = plate_hp_data(ob)
    dg = bpy.context.evaluated_depsgraph_get()
    me = bpy.data.meshes.new_from_object(_lc_full(ob, dg), depsgraph=dg)
    old, region, surround = ob.data, p.region, p.surround
    ob.modifiers.clear()
    ob.data = me
    me.name = old.name
    try:                                          # 0.24.95 the marks of the final shape (bevel / shell edges included)
        from . import edge_memory as _em
        import numpy as _np
        _em.mark_generated(me)
        lines = me.attributes.get('mch_crease')
        if lines is not None and lines.domain == 'EDGE' and len(me.edges):
            v = _np.zeros(len(me.edges), _np.float32)
            lines.data.foreach_get('value', v)
            if (v > 0.5).any():
                _em.mark_edges(me, v > 0.5, add=True)
    except Exception as ex:
        print('Mecha: plate apply marks:', ex)
    p.is_part = False
    p.region = p.surround = None
    if SRC_KEY in ob:
        del ob[SRC_KEY]
    if data is not None:
        ob[BAKED_KEY] = json.dumps(data)
    for m in (old, region, surround):
        if m is not None and m.users == 0:
            bpy.data.meshes.remove(m)


# 0.24.145 (user: "아머 플레이트도 저장이 안 돼" - "방금 그리면서 ... 값을 조정했으면 다음 긋는 선은 그 값을 기억해야 될 거 아녀,
# 블렌더를 끄고 새 프로젝트를 열면 기본값") a value you change on a live plate goes on to the next plate of that profile
# (kept on the scene: saved with the file, a new file starts with the defaults); what the preset gave it is not
MEMORY_KEY = 'mch_plate_memory'          # scene: {preset: {setting: value}}
BORN_KEY = 'mch_plate_born'              # a plate: its settings as it was made
PRESET_KEY = 'mch_plate_preset'


def _settings_of(p):
    from . import face_extract as fx
    out = {}
    for k in fx.SETTING_KEYS:
        try:
            v = getattr(p, k)
        except AttributeError:
            continue
        if isinstance(v, (bool, int, float, str)):
            out[k] = v
        elif hasattr(v, '__len__') and not isinstance(v, str) and all(isinstance(x, (int, float)) for x in v):
            out[k] = list(v)
    return out


def plate_memory(scene):
    try:
        return json.loads(scene.get(MEMORY_KEY) or '{}')
    except (TypeError, ValueError, ReferenceError):
        return {}


def remember(ob, scene):
    """The settings of live plate ``ob`` that differ from what it was made with: kept for the next plate of its
    profile."""
    if scene is None or not ob.get(BORN_KEY):
        return
    try:
        born = json.loads(ob[BORN_KEY])
    except (TypeError, ValueError):
        return
    now = _settings_of(ob.mch_extract)
    mem = plate_memory(scene)
    slot = mem.setdefault(ob.get(PRESET_KEY, ''), {})
    changed = False
    for k, v in now.items():
        b = born.get(k)
        same = (abs(v - b) < 1e-9) if isinstance(v, float) and isinstance(b, (int, float)) else v == b
        if not same and slot.get(k) != v:
            slot[k] = v
            changed = True
    if changed:
        scene[MEMORY_KEY] = json.dumps(mem)


def create_plate(context, target, region, surround, preset, local_size, auto=True, collection='Armor Plates',
                 height_scale=1.0):
    """A live Face Extract part on ``target`` from a region / surround mesh
    (object space of the target).  Raises cg.CutError when it cannot be built."""
    from . import face_extract as fx
    scene = context.scene
    me = bpy.data.meshes.new(target.name + '_Plate')
    part = bpy.data.objects.new(me.name, me)
    fx._parts_collection(context, collection).objects.link(part)
    part.matrix_world = target.matrix_world.copy()
    for mat in target.data.materials:
        me.materials.append(mat)
    p = part.mch_extract
    defaults = scene.mch_extract
    for key in fx.SETTING_KEYS:
        setattr(p, key, getattr(defaults, key))
    for k, v in preset_values(preset, local_size, auto).items():
        if k == 'extract_height':
            v *= height_scale
        try:
            setattr(p, k, v)
        except (TypeError, AttributeError):
            pass
    for k, v in plate_memory(scene).get(preset or '', {}).items():   # 0.24.145 what you changed on the last plate
        try:
            setattr(p, k, tuple(v) if isinstance(v, list) else v)
        except (TypeError, AttributeError, ValueError):
            pass
    from . import tool_state as _ts_, mold_cut as _mcm
    if not _ts_.mold_on(context):                # 0.24.305 the original Armor Plate: no moldings
        _mcm.strip(p)
    p.resolution = 0                          # the patch is already dense and even
    part[BORN_KEY] = json.dumps(_settings_of(p))
    part[PRESET_KEY] = preset or ''
    p.source = target
    p.region = region
    p.surround = surround
    p.is_part = True
    if not fx.rebuild(part):
        note = p.notes
        fx._remove_part(part)
        raise cg.CutError('Plate could not be built: ' + note)
    return part


def cycle_preset(scene, step):
    st = scene.mch_plate
    i = PRESET_IDS.index(st.preset) if st.preset in PRESET_IDS else 0
    _QUIET[0] = True                     # 0.24.293 the wheel while drawing picks the NEXT plate's profile: the live
    try:                                 # Alt carve is not carved again with it
        st.preset = PRESET_IDS[(i + step) % len(PRESET_IDS)]
    finally:
        _QUIET[0] = False
    return dict((p[0], p[1]) for p in PRESETS)[st.preset]


# -----------------------------------------------------------------------------
# Settings / panel
# -----------------------------------------------------------------------------


def pending_plate(context):
    """The active plate that is still live (drawn, not applied yet)."""
    ob = getattr(context, 'active_object', None)
    return ob if plate_source(ob) is not None else None


def live_any(context):
    """(the active plate still waiting for Apply, 'PLATE' - a Face Extract plate - or 'MRIDGE') / (None, None)."""
    ob = pending_plate(context)
    if ob is not None:
        return ob, 'PLATE'
    from . import mech_ridge
    ob = mech_ridge.live_plate(context)
    return (ob, 'MRIDGE') if ob is not None else (None, None)


def swap_profile(context, ob, kind, preset):
    """0.24.95 (user: "아머 플레이트 할 때 왜 메카 리지랑 다른 거가 바뀌지가 않아?") the live plate ``ob`` drawn again
    from its own outline and view as ``preset`` when the profile changes kind: Mech Ridge is a plate of its own (a
    sloped roof, mech_ridge.py) and the other profiles are Face Extract parts - picking one from the other only set
    the NEXT plate.  The old plate is hidden while the new one is cast (it lands on the part, not on the old
    plate) and removed once the new one stands; when that fails the old plate stays.  Returns the report."""
    from . import face_extract as fx
    from . import mech_ridge
    src = plate_source(ob) if kind == 'PLATE' else mech_ridge.source(ob)
    if src is None or not src.get('loops') or src.get('proj') is None:
        raise cg.CutError('This plate has no saved outline: draw it again with the new profile.')
    if src.get('through') is not None:
        raise cg.CutError('A Through plate cannot change to Mech Ridge: draw it again with that profile.')
    loops = [[tuple(q) for q in lp] for lp in src['loops']]
    proj = thaw_projector(src['proj'])
    if proj is None:
        raise cg.CutError('The view this plate was drawn in is lost: draw it again with the new profile.')
    was = ob.hide_get()
    ob.hide_set(True)
    try:
        msg = perform_plate(context, loops, proj, preset)
    except cg.CutError:
        ob.hide_set(was)
        raise
    if kind == 'PLATE':
        fx._remove_part(ob)
    else:
        me = ob.data
        bpy.data.objects.remove(ob)
        if me is not None and me.users == 0:
            bpy.data.meshes.remove(me)
    return msg


def _spacing_update(self, context):
    ob = pending_plate(context)
    if ob is not None and plate_source(ob).get('spacing') != self.spacing:
        rebuild_plate(context, ob, self.spacing)


_QUIET = [False]


def _carve_update(self, context):
    """0.24.293 an Alt Carve setting / the profile changed: the live carve (if any) is carved again (from a timer)."""
    if _QUIET[0]:
        return
    try:
        from . import ramp_edit
        ramp_edit.refresh_later(context, 'platecarve')
    except Exception:          # a setting must never fail
        pass


class MCH_PG_Plate(bpy.types.PropertyGroup):
    preset: EnumProperty(name='Profile', items=[(p[0], p[1], p[2]) for p in PRESETS], default='CHAMFER',
                         update=_carve_update,
                         description='Plate profile (mouse wheel while drawing steps through them)')
    spacing: IntProperty(name='Face Size (px)', default=120, min=4, max=400, update=_spacing_update,
                         description='Size of the new faces on screen: bigger = fewer, cleaner faces '
                                     '(changes the selected plate live until Apply)')
    auto_size: BoolProperty(name='Auto Size', default=True,
                            description='Profile height / bevel / chamfer scale with the plate size')
    carve_depth: FloatProperty(name='Alt Carve Depth', default=0.0, min=0.0, soft_max=1.0, precision=4,
                               unit='LENGTH', update=_carve_update, description='Alt + draw carves the plate the other way: how deep '
                                                          '(0 = as deep as the plate is tall)')
    # 0.24.295 (user: "아머플레이트도 아까 프레스 컷처럼 대각선으로 잘리는 버튼") the recess's walls slant in toward its
    # middle (as Press Cut's Wall Angle); 0 = straight down (as before)
    carve_wall: FloatProperty(name='Alt Carve Wall Angle', default=0.0, min=0.0, max=math.radians(60.0),
                              subtype='ANGLE', update=_carve_update,
                              description='Alt + draw carve: the walls go in diagonally - the floor narrower than the '
                                          'opening by depth x tan(angle); 0 = straight walls')
    # 0.24.296 (user: "알트로 빼낼 때 바닥 쪽에 계단처럼 한 단 더 파이면서 들어가는 것도") stepped carve
    carve_steps: IntProperty(name='Alt Carve Steps', default=0, min=0, max=6, update=_carve_update,
                             description='Alt + draw carve: the floor stepped down this many times more - each step '
                                         'the outline moved in (Step Inset) and Step Depth deeper; 0 = one plain floor')
    step_inset: FloatProperty(name='Step Inset', default=0.0, min=0.0, soft_max=1.0, precision=4, unit='LENGTH',
                              update=_carve_update,
                              description='How far in from the edge above each step starts (0 = Auto: about a fifth '
                                          'of the shape)')
    step_depth: FloatProperty(name='Step Depth', default=0.0, min=0.0, soft_max=1.0, precision=4, unit='LENGTH',
                              update=_carve_update,
                              description='How much deeper each step goes (0 = Auto: half the carve depth)')
    # 0.24.291 (user: "옆에 세팅에 플렛 팔로우 레벨 버튼 만들면 되것네") the Alt carve's floor, as the Cut tool's
    carve_floor: EnumProperty(name='Alt Carve Floor', default='FOLLOW', update=_carve_update, items=[
        ('FOLLOW', 'Follow', 'As deep below the surface everywhere under the shape, however the part is turned'),
        ('LEVEL', 'Level', 'A flat floor at the depth below the point you press: everything higher under the shape '
                           'is cleared down to it'),
        ('FLAT', 'Flat', 'A flat floor across the view from the point you press (seen at an angle: one side deeper)')],
        description='Alt + draw carve: how the floor of the recess lies under the shape')
    creature: BoolProperty(name='Creature Shell', default=False,
                           description='Creature Shell brush: new plates get hard random facets, bulges, '
                                       'N/E/S/W edge lift and gravity')


class MCH_OT_plate_preset(bpy.types.Operator):
    """Plate profile for the next plate (and the selected plate)"""
    bl_idname = 'mch.plate_preset'
    bl_label = 'Plate Profile'
    bl_options = {'REGISTER', 'UNDO'}
    preset: EnumProperty(items=[(p[0], p[1], p[2]) for p in PRESETS], default='CHAMFER')

    @classmethod
    def description(cls, context, properties):
        return dict((p[0], p[2]) for p in PRESETS).get(properties.preset, '')

    def execute(self, context):
        from . import face_extract as fx
        context.scene.mch_plate.preset = self.preset
        ob = context.active_object
        live, kind = live_any(context)
        if live is not None and (kind == 'MRIDGE') != (self.preset == 'MRIDGE'):
            try:                                # 0.24.95 Mech Ridge <-> the others: the plate drawn again
                self.report({'INFO'}, swap_profile(context, live, kind, self.preset))
            except cg.CutError as ex:
                self.report({'WARNING'}, str(ex).splitlines()[0])
                return {'CANCELLED'}
            return {'FINISHED'}
        if self.preset == 'MRIDGE':
            return {'FINISHED'}                 # (a Mech Ridge plate already: nothing to change)
        if ob is not None and is_plate_or_part(ob) and ob.mch_extract.region is not None:
            reg = ob.mch_extract.region
            pts = [v.co for v in reg.vertices]
            lo = Vector([min(c[k] for c in pts) for k in range(3)])
            hi = Vector([max(c[k] for c in pts) for k in range(3)])
            p = ob.mch_extract
            p.is_part = False                     # one rebuild at the end
            for k, v in preset_values(self.preset, (hi - lo).length, context.scene.mch_plate.auto_size).items():
                try:
                    setattr(p, k, v)
                except (TypeError, AttributeError):
                    pass
            p.resolution = 0
            p.is_part = True
            fx.rebuild(ob)
        return {'FINISHED'}


class MCH_OT_plate_cycle(bpy.types.Operator):
    """Next / previous plate profile (the selected live plate changes at once)"""
    bl_idname = 'mch.plate_cycle'
    bl_label = 'Plate Profile Step'
    bl_options = {'REGISTER', 'UNDO'}
    step: IntProperty(default=1)

    def execute(self, context):
        st = context.scene.mch_plate
        i = PRESET_IDS.index(st.preset) if st.preset in PRESET_IDS else 0
        return bpy.ops.mch.plate_preset(preset=PRESET_IDS[(i + self.step) % len(PRESET_IDS)])


class MCH_OT_plate_lines(bpy.types.Operator):
    """Surface lines on the plate top: off > center line > cross > random (Reroll: new random lines)"""
    bl_idname = 'mch.plate_lines'
    bl_label = 'Plate Surface Lines'
    bl_options = {'REGISTER', 'UNDO'}
    reroll: BoolProperty(default=False, options={'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return ob is not None and is_plate_or_part(ob)

    def execute(self, context):
        p = context.active_object.mch_extract
        if self.reroll:
            if p.facet_style != 'RANDOM':
                p.facet_style = 'RANDOM'
            else:
                p.facet_seed += 1
        else:
            i = LINE_STYLES.index(p.facet_style) if p.facet_style in LINE_STYLES else 0
            p.facet_style = LINE_STYLES[(i + 1) % len(LINE_STYLES)]
        remember_plate(context.active_object)
        return {'FINISHED'}


class MCH_OT_plate_rim(bpy.types.Operator):
    """Raise (or lower) the border band on this side of the plate: N / E / S / W"""
    bl_idname = 'mch.plate_rim'
    bl_label = 'Plate Rim'
    bl_options = {'REGISTER', 'UNDO'}
    side: EnumProperty(items=[(k, k, '') for k in 'NESW'] + [('RANDOM', 'Random', ''), ('PROFILE', 'Profile', '')],
                       default='N')

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return ob is not None and is_plate_or_part(ob)

    def execute(self, context):
        p = context.active_object.mch_extract
        if self.side == 'RANDOM':
            if p.rim_random:
                p.rim_seed += 1                 # pressed again: new random pieces
            else:
                p.rim_random = True
        elif self.side == 'PROFILE':
            p.rim_profile = 'BEVEL' if p.rim_profile == 'CHAMFER' else 'CHAMFER'
        else:
            key = 'rim_' + self.side.lower()
            setattr(p, key, not getattr(p, key))
        remember_plate(context.active_object)
        return {'FINISHED'}


class MCH_OT_plate_apply(bpy.types.Operator):
    """Apply the plate: it becomes a plain mesh with the current shape (no more live changes)"""
    bl_idname = 'mch.plate_apply'
    bl_label = 'Apply Plate'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return live_any(context)[0] is not None

    def execute(self, context):
        live, kind = live_any(context)
        if kind == 'MRIDGE':                    # 0.24.95 (the HUD shows for Mech Ridge plates too)
            from . import mech_ridge
            mech_ridge.apply(live)
            self.report({'INFO'}, 'Applied 1 plate(s)')
            return {'FINISHED'}
        obs = [o for o in context.selected_objects if plate_source(o) is not None]
        ob = pending_plate(context)
        if ob is not None and ob not in obs:
            obs.append(ob)
        for o in obs:
            apply_plate(o)
        self.report({'INFO'}, f'Applied {len(obs)} plate(s)')
        return {'FINISHED'}


class MCH_OT_plate_cancel(bpy.types.Operator):
    """Remove the plate you just drew"""
    bl_idname = 'mch.plate_cancel'
    bl_label = 'Remove Plate'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return live_any(context)[0] is not None

    def execute(self, context):
        from . import face_extract as fx
        ob, kind = live_any(context)
        if kind == 'MRIDGE':                    # 0.24.95 (the HUD shows for Mech Ridge plates too)
            from . import mech_ridge
            target = bpy.data.objects.get((mech_ridge.source(ob) or {}).get('target', ''))
            me = ob.data
            bpy.data.objects.remove(ob)
            if me is not None and me.users == 0:
                bpy.data.meshes.remove(me)
        else:
            target = ob.mch_extract.source
            fx._remove_part(ob)
        if target is not None and target.name in context.view_layer.objects:
            target.select_set(True)
            context.view_layer.objects.active = target
        return {'FINISHED'}


# -----------------------------------------------------------------------------
# HUD next to a live plate: Apply / Remove / profile and live sliders
# -----------------------------------------------------------------------------

HUD_BUTTONS = (('apply', 'CHECKMARK', 'mch.plate_apply', {}, 'Apply'),
               ('cancel', 'X', 'mch.plate_cancel', {}, 'Remove'),
               ('prev', 'TRIA_LEFT', 'mch.plate_cycle', {'step': -1}, 'Previous profile'),
               ('next', 'TRIA_RIGHT', 'mch.plate_cycle', {'step': 1}, 'Next profile'),
               ('lines', 'IPO_LINEAR', 'mch.plate_lines', {'reroll': False}, 'Surface lines'),
               ('reroll', 'FILE_REFRESH', 'mch.plate_lines', {'reroll': True}, 'New random lines'),
               ('rim_n', 'EVENT_N', 'mch.plate_rim', {'side': 'N'}, 'Raise the north border'),
               ('rim_e', 'EVENT_E', 'mch.plate_rim', {'side': 'E'}, 'Raise the east border'),
               ('rim_s', 'EVENT_S', 'mch.plate_rim', {'side': 'S'}, 'Raise the south border'),
               ('rim_w', 'EVENT_W', 'mch.plate_rim', {'side': 'W'}, 'Raise the west border'),
               ('rim_rand', 'FILE_REFRESH', 'mch.plate_rim', {'side': 'RANDOM'}, 'Random border pieces (again: new)'),
               ('rim_prof', 'MOD_BEVEL', 'mch.plate_rim', {'side': 'PROFILE'}, 'Rim edge: chamfer / bevel'))
# key, label, part property (None = Face Size), lo, hi  (lengths: 1/1000 of the plate size)
SLIDERS = (('height', 'Height', 'extract_height', 1, 300), ('chamfer', 'Chamfer', 'chamfer_width', 0, 200),
           ('bevel', 'Bevel', 'bevel_width', 0, 200), ('crease', 'Crease', 'facet_depth', -200, 200),
           ('line_width', 'Line Width', 'facet_width', 0, 80), ('line_move', 'Line Move', 'facet_offset', -100, 100),
           ('line_turn', 'Line Turn', 'facet_rotation', -180, 180),
           ('rim_height', 'Rim Height', 'rim_height', -200, 200), ('rim_width', 'Rim Width', 'rim_width', 1, 60),
           ('rim_slope', 'Rim Slope', 'rim_slope', 2, 200), ('rim_turn', 'Rim Turn', 'dir_rotation', -180, 180),
           ('spacing', 'Face Size', None, 20, 400))
PCT_PROPS = {'facet_depth', 'facet_width', 'facet_offset', 'rim_height', 'rim_width', 'rim_slope'}
LINE_STYLES = ('NONE', 'CENTER', 'CROSS', 'RANDOM')
LINE_NAMES = {'NONE': 'Lines: off', 'CENTER': 'Lines: center', 'CROSS': 'Lines: cross', 'RANDOM': 'Lines: random'}


REMEMBER_REL = ('extract_height', 'chamfer_width', 'bevel_width')
REMEMBER_RAW = ('chamfer_angle', 'facet_style', 'facet_depth', 'facet_width', 'facet_offset', 'facet_rotation',
                'facet_count', 'facet_seed', 'rim_n', 'rim_e', 'rim_s', 'rim_w', 'rim_random', 'rim_seed', 'rim_count',
                'rim_profile', 'rim_slope', 'rim_width', 'rim_height', 'dir_rotation')


def remember_plate(ob):
    """0.20.2: keep this plate's profile / lines / rims for the next plate (lengths relative to its size)."""
    from . import last_used
    src = plate_source(ob)
    if src is None:
        return
    size = max(1e-6, float(src.get('size', 1.0)))
    p = ob.mch_extract
    for k in REMEMBER_REL:
        last_used.remember('plate', k, getattr(p, k))      # the same numbers next time
    for k in REMEMBER_RAW:
        v = getattr(p, k)
        last_used.remember('plate', k, v if isinstance(v, (bool, int, float, str)) else float(v))
    last_used.remember('plate', '_preset', context_preset(ob))


def context_preset(ob):
    try:
        return bpy.context.scene.mch_plate.preset
    except AttributeError:
        return ''


def recall_plate(part, local_size, preset):
    """Apply the remembered settings to a new plate (only when the profile is the same as last time)."""
    from . import last_used
    from . import face_extract as fx
    last = last_used.recall('plate')
    if not last or last.get('_preset') != preset:
        return False
    p = part.mch_extract
    p.is_part = False
    for k, v in last.items():
        if k.startswith('_'):
            continue
        try:
            setattr(p, k, v)
        except (TypeError, AttributeError, ValueError):
            pass
    p.is_part = True
    fx.rebuild(part)
    return True


def slider_spec(context, key, ob=None):
    """(label, value, lo, hi, setter, text) of a HUD slider for the live plate."""
    ob = ob or pending_plate(context)
    label, prop, lo, hi = next((l, pr, a, b) for k, l, pr, a, b in SLIDERS if k == key)
    if prop is None:
        st = context.scene.mch_plate
        v = int(plate_source(ob).get('spacing', st.spacing))

        def setter(val):
            if st.spacing != val:
                st.spacing = val                        # rebuilds through the update
            elif plate_source(ob).get('spacing') != val:
                rebuild_plate(context, ob, val)
        return label, v, lo, hi, setter, f'{label}  {v} px'
    p = ob.mch_extract
    if prop in PCT_PROPS:                           # surface lines: percent
        v = int(round(getattr(p, prop) * 100.0))
        return label, v, lo, hi, (lambda val: setattr(p, prop, val / 100.0)), f'{label}  {v} %'
    if prop in {'facet_rotation', 'dir_rotation'}:
        import math as _m
        v = int(round(_m.degrees(getattr(p, prop))))
        return label, v, lo, hi, (lambda val: setattr(p, prop, _m.radians(val))), f'{label}  {v} deg'
    size = max(1e-6, float(plate_source(ob).get('size', 1.0)))
    v = int(round(getattr(p, prop) / size * 1000.0))

    def setter(val):
        setattr(p, prop, max(0.0001 if prop == 'extract_height' else 0.0, val / 1000.0 * size))
    return label, v, lo, hi, setter, f'{label}  {getattr(p, prop):.3f}'


def hud_layout(screen_pts, region_w, region_h, btn=30.0, gap=6.0, slider_w=104.0, slider_h=20.0):
    pts = [p for p in screen_pts if p is not None]
    if not pts:
        return {}
    x = min(max(max(p[0] for p in pts) + btn * 1.2, btn), region_w - slider_w - btn)
    step = btn + gap
    total = step * 5 + (slider_h + gap) * len(SLIDERS)
    top = min(max((max(p[1] for p in pts) + min(p[1] for p in pts)) / 2 + total / 2, total), region_h - btn)
    out = {'apply': (x, top), 'cancel': (x, top - step),
           'prev': (x, top - 2 * step), 'next': (x + step, top - 2 * step),
           'lines': (x, top - 3 * step), 'reroll': (x + step, top - 3 * step)}
    for i, k in enumerate(('rim_n', 'rim_e', 'rim_s', 'rim_w', 'rim_rand', 'rim_prof')):
        out[k] = (x + i * step, top - 4 * step)
    y = top - 5 * step
    for key, *_ in SLIDERS:
        out['slider_' + key] = (x - btn / 2 + slider_w / 2, y + btn / 2 - slider_h / 2)
        y -= slider_h + gap
    return out


def _hud_current(context):
    try:
        from . import tool_state as ts
        if context.mode != 'OBJECT' or not ts.is_mecha_workspace(getattr(context, 'workspace', None)):
            return None, {}
    except (AttributeError, TypeError):
        return None, {}
    from .primitive_hud import anchored, release_anchor
    ob, kind = live_any(context)
    region, rv3d = context.region, context.region_data
    if ob is None or region is None or rv3d is None:
        if ob is None:
            release_anchor('plate')
        return None, {}
    from bpy_extras import view3d_utils
    ui = context.preferences.system.ui_scale
    pts = []
    for c in ob.bound_box:
        q = view3d_utils.location_3d_to_region_2d(region, rv3d, ob.matrix_world @ Vector(c))
        pts.append(None if q is None else (q[0] / ui, q[1] / ui))
    lay = hud_layout(pts, region.width / ui, region.height / ui)
    if kind == 'MRIDGE':                        # 0.24.95 its own settings are in the panel: Apply / Remove / profile
        lay = {k: v for k, v in lay.items() if k in MRIDGE_HUD}
    return ob, anchored('plate', ob.name, region, lay)


MRIDGE_HUD = ('apply', 'cancel', 'prev', 'next')


class MCH_GT_plate_slider(bpy.types.Gizmo):
    bl_idname = 'MCH_GT_plate_slider'
    __slots__ = ('shape', 'init_x', 'init_value', 'key')

    def setup(self):
        if not hasattr(self, 'shape'):
            from .primitive_hud import _RECT
            self.shape = self.new_custom_shape('TRIS', _RECT)

    def draw(self, context):
        self.draw_custom_shape(self.shape)

    def test_select(self, context, location):          # 0.24.129 (Blender 5.2: no draw_select in a 2D gizmo group)
        from .primitive_hud import rect_hit
        return rect_hit(self, location)

    def invoke(self, context, event):
        self.init_x = event.mouse_region_x
        self.init_value = slider_spec(context, self.key)[1]
        return {'RUNNING_MODAL'}

    def modal(self, context, event, tweak):
        from .primitive_hud import slider_value
        spec = slider_spec(context, self.key)
        step = 3.0 if self.key == 'spacing' else 4.0
        v = slider_value(self.init_value, event.mouse_region_x - self.init_x, step_px=step, lo=spec[2], hi=spec[3])
        if v != spec[1]:
            spec[4](v)
        if context.area:
            context.area.header_text_set(slider_spec(context, self.key)[5])
        return {'RUNNING_MODAL'}

    def exit(self, context, cancel):
        if context.area:
            context.area.header_text_set(None)
        if cancel:
            slider_spec(context, self.key)[4](self.init_value)
        else:
            ob = pending_plate(context)
            if ob is not None:
                remember_plate(ob)
            from . import undo_keep
            undo_keep.push('Plate ' + self.key)


class MCH_GGT_plate_hud(bpy.types.GizmoGroup):
    bl_idname = 'MCH_GGT_plate_hud'
    bl_label = 'Armor Plate HUD'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_options = {'PERSISTENT', 'SCALE'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and ts.hud_for(context, {'PLATE'}) and live_any(context)[0] is not None

    def setup(self, context):
        self.items = {}
        for name, icon, op, props, _label in HUD_BUTTONS:
            gz = self.gizmos.new('GIZMO_GT_button_2d')
            gz.icon = icon
            gz.draw_options = {'BACKDROP', 'OUTLINE'}
            t = gz.target_set_operator(op)
            for k, v in props.items():
                setattr(t, k, v)
            gz.color = (1.0, 0.62, 0.16) if name == 'apply' else (0.17, 0.19, 0.23)
            gz.alpha = 0.92
            gz.color_highlight = (0.32, 0.35, 0.41)
            gz.alpha_highlight = 1.0
            self.items[name] = gz
        for key, *_ in SLIDERS:
            gz = self.gizmos.new(MCH_GT_plate_slider.bl_idname)
            gz.key = key
            gz.color = (0.24, 0.27, 0.32)
            gz.alpha = 0.95
            gz.color_highlight = (0.36, 0.40, 0.47)
            gz.alpha_highlight = 1.0
            gz.use_draw_scale = False
            self.items['slider_' + key] = gz

    def draw_prepare(self, context):
        _ob, lay = _hud_current(context)
        ui = context.preferences.system.ui_scale
        for name, gz in self.items.items():
            pos = lay.get(name)
            gz.hide = pos is None
            if pos is None:
                continue
            if name.startswith('slider_'):
                gz.matrix_basis = Matrix.Translation((pos[0] * ui, pos[1] * ui, 0.0)) @ Matrix.Diagonal(
                    (52.0 * ui, 10.0 * ui, 1.0, 1.0))
                continue
            gz.scale_basis = 15.0
            gz.matrix_basis[0][3] = pos[0] * ui
            gz.matrix_basis[1][3] = pos[1] * ui
            if name in {'rim_n', 'rim_e', 'rim_s', 'rim_w'} and _ob is not None:
                gz.color = (1.0, 0.62, 0.16) if getattr(_ob.mch_extract, name) else (0.17, 0.19, 0.23)
            elif name == 'rim_rand' and _ob is not None:
                gz.color = (1.0, 0.62, 0.16) if _ob.mch_extract.rim_random else (0.17, 0.19, 0.23)


_label_handle = None


def _draw_labels():
    try:
        context = bpy.context
        from .tool_state import hud_labels_ok
        if not hud_labels_ok(context, {'PLATE'}):          # 0.24.146 only with the HUD's buttons
            return
        ob, lay = _hud_current(context)
        if ob is None or not lay:
            return
        import blf
        ui = context.preferences.system.ui_scale
        blf.size(0, 11 * ui)
        name = dict((p[0], p[1]) for p in PRESETS).get(context.scene.mch_plate.preset, '')
        lines = LINE_NAMES.get(ob.mch_extract.facet_style, '')
        for key, text in (('apply', 'Apply'), ('cancel', 'Remove'), ('next', name), ('reroll', lines),
                          ('rim_prof', 'Rims: ' + ob.mch_extract.rim_profile.title())):
            x, y = lay[key]
            blf.color(0, *((1.0, 0.62, 0.16) if key == 'apply' else (0.85, 0.87, 0.9)), 1.0)
            blf.position(0, (x + 21) * ui, (y - 4) * ui, 0)
            blf.draw(0, _tr(text))
        for key, *_ in SLIDERS:
            x, y = lay['slider_' + key]
            text = slider_spec(context, key, ob)[5]
            w, _h = blf.dimensions(0, _tr(text))
            blf.color(0, 1.0, 1.0, 1.0, 1.0)
            blf.position(0, x * ui - w / 2, (y - 4) * ui, 0)
            blf.draw(0, _tr(text))
    except Exception:          # never break viewport drawing
        pass



def _draw_edge_molding(layout, p, title='Edge Molding'):
    """0.24.298 Top / Bottom Edge Molding of a plate (the live one's, or the next plates')."""
    if not hasattr(p, 'emold_top'):
        return
    col = layout.column(align=True)
    col.label(text=title, icon='MOD_SOLIDIFY')
    row = col.row(align=True)
    row.prop(p, 'emold_top', text='Top', toggle=True)
    row.prop(p, 'emold_bottom', text='Bottom', toggle=True)
    col.prop(p, 'emold_dome')                         # 0.24.299 (on its own too)
    if p.emold_top or p.emold_bottom:
        col.prop(p, 'emold_out', text='Out')
        col.prop(p, 'emold_band', text='Height (0: Auto)')
        if p.emold_top:
            col.prop(p, 'emold_lip')
        col.row(align=True).prop(p, 'emold_shape', expand=True)

def draw(layout, context):
    from . import face_extract as fx
    st = context.scene.mch_plate
    box = layout.box()
    box.label(text='ARMOR PLATE: draw on a mesh', icon='MOD_SOLIDIFY')
    grid = box.grid_flow(row_major=True, columns=2, even_columns=True, align=True)
    for pid, label, _d, _v in PRESETS:
        grid.operator('mch.plate_preset', text=label, depress=(st.preset == pid)).preset = pid
    from . import mech_ridge
    if st.preset == 'MRIDGE' or mech_ridge.live_plate(context) is not None:
        mech_ridge.draw(box, context)
    row = box.row(align=True)
    row.prop(st, 'spacing')
    row.prop(st, 'auto_size', toggle=True)
    box.prop(st, 'carve_depth')                       # 0.24.42 Alt + draw: the recess depth
    box.row(align=True).prop(st, 'carve_floor', expand=True)     # 0.24.291 the recess floor
    box.prop(st, 'carve_wall')                        # 0.24.295 slanted walls
    if hasattr(context.scene, 'mch_moldcut') and ts.mold_on(context):   # 0.24.304 Mold Cut (0.24.305 Mold tool)
        from . import mold_cut
        mold_cut.draw(box.box(), context.scene.mch_moldcut)
    col_ = box.column(align=True)                     # 0.24.296 stepped floor
    col_.prop(st, 'carve_steps')
    if st.carve_steps > 0:
        col_.prop(st, 'step_inset', text='Step Inset (0: Auto)')
        col_.prop(st, 'step_depth', text='Step Depth (0: Auto)')
    ob = pending_plate(context)
    if ob is None and hasattr(context.scene, 'mch_extract') and ts.mold_on(context):
        _draw_edge_molding(box.box(), context.scene.mch_extract, 'Edge Molding (next plates)')
    if ob is not None:
        p = ob.mch_extract
        sub = box.box()
        sub.label(text=f'LIVE: {ob.name} (until Apply)', icon='MOD_SOLIDIFY')
        col = sub.column(align=True)
        for prop in ('extract_height', 'chamfer_width', 'chamfer_angle', 'bevel_width'):
            col.prop(p, prop)
        rr = sub.row(align=True)
        rr.label(text='Rims')
        for k in 'nesw':
            rr.prop(p, f'rim_{k}', toggle=True)
        rr.prop(p, 'rim_random', toggle=True, text='Random')
        if p.rim_n or p.rim_e or p.rim_s or p.rim_w or p.rim_random:
            rc = sub.column(align=True)
            rc.prop(p, 'rim_height', slider=True)
            rc.prop(p, 'rim_width', slider=True)
            rc.row(align=True).prop(p, 'rim_profile', expand=True)
            rc.prop(p, 'rim_slope', slider=True)
            if p.rim_random:
                r2 = rc.row(align=True)
                r2.prop(p, 'rim_count')
                r2.prop(p, 'rim_seed')
            rc.prop(p, 'dir_rotation', text='Rim Turn')
        ln = sub.column(align=True)
        ln.prop(p, 'facet_style')
        if p.facet_style != 'NONE':
            ln.prop(p, 'facet_depth', slider=True)
            ln.prop(p, 'facet_width', slider=True)
            ln.prop(p, 'facet_offset', slider=True)
            ln.prop(p, 'facet_rotation')
            if p.facet_style == 'RANDOM':
                r = ln.row(align=True)
                r.prop(p, 'facet_count')
                r.prop(p, 'facet_seed')
        if ts.mold_on(context):
            _draw_edge_molding(sub, p)                # 0.24.298 (0.24.305 Mold Armor Plate)
        r = sub.row(align=True)
        r.scale_y = 1.3
        r.operator('mch.plate_apply', text='Apply', icon='CHECKMARK')
        r.operator('mch.plate_cancel', text='Remove', icon='X')
    col = box.column(align=True)
    col.scale_y = 0.8
    col.label(text='Click points / drag freehand, Enter or double-click: plate', icon='INFO')
    col.label(text='Mouse wheel while drawing: change the profile')
    col.label(text='Until Apply: face size / height / chamfer change live')
    col.label(text='The mesh you draw on is not changed (Alt + draw: carved in)')
    from . import random_panels
    random_panels.draw(layout, context)
    fx.draw(layout, context)


CLASSES = (MCH_PG_Plate, MCH_OT_plate_preset, MCH_OT_plate_cycle, MCH_OT_plate_lines, MCH_OT_plate_rim, MCH_OT_plate_apply, MCH_OT_plate_cancel,
           MCH_GT_plate_slider, MCH_GGT_plate_hud)


def register():
    global _label_handle
    for c in CLASSES:
        bpy.utils.register_class(c)
    bpy.types.Scene.mch_plate = bpy.props.PointerProperty(type=MCH_PG_Plate)
    if not bpy.app.background and _label_handle is None:
        _label_handle = bpy.types.SpaceView3D.draw_handler_add(_draw_labels, (), 'WINDOW', 'POST_PIXEL')


def unregister():
    _BVH_CACHE.clear()
    global _label_handle
    if _label_handle is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(_label_handle, 'WINDOW')
        except (ValueError, RuntimeError):
            pass
        _label_handle = None
    if hasattr(bpy.types.Scene, 'mch_plate'):
        del bpy.types.Scene.mch_plate
    for c in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(c)
        except RuntimeError:
            pass
