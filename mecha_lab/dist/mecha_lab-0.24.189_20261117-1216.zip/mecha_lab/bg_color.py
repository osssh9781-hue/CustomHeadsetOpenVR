"""0.24.137 Background Colour (user: "HDRI 는 다른 애드온 쓸 거라 배경만 내가 원하는 색으로 바꿀 수 있게 해 주라, 너가
만든 게 너무 무거워").

The camera sees one colour; the scene's world - an HDRI from any add-on, or anything else - still lights the parts and
shows in their reflections.  Three small nodes go into the scene's world: Light Path (Is Camera Ray) mixes the world's
own shader with a Background of the colour.  Renders, Quick Render and the Rendered viewport all use the world, so they
all show it.  Solid view too (an option): the 3D views' own background set to the same colour (their old setting kept
and put back).

Off: the three nodes removed and the world's own shader linked to its output again - nothing else in the world is
touched.  Another add-on rebuilding its world drops the nodes: Background Colour then reads Off (press it again).

0.24.138 (user: "백그라운드 이미지가 안 보여", "뒤에 넣는 스튜디오 이미지들 다 어디 갔어?") Picture: a studio backdrop
(the add-on's 68) or one of the user's pictures behind the model instead of the colour - the frame's window
coordinates, Fill / Fit (the colour round a fitted picture), Brightness / Contrast; on any world, like the colour.
Material Preview Too: Material Preview shows the scene's world (Blender's own studio light otherwise hides it).

0.24.148 (user: "컴포지터 방식으로 ㄱㄱ, 그 버튼 누르면 뷰포트나 이런 건 다 너가 알아서 세팅") Compositor: the colour /
picture put behind the render in the compositor instead of in the world - the world is not touched at all.  Pressed:
Film Transparent on, a few nodes just before the compositor's output (a small compositor of ours when the scene has
none; with your own, what went to its output goes on top of the background), every 3D view's viewport compositor Always (Material Preview and Rendered
show it).  Everything changed is remembered and put back by Off / World.  The picture is never blurred by depth of
field or touched by the denoiser.

0.24.149 (user: "백그라운드 이미지를 포토샵처럼 내가 그릴 수 없어?") Paint Background: a canvas the frame's shape (it
starts as what is behind the model now - the picture, or the colour) becomes the background picture, and a window opens
with Blender's Image Editor in Paint mode on it - brushes, colours, soften / smear / clone / fill, gradients.  The
background follows the painting (the compositor reads the canvas).  The canvas is kept in the .blend (packed each time
the file is saved); New Canvas starts again from the colour / picture.
"""
from __future__ import annotations

import json
import os

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, FloatVectorProperty, StringProperty

N_PATH, N_BG, N_MIX = 'MCH BG Path', 'MCH BG Colour', 'MCH BG Mix'
N_COORD, N_MAP, N_PIC, N_BC, N_ALPHA = 'MCH BG Coord', 'MCH BG Map', 'MCH BG Picture', 'MCH BG Bright', 'MCH BG Alpha'
N_BW, N_RAMP, N_RMIX = 'MCH BG Ramp Value', 'MCH BG Ramp', 'MCH BG Ramp Mix'      # 0.24.140 the Colour Ramp back
PIC_NODES = (N_COORD, N_MAP, N_PIC, N_BC, N_ALPHA, N_BW, N_RAMP, N_RMIX)
NODES = (N_PATH, N_BG, N_MIX) + PIC_NODES
STOPS = 'mch_bg_ramp_stops'        # on the settings: the ramp's colours, kept while the picture nodes are out
DARK, LIGHT = (0.02, 0.022, 0.028, 1.0), (0.92, 0.92, 0.92, 1.0)
VIEW_KEY = 'mch_bg_view'
MAT_KEY = 'mch_bg_matview'
OWN = 'mch_bg_own'                 # on a picture this loaded (let go when another is picked and nothing uses it)
DEFAULT_PICTURE = 'B:white_sweep_land.jpg'
CANVAS_TAG = 'mch_bg_canvas'       # on the painted background (the scene's name): never let go, packed on save
CANVAS_PREFIX = 'P:'               # the setting's picture = 'P:' + the canvas image's name
CANVAS_NAME = 'MCH Background Paint'
COMP_TAG = 'mch_bg_comp'            # on our compositor group (the scene's name)
COMP_KEY = 'mch_bg_comp_keep'      # on the scene: what Compositor changed (put back by Off)
VIEWCOMP_KEY = 'mch_bg_viewcomp'   # on a screen: its 3D views' viewport compositor before
C_RL, C_USER, C_FULL, C_SCALE = 'MCH BG Render', 'MCH BG Your Compositor', 'MCH BG Full Colour', 'MCH BG Fit'
C_SEP, C_CLAMP, C_SETA, C_AO1, C_AO2 = 'MCH BG Picture Alpha', 'MCH BG Clamp', 'MCH BG Set Alpha', 'MCH BG Picture Over', \
    'MCH BG Model Over'


def _upd_color(self, context):
    set_color(context.scene)


def _upd_solid(self, context):
    update_views(context.scene)


def _upd_mat(self, context):
    update_material_views(context.scene)


# ---- 0.24.142 (user: "n 패널 상단에 배경 이미지랑 배경 컬러 설정하는 거 넣어 줘") the picture list for the sidebar ------

_ITEMS = []                        # (kept alive: Blender reads the strings of a dynamic enum later)
_PREV = {'coll': None}


def _pick_items(self, context):
    from . import backdrops
    _ITEMS[:] = [(ident, label, '', i) for i, (ident, label) in enumerate(backdrops.entries())] or \
        [('NONE', 'No pictures', '', 0)]
    return _ITEMS


def _pick_get(self):
    from . import backdrops
    scene = self.id_data
    cur = picture_ident(scene)
    for i, (ident, _label) in enumerate(backdrops.entries()):
        if ident == cur:
            return i
    return 0


def _pick_set(self, value):
    from . import backdrops
    ents = backdrops.entries()
    if not 0 <= value < len(ents):
        return
    show_picture(self.id_data, ents[value][0])


def show_picture(scene, ident):
    """Picture ``ident`` behind the model (the background on if it was off)."""
    st = settings(scene)
    st.image = ident
    st.mode = 'IMAGE'
    if on(scene):
        set_color(scene)
    else:
        apply(scene)


def preview_icon(path):
    """An icon of picture ``path`` for the sidebar (only the pictures shown are loaded), or 0."""
    if not path or not os.path.isfile(path):
        return 0
    try:
        from bpy.utils import previews as _previews
        if _PREV['coll'] is None:
            _PREV['coll'] = _previews.new()
        coll = _PREV['coll']
        if path not in coll:
            coll.load(path, path, 'IMAGE')
        return coll[path].icon_id
    except (KeyError, RuntimeError, AttributeError):
        return 0


class MCH_PG_Background(bpy.types.PropertyGroup):
    color: FloatVectorProperty(name='Background', subtype='COLOR', size=3, min=0.0, max=1.0,
                               default=(0.18, 0.18, 0.18), update=_upd_color,
                               description='The colour the camera sees behind the parts (the world still lights them)')
    solid_too: BoolProperty(name='Solid View Too', default=False, update=_upd_solid,
                            description='The 3D views\' own background (Solid / Material Preview) in the same colour')
    # 0.24.138 a picture behind the model (the studio backdrops come back)
    mode: EnumProperty(name='Behind the Model', items=[('COLOR', 'Colour', 'One colour'),
                                                       ('IMAGE', 'Picture', 'A studio backdrop or one of your pictures')],
                       default='COLOR', update=_upd_color)
    image: StringProperty(name='Picture', default='', update=_upd_color,
                          description='The picture behind the model (a studio backdrop or one of yours)')
    fit: EnumProperty(name='Fit', items=[('FILL', 'Fill', 'The frame covered (the picture\'s edges cut off)'),
                                         ('FIT', 'Fit', 'The whole picture (the colour round it)')],
                      default='FILL', update=_upd_color)
    bright: FloatProperty(name='Brightness', default=0.0, soft_min=-1.0, soft_max=1.0, update=_upd_color,
                          description='The picture lighter / darker')
    contrast: FloatProperty(name='Contrast', default=0.0, soft_min=-1.0, soft_max=1.0, update=_upd_color,
                            description='The picture\'s contrast (-1 flat, 0 as it is, 1 twice as much)')
    ramp: BoolProperty(name='Colour Ramp', default=False, update=_upd_color,
                       description='The picture\'s dark and light parts take the ramp\'s colours (Dark / Light, Edit '
                       'Ramp… for more stops)')
    image_pick: EnumProperty(name='Picture', items=_pick_items, get=_pick_get, set=_pick_set,
                             description='The picture behind the model: the studio backdrops, then your folder')
    method: EnumProperty(name='Method', default='COMP', items=[
        ('COMP', 'Compositor', 'The colour / picture put behind the render in the compositor (Film Transparent, the '
                               'viewport compositor on - all set for you); the world untouched'),
        ('WORLD', 'World', 'The colour / picture in the world for the camera rays (nothing else changed)')],
        description='How the background is put behind the model')
    material_too: BoolProperty(name='Material Preview Too', default=True, update=_upd_mat,
                               description='Material Preview shows the scene\'s world (your HDRI and the background) '
                               'instead of Blender\'s own studio light')


def settings(scene):
    return getattr(scene, 'mch_bg', None)


def picture_ident(scene):
    """The picture in use: the setting, else the one the old HDRI page had (0.24.95 - 0.24.136), else the white
    studio sweep."""
    st = settings(scene)
    if st is not None and st.image:
        return st.image
    old = getattr(scene, 'mch_mech_hdri_bg_image', '')
    return old or DEFAULT_PICTURE


def picture_path(scene):
    from . import backdrops
    ident = picture_ident(scene)
    if ident.startswith(CANVAS_PREFIX):              # (0.24.149 the painted canvas: no file)
        return ''
    p = backdrops.path(ident)
    return p if p and os.path.isfile(p) else ''


def canvas_image(scene):
    """0.24.149 the painted background the setting points at (an image in the file), or None."""
    ident = picture_ident(scene)
    if not ident.startswith(CANVAS_PREFIX):
        return None
    img = bpy.data.images.get(ident[len(CANVAS_PREFIX):])
    return img if img is not None and img.get(CANVAS_TAG) else None


def _wanted(scene):
    """(image, path) to show in Picture mode: the painted canvas, else a picture file; (None, '') = the colour."""
    st = settings(scene)
    if st is None or st.mode != 'IMAGE':
        return None, ''
    cv = canvas_image(scene)
    if cv is not None:
        return cv, ''
    return None, picture_path(scene)


def has_picture(scene):
    return _wanted(scene) != (None, '')


def _put_picture(node, scene):
    """The picture to show into image node ``node`` (a file loaded once, the one before let go); it, or None."""
    cv, path = _wanted(scene)
    old = node.image
    if cv is not None:
        if old is not cv:
            node.image = cv
            _let_go(old)
        return cv
    if not path:
        node.image = None
        _let_go(old)
        return None
    if old is None or old.get(CANVAS_TAG) or \
            os.path.normcase(bpy.path.abspath(old.filepath)) != os.path.normcase(path):
        known = {i.name for i in bpy.data.images}
        img = bpy.data.images.load(path, check_existing=True)
        if img.name not in known:
            img[OWN] = True
        node.image = img
        _let_go(old)
    return node.image


def _output(nt):
    outs = [n for n in nt.nodes if n.bl_idname == 'ShaderNodeOutputWorld']
    return next((n for n in outs if getattr(n, 'is_active_output', False)), outs[0] if outs else None)


def on(scene):
    """Is the background on (in the world, or 0.24.148 in the compositor)?"""
    return world_on(scene) or comp_on(scene)


def world_on(scene):
    """Is the colour in the scene's world (our Mix linked to the world's output)?"""
    w = getattr(scene, 'world', None)
    nt = getattr(w, 'node_tree', None)
    if nt is None:
        return False
    mix, out = nt.nodes.get(N_MIX), _output(nt)
    if mix is None or out is None:
        return False
    return any(l.from_node == mix for l in out.inputs['Surface'].links)


def _world(scene):
    w = scene.world
    if w is None:
        w = bpy.data.worlds.new('World')
        scene.world = w
    try:
        if not w.use_nodes:
            w.use_nodes = True
    except AttributeError:
        pass
    return w


def apply(scene):
    """The background on, the settings' way (0.24.148: Compositor, or World)."""
    st = settings(scene)
    if on(scene):
        set_color(scene)
        return 'Background Colour is on'
    if st is not None and st.method == 'COMP':
        return comp_apply(scene)
    return world_apply(scene)


def world_apply(scene):
    """The colour into the scene's world (an existing world kept as it is - its shader goes through our Mix)."""
    if world_on(scene):
        set_color(scene)
        return 'Background Colour is on'
    migrate(scene)
    w = _world(scene)
    nt = w.node_tree
    out = _output(nt)
    if out is None:
        out = nt.nodes.new('ShaderNodeOutputWorld')
        out.location = (300, 0)
    surf = out.inputs['Surface']
    src = surf.links[0].from_socket if surf.links else None
    for name in NODES:                                 # (leftovers of an earlier time: rebuilt)
        n = nt.nodes.get(name)
        if n is not None:
            nt.nodes.remove(n)
    path = nt.nodes.new('ShaderNodeLightPath')
    path.name = path.label = N_PATH
    bg = nt.nodes.new('ShaderNodeBackground')
    bg.name = bg.label = N_BG
    mix = nt.nodes.new('ShaderNodeMixShader')
    mix.name = mix.label = N_MIX
    x, y = out.location
    path.location, bg.location, mix.location = (x - 420, y + 260), (x - 420, y - 160), (x - 180, y)
    lk = nt.links
    lk.new(path.outputs['Is Camera Ray'], mix.inputs['Fac'])
    if src is not None:
        lk.new(src, mix.inputs[1])
    lk.new(bg.outputs['Background'], mix.inputs[2])
    lk.new(mix.outputs['Shader'], surf)
    set_color(scene)
    update_views(scene)
    update_material_views(scene)
    st = settings(scene)
    if st is not None and st.mode == 'IMAGE':
        return 'Background Picture on: the camera sees the picture, the world still lights the parts'
    return 'Background Colour on: the camera sees the colour, the world still lights the parts'


def remove(scene):
    """The background off, whichever way it is on."""
    msg = 'Background off'
    if comp_on(scene) or COMP_KEY in scene.keys():
        msg = comp_remove(scene)
    if world_on(scene):
        msg = world_remove(scene)
    update_views(scene, force_off=True)
    update_material_views(scene, force_off=True)
    return msg


def world_remove(scene):
    """The three nodes out, the world's own shader back on its output."""
    w = getattr(scene, 'world', None)
    nt = getattr(w, 'node_tree', None)
    if nt is not None:
        mix, out = nt.nodes.get(N_MIX), _output(nt)
        src = mix.inputs[1].links[0].from_socket if mix is not None and mix.inputs[1].links else None
        linked = out is not None and any(l.from_node == mix for l in out.inputs['Surface'].links)
        pic = nt.nodes.get(N_PIC)
        img = pic.image if pic is not None else None
        _save_stops(scene, nt)
        for name in NODES:
            n = nt.nodes.get(name)
            if n is not None:
                nt.nodes.remove(n)
        _let_go(img)
        if src is not None and out is not None and linked and not out.inputs['Surface'].links:
            nt.links.new(src, out.inputs['Surface'])
    update_views(scene, force_off=True)
    update_material_views(scene, force_off=True)
    return 'Background off: the world as it was'


def set_color(scene):
    if comp_on(scene):
        comp_sync(scene)
    st = settings(scene)
    w = getattr(scene, 'world', None)
    nt = getattr(w, 'node_tree', None)
    if st is None or nt is None:
        return
    bg = nt.nodes.get(N_BG)
    if bg is not None:
        bg.inputs['Color'].default_value = (*st.color, 1.0)
        bg.inputs['Strength'].default_value = 1.0
        _picture_sync(scene, nt, bg)
    update_views(scene)


# ---- the picture behind the model ---------------------------------------------------------------------------------

def _let_go(img):
    try:
        if img is not None and img.get(OWN) and img.users == 0:
            bpy.data.images.remove(img)
    except (ReferenceError, RuntimeError):
        pass


def _mix_in(node, ident):
    return next(s for s in node.inputs if s.identifier == ident)


def _picture_nodes(nt, bg):
    """Window coordinates -> fitted -> the picture -> brightness / contrast -> the colour where it has no pixels."""
    nd, lk = nt.nodes, nt.links
    x, y = bg.location
    coord = nd.new('ShaderNodeTexCoord')
    mp = nd.new('ShaderNodeMapping')
    mp.vector_type = 'POINT'
    pic = nd.new('ShaderNodeTexImage')
    pic.extension = 'CLIP'
    pic.interpolation = 'Linear'
    bc = nd.new('ShaderNodeBrightContrast')
    al = nd.new('ShaderNodeMix')
    al.data_type = 'RGBA'
    for n, name, dx in ((coord, N_COORD, -1100), (mp, N_MAP, -900), (pic, N_PIC, -700), (bc, N_BC, -440),
                        (al, N_ALPHA, -240)):
        n.name = n.label = name
        n.location = (x + dx, y - 360)
    lk.new(coord.outputs['Window'], mp.inputs['Vector'])
    lk.new(mp.outputs['Vector'], pic.inputs['Vector'])
    lk.new(pic.outputs['Color'], bc.inputs['Color'])
    lk.new(pic.outputs['Alpha'], _mix_in(al, 'Factor_Float'))
    # (0.24.95 / 0.24.140 user: "사진에 컬러램프 기능 - 대비랑 색 같은 거 내가 조절", "왜 컬러램프 조정하는 거 뺐어?")
    bw = nd.new('ShaderNodeRGBToBW')
    ramp = nd.new('ShaderNodeValToRGB')
    rmix = nd.new('ShaderNodeMix')
    rmix.data_type = 'RGBA'
    for n, name, dx in ((bw, N_BW, -440), (ramp, N_RAMP, -300), (rmix, N_RMIX, -60)):
        n.name = n.label = name
        n.location = (x + dx, y - 640)
    els = ramp.color_ramp.elements
    els[0].position, els[0].color = 0.0, DARK
    els[1].position, els[1].color = 1.0, LIGHT
    lk.new(bc.outputs['Color'], bw.inputs['Color'])
    lk.new(bw.outputs['Val'], ramp.inputs['Fac'])
    lk.new(bc.outputs['Color'], _mix_in(rmix, 'A_Color'))
    lk.new(ramp.outputs['Color'], _mix_in(rmix, 'B_Color'))
    lk.new(next(o for o in rmix.outputs if o.identifier == 'Result_Color'), _mix_in(al, 'B_Color'))
    lk.new(next(o for o in al.outputs if o.identifier == 'Result_Color'), bg.inputs['Color'])


def _save_stops(scene, nt):
    """The ramp's colours onto the settings (the picture nodes go out: Colour, off)."""
    st = settings(scene)
    rn = nt.nodes.get(N_RAMP) if nt is not None else None
    if st is None or rn is None:
        return
    st[STOPS] = json.dumps([[e.position, list(e.color)] for e in rn.color_ramp.elements])


def _load_stops(scene, rn):
    """The ramp's colours from the settings, else from the old HDRI page's ramp (0.24.95 - 0.24.136)."""
    st = settings(scene)
    stops = None
    try:
        stops = json.loads(st[STOPS]) if st is not None and STOPS in st.keys() else None
    except (TypeError, ValueError):
        stops = None
    if stops is None:
        try:
            from . import backdrops
            old = backdrops.ramp_node(scene)
            if old is not None:
                stops = [[e.position, list(e.color)] for e in old.color_ramp.elements]
        except (ImportError, AttributeError, ReferenceError):
            stops = None
    if not stops:
        return
    els = rn.color_ramp.elements
    while len(els) > max(2, len(stops)):
        els.remove(els[-1])
    while len(els) < len(stops):
        els.new(1.0)
    for e, (pos, col) in zip(els, stops):
        e.position = pos
        e.color = col


def migrate(scene):
    """0.24.140 once: the old HDRI page's picture settings (Fit, Brightness, Contrast, Colour Ramp) carried over."""
    st = settings(scene)
    if st is None or st.get('mch_migrated'):
        return
    st['mch_migrated'] = 1
    if getattr(scene, 'mch_mech_hdri_bg_mode', 'COLOR') != 'IMAGE':
        return
    st.fit = getattr(scene, 'mch_mech_hdri_bg_fit', 'FILL')
    st.bright = float(getattr(scene, 'mch_mech_hdri_bg_bright', 0.0))
    st.contrast = float(getattr(scene, 'mch_mech_hdri_bg_contrast', 0.0))
    st.ramp = bool(getattr(scene, 'mch_mech_hdri_bg_ramp', False))


def ramp_node(scene):
    """The background picture's Colour Ramp node (the compositor's, else the scene's world's), or None."""
    if comp_on(scene):
        st = settings(scene)
        ng = scene.compositing_node_group
        return ng.nodes.get(N_RAMP) if has_picture(scene) else None
    w = getattr(scene, 'world', None)
    nt = getattr(w, 'node_tree', None)
    return nt.nodes.get(N_RAMP) if nt is not None else None


def _picture_sync(scene, nt, bg):
    """Picture mode with a picture that exists: the chain in (the picture loaded, fitted to the render frame);
    else the chain out (the colour)."""
    from . import backdrops
    st = settings(scene)
    cv, path = _wanted(scene)
    pic = nt.nodes.get(N_PIC)
    if cv is None and not path:
        img = pic.image if pic is not None else None
        _save_stops(scene, nt)
        for name in PIC_NODES:
            n = nt.nodes.get(name)
            if n is not None:
                nt.nodes.remove(n)
        _let_go(img)
        return
    if any(nt.nodes.get(n) is None for n in PIC_NODES):
        for name in PIC_NODES:
            n = nt.nodes.get(name)
            if n is not None:
                nt.nodes.remove(n)
        _picture_nodes(nt, bg)
        _load_stops(scene, nt.nodes.get(N_RAMP))
        pic = nt.nodes.get(N_PIC)
    img = _put_picture(pic, scene)
    ia = (img.size[0] / img.size[1]) if img.size[0] and img.size[1] else backdrops.aspect(path)
    sx, sy = backdrops.fit_scale(backdrops.frame_aspect(scene), ia, st.fit)
    # 0.24.141 (user: "뎁스 오브 필드 넣으면 왜 배경 부분이 하얘져?" - a render with a light frame round the picture):
    # depth of field (and the pixel filter) sends some camera rays just past the frame's edge, where a clipped picture
    # has nothing and the Colour showed through.  Fill: the picture's edge carried on outwards; Fit: clipped (the
    # Colour round the whole picture is the point)
    pic.extension = 'EXTEND' if st.fit == 'FILL' else 'CLIP'
    mp = nt.nodes.get(N_MAP)
    mp.inputs['Scale'].default_value = (sx, sy, 1.0)
    mp.inputs['Location'].default_value = (0.5 - 0.5 * sx, 0.5 - 0.5 * sy, 0.0)
    bc = nt.nodes.get(N_BC)
    bc.inputs['Bright'].default_value = float(st.bright)
    bc.inputs['Contrast'].default_value = float(st.contrast)
    _mix_in(nt.nodes.get(N_RMIX), 'Factor_Float').default_value = 1.0 if st.ramp else 0.0
    _mix_in(nt.nodes.get(N_ALPHA), 'A_Color').default_value = (*st.color, 1.0)


# ---- 0.24.148 the compositor way --------------------------------------------------------------------------------

C_NODES = (C_RL, C_FULL, N_PIC, C_SCALE, C_SEP, N_BC, C_CLAMP, N_BW, N_RAMP, N_RMIX, C_SETA, C_AO1, C_AO2)


def _out_node(nt):
    outs = [n for n in nt.nodes if n.bl_idname == 'NodeGroupOutput']
    return next((n for n in outs if getattr(n, 'is_active_output', False)), outs[0] if outs else None)


def _comp_group(scene):
    """The scene's compositor when our nodes feed its output, else None."""
    nt = getattr(scene, 'compositing_node_group', None)
    if nt is None:
        return None
    ao2, out = nt.nodes.get(C_AO2), _out_node(nt)
    if ao2 is None or out is None or not out.inputs:
        return None
    return nt if any(lk.from_node == ao2 for lk in out.inputs[0].links) else None


def comp_on(scene):
    """Is the background in the scene's compositor (our nodes before its output)?"""
    return _comp_group(scene) is not None


def _keep(scene):
    try:
        return json.loads(scene[COMP_KEY]) if COMP_KEY in scene.keys() else None
    except (TypeError, ValueError):
        return None


def _mix_sock(node, kind, io='in', which=0):
    socks = node.inputs if io == 'in' else node.outputs
    return [x for x in socks if x.type == kind][which]


def _comp_insert(scene, nt):
    """Our nodes into compositor ``nt``, just before its output: (what went to the output | the render) over (the
    picture over the colour).  Your own compositor nodes stay as they are (a nested group's Render Layers gives
    nothing in Blender 5.2, so ours go into your tree, like the world way's three nodes into your world)."""
    N, L = nt.nodes, nt.links
    for name in C_NODES:                              # (leftovers of an earlier time)
        n = N.get(name)
        if n is not None:
            N.remove(n)
    if not any(it.item_type == 'SOCKET' and it.in_out == 'OUTPUT' for it in nt.interface.items_tree):
        nt.interface.new_socket('Image', in_out='OUTPUT', socket_type='NodeSocketColor')
    out = _out_node(nt)
    if out is None:
        out = N.new('NodeGroupOutput')
        out.location = (800, 0)
    src = out.inputs[0].links[0].from_socket if out.inputs and out.inputs[0].links else None
    ox, oy = out.location

    def node(kind, name, dx, dy):
        n = N.new(kind)
        n.name = n.label = name
        n.location = (ox + dx, oy + dy)
        return n
    if src is None:
        rl = node('CompositorNodeRLayers', C_RL, -1700, 300)
        rl.scene = scene
        src = rl.outputs['Image']
    full = node('ShaderNodeMix', C_FULL, -560, 300)           # (a colour as big as the render: the picture's
    full.data_type = 'RGBA'                                   #  Fit leaves room round it)
    _mix_sock(full, 'VALUE').default_value = 1.0
    L.new(src, _mix_sock(full, 'RGBA'))
    img = node('CompositorNodeImage', N_PIC, -1700, -100)
    scl = node('CompositorNodeScale', C_SCALE, -1500, -100)
    scl.inputs['Type'].default_value = 'Render Size'
    L.new(img.outputs['Image'], scl.inputs['Image'])
    sep = node('CompositorNodeSeparateColor', C_SEP, -1300, -380)
    L.new(scl.outputs['Image'], sep.inputs['Image'])
    bc = node('ShaderNodeVectorMath', N_BC, -1300, -100)      # brightness / contrast: a x colour + b
    bc.operation = 'MULTIPLY_ADD'
    L.new(scl.outputs['Image'], bc.inputs[0])
    cl = node('ShaderNodeVectorMath', C_CLAMP, -1120, -100)
    cl.operation = 'MAXIMUM'
    cl.inputs[1].default_value = (0.0, 0.0, 0.0)
    L.new(bc.outputs['Vector'], cl.inputs[0])
    bw = node('CompositorNodeRGBToBW', N_BW, -940, -320)
    L.new(cl.outputs['Vector'], bw.inputs['Image'])
    ramp = node('ShaderNodeValToRGB', N_RAMP, -780, -320)
    els = ramp.color_ramp.elements
    els[0].position, els[0].color = 0.0, DARK
    els[1].position, els[1].color = 1.0, LIGHT
    L.new(bw.outputs['Val'], ramp.inputs[0])
    rmix = node('ShaderNodeMix', N_RMIX, -520, -150)
    rmix.data_type = 'RGBA'
    L.new(cl.outputs['Vector'], _mix_sock(rmix, 'RGBA'))
    L.new(ramp.outputs['Color'], _mix_sock(rmix, 'RGBA', which=1))
    seta = node('CompositorNodeSetAlpha', C_SETA, -340, -150)
    seta.inputs['Type'].default_value = 'Apply Mask'
    L.new(_mix_sock(rmix, 'RGBA', 'out'), seta.inputs['Image'])
    L.new(sep.outputs['Alpha'], seta.inputs['Alpha'])
    ao1 = node('CompositorNodeAlphaOver', C_AO1, -360, 150)
    L.new(_mix_sock(full, 'RGBA', 'out'), ao1.inputs['Background'])
    L.new(seta.outputs['Image'], ao1.inputs['Foreground'])
    ao2 = node('CompositorNodeAlphaOver', C_AO2, -180, 250)
    L.new(ao1.outputs['Image'], ao2.inputs['Background'])
    L.new(src, ao2.inputs['Foreground'])
    L.new(ao2.outputs['Image'], out.inputs[0])
    return nt


def _comp_take_out(nt):
    """Our nodes out of ``nt``, what went to its output linked to it again.  Returns the picture it showed."""
    N = nt.nodes
    ao2, out = N.get(C_AO2), _out_node(nt)
    src = None
    if ao2 is not None and ao2.inputs['Foreground'].links:
        lk = ao2.inputs['Foreground'].links[0]
        if lk.from_node.name != C_RL:
            src = lk.from_socket
    linked = ao2 is not None and out is not None and out.inputs and any(
        lk.from_node == ao2 for lk in out.inputs[0].links)
    pic = N.get(N_PIC)
    img = pic.image if pic is not None else None
    for name in C_NODES:
        n = N.get(name)
        if n is not None:
            N.remove(n)
    if src is not None and linked and not out.inputs[0].links:
        nt.links.new(src, out.inputs[0])
    return img


def comp_sync(scene):
    """The colour / picture / Fill-Fit / Brightness / Contrast / Colour Ramp into our compositor group."""
    st = settings(scene)
    ng = _comp_group(scene)
    if st is None or ng is None:
        return
    N = ng.nodes
    _mix_sock(N[C_FULL], 'RGBA', which=1).default_value = (*st.color, 1.0)
    if _put_picture(N.get(N_PIC), scene) is None:
        return
    scl = N[C_SCALE]
    scl.inputs['Frame Type'].default_value = 'Crop' if st.fit == 'FILL' else 'Fit'
    for ax in ('Extension X', 'Extension Y'):
        scl.inputs[ax].default_value = 'Extend' if st.fit == 'FILL' else 'Clip'
    a = 1.0 + float(st.contrast)                     # (as the world's Bright / Contrast node)
    b = float(st.bright) - float(st.contrast) * 0.5
    N[N_BC].inputs[1].default_value = (a, a, a)
    N[N_BC].inputs[2].default_value = (b, b, b)
    _mix_sock(N[N_RMIX], 'VALUE').default_value = 1.0 if st.ramp else 0.0


def update_view_compositor(scene, force_off=False):
    """Compositor on: every 3D view's viewport compositor Always (Material Preview / Rendered show the background);
    its own setting kept on the screen and put back."""
    want = comp_on(scene) and not force_off
    for scr, idx, sp in _views():
        sh = sp.shading
        try:
            keep = json.loads(scr[VIEWCOMP_KEY]) if VIEWCOMP_KEY in scr.keys() else {}
        except (TypeError, ValueError):
            keep = {}
        if want:
            if idx not in keep:
                keep[idx] = sh.use_compositor
            sh.use_compositor = 'ALWAYS'
            scr[VIEWCOMP_KEY] = json.dumps(keep)
        elif idx in keep:
            try:
                sh.use_compositor = keep.pop(idx)
            except (TypeError, ValueError):
                keep.pop(idx, None)
            if keep:
                scr[VIEWCOMP_KEY] = json.dumps(keep)
            elif VIEWCOMP_KEY in scr.keys():
                del scr[VIEWCOMP_KEY]


def comp_apply(scene):
    """The background in the compositor: Film Transparent, our nodes before the compositor's output (a compositor of
    ours when the scene has none), the viewport compositor on.  What was there is remembered (Off puts it back)."""
    if comp_on(scene):
        comp_sync(scene)
        return 'Background (Compositor) is on'
    if world_on(scene):
        world_remove(scene)
    migrate(scene)
    r = scene.render
    nt = getattr(scene, 'compositing_node_group', None)
    if _keep(scene) is None:
        scene[COMP_KEY] = json.dumps({'film_transparent': bool(r.film_transparent),
                                      'use_compositing': bool(r.use_compositing), 'made': nt is None})
    if nt is None:
        for ng in [g for g in bpy.data.node_groups if g.get(COMP_TAG) == scene.name and g.users == 0]:
            bpy.data.node_groups.remove(ng)                   # (a leftover of ours)
        nt = bpy.data.node_groups.new(f'MCH Background ({scene.name})', 'CompositorNodeTree')
        nt[COMP_TAG] = scene.name
        scene.compositing_node_group = nt
    _comp_insert(scene, nt)
    r.film_transparent = True
    r.use_compositing = True
    _load_stops(scene, nt.nodes.get(N_RAMP))
    comp_sync(scene)
    update_view_compositor(scene)
    update_views(scene)
    update_material_views(scene)
    st = settings(scene)
    what = 'Picture' if st is not None and st.mode == 'IMAGE' else 'Colour'
    return (f'Background {what} on (Compositor): Film Transparent and the viewport compositor set - Material '
            f'Preview / Rendered show it, the world still lights the parts')


def comp_remove(scene):
    """Our nodes out (a compositor of ours removed); Film Transparent, the views' viewport compositor as they were."""
    nt = getattr(scene, 'compositing_node_group', None)
    keep = _keep(scene) or {}
    r = scene.render
    img = None
    if nt is not None and nt.nodes.get(C_AO2) is not None:
        _save_stops(scene, nt)
        img = _comp_take_out(nt)
        if nt.get(COMP_TAG):
            scene.compositing_node_group = None
            if nt.users == 0:
                bpy.data.node_groups.remove(nt)
    if keep:
        try:
            r.film_transparent = bool(keep.get('film_transparent', False))
            r.use_compositing = bool(keep.get('use_compositing', True))
        except (AttributeError, TypeError):
            pass
    if COMP_KEY in scene.keys():
        del scene[COMP_KEY]
    _let_go(img)
    update_view_compositor(scene, force_off=True)
    return 'Background off (Compositor): Film Transparent and the compositor as they were'


def switch_method(scene, method):
    """World <-> Compositor (on stays on, the other way's changes put back)."""
    st = settings(scene)
    if st is None or method not in {'COMP', 'WORLD'}:
        return ''
    was = on(scene)
    st.method = method
    if not was:
        return f'Background: {"Compositor" if method == "COMP" else "World"} (press Background Colour to show it)'
    if method == 'COMP':
        if world_on(scene):
            world_remove(scene)
        return comp_apply(scene)
    if comp_on(scene):
        comp_remove(scene)
    return world_apply(scene)


# ---- 0.24.149 Paint Background: a canvas behind the model, painted in Blender's Image Editor ------------------------

def _to_srgb(v):
    import numpy as np
    v = np.clip(v, 0.0, None)
    return np.where(v <= 0.0031308, v * 12.92, 1.055 * np.power(v, 1 / 2.4) - 0.055)


def canvas_size(scene):
    """The canvas: the frame's shape, about the render's pixels (1024 .. 4096 on its long side)."""
    r = scene.render
    w = max(1.0, r.resolution_x * r.pixel_aspect_x * r.resolution_percentage / 100.0)
    h = max(1.0, r.resolution_y * r.pixel_aspect_y * r.resolution_percentage / 100.0)
    k = min(4096.0, max(1024.0, max(w, h))) / max(w, h)
    return max(16, int(round(w * k))), max(16, int(round(h * k)))


def _start_pixels(scene, W, H, ident):
    """The canvas's first pixels (sRGB, H x W x 4): picture ``ident`` fitted as shown (Fill / Fit, the colour round
    it), or ('') the colour."""
    import numpy as np
    from . import backdrops
    st = settings(scene)
    px = np.empty((H, W, 4), np.float32)
    px[..., :3] = _to_srgb(np.array(st.color, np.float32))
    px[..., 3] = 1.0
    path = backdrops.path(ident) if ident else ''
    if not path or not os.path.isfile(path):
        return px
    known = {i.name for i in bpy.data.images}
    src = bpy.data.images.load(path, check_existing=True)
    loaded = src if src.name not in known else None   # (in use already: not ours to remove)
    try:
        iw, ih = src.size
        if not iw or not ih:
            return px
        k = max(W / iw, H / ih) if st.fit == 'FILL' else min(W / iw, H / ih)
        nw, nh = max(1, int(round(iw * k))), max(1, int(round(ih * k)))
        tmp = src.copy()
        try:
            tmp.scale(nw, nh)
            a = np.empty(nw * nh * 4, np.float32)
            tmp.pixels.foreach_get(a)
            a = a.reshape(nh, nw, 4)
            if tmp.is_float:
                a[..., :3] = _to_srgb(a[..., :3])
        finally:
            bpy.data.images.remove(tmp)
    finally:
        if loaded is not None and loaded.users == 0:
            bpy.data.images.remove(loaded)
    ox, oy = (W - nw) // 2, (H - nh) // 2               # (centred: cut off, or the colour round it)
    x0, y0 = max(0, ox), max(0, oy)
    x1, y1 = min(W, ox + nw), min(H, oy + nh)
    sub = a[y0 - oy:y1 - oy, x0 - ox:x1 - ox]
    al = sub[..., 3:4]
    px[y0:y1, x0:x1, :3] = sub[..., :3] * al + px[y0:y1, x0:x1, :3] * (1.0 - al)
    return px


def make_canvas(scene, fresh=False):
    """The painted background: the one there is (``fresh``: started again), else a new one - starting as what is
    behind the model now (the picture, or the colour); it becomes the background picture (Fill: the frame's shape)."""
    st = settings(scene)
    img = next((i for i in bpy.data.images if i.get(CANVAS_TAG) == scene.name), None)
    cur = picture_ident(scene) if st.mode == 'IMAGE' else ''
    if cur.startswith(CANVAS_PREFIX):
        cur = img.get('mch_from', '') if img is not None else ''     # (the canvas itself: what it started from)
    if img is None or fresh:
        W, H = canvas_size(scene)
        px = _start_pixels(scene, W, H, cur)
        if img is None:
            img = bpy.data.images.new(CANVAS_NAME, W, H, alpha=False)
            img[CANVAS_TAG] = scene.name
        elif tuple(img.size) != (W, H):
            img.scale(W, H)
        img['mch_from'] = cur
        img.pixels.foreach_set(px.ravel())
        img.update()
        try:
            img.pack()                                # (kept in the .blend from the start)
        except RuntimeError:
            pass
    st.image = CANVAS_PREFIX + img.name
    st.fit = 'FILL'
    st.mode = 'IMAGE'
    return img


def _fit_view(area_ptr):
    try:
        for w in bpy.context.window_manager.windows:
            for a in w.screen.areas:
                if a.as_pointer() == area_ptr and a.type == 'IMAGE_EDITOR':
                    reg = next(r for r in a.regions if r.type == 'WINDOW')
                    with bpy.context.temp_override(window=w, area=a, region=reg):
                        bpy.ops.image.view_all(fit_view=True)
    except (RuntimeError, StopIteration, ReferenceError):
        pass
    return None


def paint_window(context, img):
    """A window with the Image Editor in Paint mode on ``img`` (one already showing it: that one).  The window, or
    None (then the 3D view's area is not changed either)."""
    wm = context.window_manager
    for w in wm.windows:
        for a in w.screen.areas:
            if a.type == 'IMAGE_EDITOR' and a.spaces.active.image == img:
                a.spaces.active.ui_mode = 'PAINT'
                return w
    win = context.window
    area = context.area if context.area is not None and context.area.type == 'VIEW_3D' else next(
        (a for a in win.screen.areas if a.type == 'VIEW_3D'), None) if win is not None else None
    if win is None or area is None:
        return None
    before = {w.as_pointer() for w in wm.windows}
    try:
        with context.temp_override(window=win, area=area):
            bpy.ops.screen.area_dupli('INVOKE_DEFAULT')
    except RuntimeError:
        return None
    made = [w for w in wm.windows if w.as_pointer() not in before]
    if not made:
        return None
    nw = made[-1]
    a = nw.screen.areas[0]
    a.ui_type = 'IMAGE_EDITOR'
    sp = a.spaces.active
    sp.image = img
    sp.ui_mode = 'PAINT'
    for flag in ('show_region_toolbar', 'show_region_ui', 'show_region_tool_header'):
        try:
            setattr(sp, flag, True)
        except AttributeError:
            pass
    for flag in ('show_uv', 'show_texpaint'):         # (not the active part's UVs over the painting; 5.x / 4.x)
        try:
            setattr(sp.uv_editor, flag, False)
        except AttributeError:
            pass
    ptr = a.as_pointer()
    bpy.app.timers.register(lambda: _fit_view(ptr), first_interval=0.3)
    return nw


@bpy.app.handlers.persistent
def _pack_canvases(*_args):
    """Saving the file: a painted background changed since it was packed is packed again (kept in the .blend)."""
    for img in bpy.data.images:
        if img.get(CANVAS_TAG) and img.is_dirty:
            try:
                img.pack()
            except RuntimeError as ex:
                print('[MECHA LAB] Paint Background: could not keep the painting in the file:', ex)


class MCH_OT_bg_paint(bpy.types.Operator):
    """Paint the background yourself: a canvas the frame's shape (starting as the picture / colour behind the model
    now) put behind the model, and a window with Blender's Image Editor in Paint mode on it.  Kept in the .blend"""
    bl_idname = 'mch.bg_paint'
    bl_label = 'Paint Background'
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}
    fresh: BoolProperty(default=False, options={'SKIP_SAVE'})

    def execute(self, context):
        sc = context.scene
        st = settings(sc)
        if st is None:
            return {'CANCELLED'}
        img = make_canvas(sc, fresh=self.fresh)
        msg = apply(sc) if not on(sc) else (set_color(sc) or '')
        win = None if bpy.app.background else paint_window(context, img)
        try:
            from . import side_panel
            side_panel.dirty()
        except (ImportError, AttributeError):
            pass
        self.report({'INFO'}, ('New canvas: ' if self.fresh else 'Paint Background: ') + (
            'paint in the new window (Image Editor, Paint) - the background follows' if win is not None else
            f'"{img.name}" behind the model - paint it in an Image Editor (Paint mode)') + (f'. {msg}' if msg else ''))
        return {'FINISHED'}


# ---- Solid view too: the 3D views' own background -----------------------------------------------------------------

def _views():
    out = []
    for win in getattr(bpy.context.window_manager, 'windows', ()):
        for i, area in enumerate(win.screen.areas):
            if area.type == 'VIEW_3D':
                sp = area.spaces.active
                if sp is not None and sp.type == 'VIEW_3D':
                    out.append((win.screen, str(i), sp))
    return out


def update_views(scene, force_off=False):
    """Solid view too on (and the colour on): the views' background = the colour (their own kept on the screen);
    else their own background back."""
    st = settings(scene)
    want = bool(st is not None and st.solid_too and on(scene) and not force_off)
    for scr, idx, sp in _views():
        sh = sp.shading
        try:
            keep = json.loads(scr[VIEW_KEY]) if VIEW_KEY in scr.keys() else {}
        except (TypeError, ValueError):
            keep = {}
        if want:
            if idx not in keep:
                keep[idx] = [sh.background_type, list(sh.background_color)]
            sh.background_type = 'VIEWPORT'
            sh.background_color = st.color
            scr[VIEW_KEY] = json.dumps(keep)
        elif idx in keep:
            typ, col = keep.pop(idx)
            try:
                sh.background_type = typ
                sh.background_color = col
            except (TypeError, ValueError):
                pass
            if keep:
                scr[VIEW_KEY] = json.dumps(keep)
            elif VIEW_KEY in scr.keys():
                del scr[VIEW_KEY]


def update_material_views(scene, force_off=False):
    """Material Preview Too on (and the background on): the 3D views' Material Preview uses the scene's world (their
    own setting kept on the screen and put back)."""
    st = settings(scene)
    want = bool(st is not None and st.material_too and on(scene) and not force_off)
    for scr, idx, sp in _views():
        sh = sp.shading
        try:
            keep = json.loads(scr[MAT_KEY]) if MAT_KEY in scr.keys() else {}
        except (TypeError, ValueError):
            keep = {}
        if want:
            if idx not in keep:
                keep[idx] = bool(sh.use_scene_world)
            sh.use_scene_world = True
            scr[MAT_KEY] = json.dumps(keep)
        elif idx in keep:
            sh.use_scene_world = bool(keep.pop(idx))
            if keep:
                scr[MAT_KEY] = json.dumps(keep)
            elif MAT_KEY in scr.keys():
                del scr[MAT_KEY]


class MCH_OT_bg_picture(bpy.types.Operator):
    """Put this picture behind the model (the Render tab's Background) - the world (your HDRI) still lights it"""
    bl_idname = 'mch.bg_picture'
    bl_label = 'Background Picture'
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}
    ident: StringProperty(default='', options={'SKIP_SAVE'})
    mode: StringProperty(default='', options={'SKIP_SAVE'})

    def execute(self, context):
        sc = context.scene
        st = settings(sc)
        if st is None:
            return {'CANCELLED'}
        if self.mode in {'COLOR', 'IMAGE'} and not self.ident:
            st.mode = self.mode                      # (Colour / Picture: the background on as well)
        else:
            from . import backdrops
            p = backdrops.path(self.ident)
            if not p or not os.path.isfile(p):
                self.report({'WARNING'}, f'Background: no picture "{self.ident}"')
                return {'CANCELLED'}
            st.image = self.ident
            st.mode = 'IMAGE'
        msg = apply(sc) if not on(sc) else (set_color(sc) or 'Background: ' + (
            os.path.basename(picture_path(sc)) if st.mode == 'IMAGE' else 'colour'))
        self.report({'INFO'}, msg)
        try:
            from . import side_panel
            side_panel.dirty()
        except (ImportError, AttributeError):
            pass
        return {'FINISHED'}


class MCH_OT_bg_ramp(bpy.types.Operator):
    """Edit the background picture's Colour Ramp - its colours and where they sit (add stops for more colours): the
    picture's dark parts take the left colour, its light parts the right one"""
    bl_idname = 'mch.bg_ramp'
    bl_label = 'Background Colour Ramp'
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    def invoke(self, context, event):
        if ramp_node(context.scene) is None:
            self.report({'WARNING'}, 'Colour Ramp: put a background picture on first (Render tab, Background)')
            return {'CANCELLED'}
        if bpy.app.background:
            return self.execute(context)
        return context.window_manager.invoke_popup(self, width=340)

    def draw(self, context):
        lay = self.layout
        lay.label(text='Background picture - Colour Ramp')
        node = ramp_node(context.scene)
        if node is not None:
            lay.template_color_ramp(node, 'color_ramp', expand=True)
        lay.label(text='Left: the picture\'s dark parts   Right: its light parts')

    def execute(self, context):
        return {'FINISHED'}


class MCH_OT_bg_picture_step(bpy.types.Operator):
    """The previous / next background picture (the studio backdrops, then your folder)"""
    bl_idname = 'mch.bg_picture_step'
    bl_label = 'Next Background Picture'
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}
    step: bpy.props.IntProperty(default=1, options={'SKIP_SAVE'})

    def execute(self, context):
        from . import backdrops
        ents = backdrops.entries()
        if not ents:
            return {'CANCELLED'}
        ids = [e[0] for e in ents]
        cur = picture_ident(context.scene)
        i = ids.index(cur) if cur in ids else -self.step
        show_picture(context.scene, ids[(i + self.step) % len(ids)])
        try:
            from . import side_panel
            side_panel.dirty()
        except (ImportError, AttributeError):
            pass
        return {'FINISHED'}


def draw_panel(layout, context):
    """The background settings (the sidebar's own Background panel, at the top of the Mecha Lab tab)."""
    from .workspace_ui import isz
    sc = context.scene
    st = settings(sc)
    if st is None:
        return
    is_on = on(sc)
    col = layout.column()
    r = col.row(align=True)
    r.operator('mch.bg_color', text='Background Colour', icon='CHECKBOX_HLT' if is_on else 'CHECKBOX_DEHLT',
               depress=is_on)
    r.prop(st, 'color', text='')
    r = col.row(align=True)                          # 0.24.148 Compositor | World
    r.operator('mch.bg_method', text='Compositor', depress=st.method == 'COMP').method = 'COMP'
    r.operator('mch.bg_method', text='World', depress=st.method == 'WORLD').method = 'WORLD'
    col.row(align=True).prop(st, 'mode', expand=True)
    r = col.row(align=True)                          # 0.24.149 paint it yourself
    r.operator('mch.bg_paint', text='Paint Background…', icon='BRUSH_DATA')
    if canvas_image(sc) is not None:
        r.operator('mch.bg_paint', text='New Canvas').fresh = True
    if st.mode == 'IMAGE':
        icon = preview_icon(picture_path(sc))
        if icon:
            col.template_icon(icon_value=icon, scale=isz(6.0))
        r = col.row(align=True)
        r.operator('mch.bg_picture_step', text='', icon='TRIA_LEFT').step = -1
        r.prop(st, 'image_pick', text='')
        r.operator('mch.bg_picture_step', text='', icon='TRIA_RIGHT').step = 1
        col.operator('mch.mech_bg_folder', text='Choose Folder…', icon='FILE_FOLDER')
        col.row(align=True).prop(st, 'fit', expand=True)
        col.prop(st, 'bright')
        col.prop(st, 'contrast')
        col.prop(st, 'ramp')
        rn = ramp_node(sc)
        if st.ramp and rn is not None:
            col.template_color_ramp(rn, 'color_ramp', expand=True)
    col.prop(st, 'material_too')
    col.prop(st, 'solid_too')
    try:
        from .mech_shader import hdri_world
        if hdri_world(sc) is not None:
            col.operator('mch.mech_hdri', text='Mecha HDRI Off (back to your world)', icon='X').action = 'OFF'
    except ImportError:
        pass


class MCH_PT_background(bpy.types.Panel):
    """0.24.142 The background - colour or picture behind the model - at the top of the sidebar's Mecha Lab tab"""
    bl_idname = 'MCH_PT_background'
    bl_label = 'Background'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Mecha Lab'
    bl_order = -100                                  # (before every other Mecha Lab panel)

    def draw_header(self, context):
        self.layout.label(text='', icon='WORLD')

    def draw(self, context):
        draw_panel(self.layout, context)


class MCH_OT_bg_fit(bpy.types.Operator):
    """The picture: Fill (the frame covered, its edges cut) or Fit (the whole picture, the colour round it)"""
    bl_idname = 'mch.bg_fit'
    bl_label = 'Background Fit'
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}
    fit: StringProperty(default='FILL', options={'SKIP_SAVE'})

    def execute(self, context):
        st = settings(context.scene)
        if st is None or self.fit not in {'FILL', 'FIT'}:
            return {'CANCELLED'}
        st.fit = self.fit
        return {'FINISHED'}


class MCH_OT_bg_color(bpy.types.Operator):
    """Background: the camera sees your colour or picture, the world (your HDRI add-on) still lights the parts.
    Again: off, the world as it was"""
    bl_idname = 'mch.bg_color'
    bl_label = 'Background Colour'
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    def execute(self, context):
        msg = remove(context.scene) if on(context.scene) else apply(context.scene)
        self.report({'INFO'}, msg)
        try:
            from . import side_panel
            side_panel.dirty()
        except (ImportError, AttributeError):
            pass
        return {'FINISHED'}


class MCH_OT_bg_method(bpy.types.Operator):
    """How the background goes behind the model: Compositor (Film Transparent and the viewport compositor set for you,
    the world untouched) or World (in the world for the camera rays)"""
    bl_idname = 'mch.bg_method'
    bl_label = 'Background Method'
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}
    method: StringProperty(default='COMP', options={'SKIP_SAVE'})

    def execute(self, context):
        msg = switch_method(context.scene, self.method)
        if not msg:
            return {'CANCELLED'}
        self.report({'INFO'}, msg)
        try:
            from . import side_panel
            side_panel.dirty()
        except (ImportError, AttributeError):
            pass
        return {'FINISHED'}


CLASSES = (MCH_PG_Background, MCH_OT_bg_method, MCH_OT_bg_paint, MCH_OT_bg_color, MCH_OT_bg_picture, MCH_OT_bg_fit, MCH_OT_bg_ramp,
           MCH_OT_bg_picture_step, MCH_PT_background)


def register():
    for c in CLASSES:
        bpy.utils.register_class(c)
    bpy.types.Scene.mch_bg = bpy.props.PointerProperty(type=MCH_PG_Background)
    if _pack_canvases not in bpy.app.handlers.save_pre:
        bpy.app.handlers.save_pre.append(_pack_canvases)


def unregister():
    if _pack_canvases in bpy.app.handlers.save_pre:
        bpy.app.handlers.save_pre.remove(_pack_canvases)
    if _PREV['coll'] is not None:
        try:
            from bpy.utils import previews as _previews     # (not "import bpy...": that made bpy local here)
            _previews.remove(_PREV['coll'])
        except (KeyError, RuntimeError):
            pass
        _PREV['coll'] = None
    if hasattr(bpy.types.Scene, 'mch_bg'):
        del bpy.types.Scene.mch_bg
    for c in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(c)
        except RuntimeError:
            pass
