"""Interactive shape strokes shared by the Cut, Split and Mask tools.

Interaction model (fixes the v0.5.9 "Ctrl+Z does nothing / Esc needed before
clicking a menu" problems):

* Cut / Split / Mask are native WorkSpaceTools.  Between strokes NOTHING is
  modal: Ctrl+Z, menus, the sidebar and other editors behave like normal
  Blender.  LMB in the viewport starts ``mch.cut_stroke``.
* ``mch.cut_stroke`` is modal only for one stroke and returns FINISHED after
  one cut, so every cut is exactly one undo step.  A failed cut returns
  CANCELLED and pushes nothing.
* While a stroke is pending, events outside the viewport region pass through
  (shape palette, sidebar, menus work without Esc).  Changing the shape or the
  tool discards only the unfinished stroke.
* Keys: Enter / LMB double-click confirm, Esc cancels the stroke, Backspace or
  Ctrl+Z removes the last point, Ctrl+Shift+Z re-adds it, Shift snaps to 45
  degrees, Alt inverts (keep inside / erase mask), F toggles open line.
* RMB once = shape popup, RMB twice (double-click) = leave the tool.  The popup
  waits for the double-click interval so the second click is never eaten.
"""
from __future__ import annotations

import math
import time
import traceback

import bpy
import gpu
from bpy.props import EnumProperty
from gpu_extras.batch import batch_for_shader
from mathutils import Vector
from mathutils.geometry import tessellate_polygon

from . import core_geometry as cg
from . import tool_state as ts

SHAPE_POPUP = 'MCH_PT_shape_popup'
TOOL_POPUP = 'MCH_PT_tool_popup'
PROFILE_POPUP = 'MCH_PT_profile_popup'
DUP_PX = 4.0          # clicks closer than this are the same point
HIT_PX = 9.0
NAV_EVENTS = {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE', 'WHEELINMOUSE', 'WHEELOUTMOUSE',
              'TRACKPADPAN', 'TRACKPADZOOM', 'MOUSEROTATE', 'MOUSESMARTZOOM'}


# -----------------------------------------------------------------------------
# Pure 2D shape generation
# -----------------------------------------------------------------------------


def rect_loop(a, b, square=False, centered=False):
    dx, dy = b[0] - a[0], b[1] - a[1]
    if square:
        s = max(abs(dx), abs(dy))
        dx, dy = math.copysign(s, dx or 1), math.copysign(s, dy or 1)
    if centered:
        x0, y0, x1, y1 = a[0] - dx, a[1] - dy, a[0] + dx, a[1] + dy
    else:
        x0, y0, x1, y1 = a[0], a[1], a[0] + dx, a[1] + dy
    return [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]


def ellipse_loop(a, b, segments, circle=False, centered=False):
    if centered:
        cx, cy = a
        rx, ry = abs(b[0] - a[0]), abs(b[1] - a[1])
    else:
        cx, cy = (a[0] + b[0]) / 2, (a[1] + b[1]) / 2
        rx, ry = abs(b[0] - a[0]) / 2, abs(b[1] - a[1]) / 2
    if circle:
        rx = ry = max(rx, ry)
    return [(cx + rx * math.cos(2 * math.pi * i / segments),
             cy + ry * math.sin(2 * math.pi * i / segments)) for i in range(segments)]


def circle_loop(c, edge, segments):
    r = math.dist(c, edge)
    return [(c[0] + r * math.cos(2 * math.pi * i / segments),
             c[1] + r * math.sin(2 * math.pi * i / segments)) for i in range(segments)]


def curve_tangents(points, sharp, overrides, smoothness=1.0, closed=True):
    """Per-point tangents of the Curve Lasso spline (Catmull-Rom by default).

    ``sharp[i]`` makes a corner (zero tangent); ``overrides[i]`` is a tangent
    set by dragging that point's Bezier handle (aligned, symmetric handles).
    """
    n = len(points)
    out = []
    for i in range(n):
        ov = overrides[i] if i < len(overrides) else None
        if ov is not None:
            out.append(ov)
            continue
        if i < len(sharp) and sharp[i]:
            out.append((0.0, 0.0))
            continue
        if closed or 0 < i < n - 1:
            a, b = points[i - 1], points[(i + 1) % n]
        elif i == 0:
            a, b = points[0], points[min(1, n - 1)]
        else:
            a, b = points[max(n - 2, 0)], points[n - 1]
        out.append(((b[0] - a[0]) * 0.5 * smoothness, (b[1] - a[1]) * 0.5 * smoothness))
    return out


def curve_handles(points, tangents, i):
    """(incoming, outgoing) Bezier handle positions of control point ``i``."""
    p, t = points[i], tangents[i]
    return ((p[0] - t[0] / 3.0, p[1] - t[1] / 3.0), (p[0] + t[0] / 3.0, p[1] + t[1] / 3.0))


def curve_lasso_spline(points, sharp=(), overrides=(), resolution=12, smoothness=1.0, closed=True):
    """Smooth closed outline through the control points (cubic Bezier spans)."""
    n = len(points)
    if n < 2 or (closed and n < 3):
        return list(points)
    tangents = curve_tangents(points, list(sharp), list(overrides), smoothness, closed)
    res = max(1, int(resolution))
    out = []
    spans = n if closed else n - 1
    for i in range(spans):
        p0, p1 = points[i], points[(i + 1) % n]
        c0 = curve_handles(points, tangents, i)[1]
        c1 = curve_handles(points, tangents, (i + 1) % n)[0]
        for k in range(res):
            t = k / res
            u = 1.0 - t
            out.append((u * u * u * p0[0] + 3 * u * u * t * c0[0] + 3 * u * t * t * c1[0] + t * t * t * p1[0],
                        u * u * u * p0[1] + 3 * u * u * t * c0[1] + 3 * u * t * t * c1[1] + t * t * t * p1[1]))
    if not closed:
        out.append(points[-1])
    return out


def round_corners(loop, radius, mode='ROUND', segments=6):
    """2D outline corner rounding / chamfer (shape option, NOT the 3D edge finish)."""
    n = len(loop)
    if mode == 'NONE' or radius <= 0 or n < 3:
        return list(loop)
    out = []
    for i in range(n):
        p, a, b = loop[i], loop[i - 1], loop[(i + 1) % n]
        la, lb = math.dist(p, a), math.dist(p, b)
        if la < 1e-6 or lb < 1e-6:
            out.append(p)
            continue
        d = min(radius, 0.45 * la, 0.45 * lb)
        cross = (a[0] - p[0]) * (b[1] - p[1]) - (a[1] - p[1]) * (b[0] - p[0])
        if d < 0.5 or abs(cross) < 1e-6 * la * lb:   # tiny or straight-through point
            out.append(p)
            continue
        h0 = (p[0] + (a[0] - p[0]) * d / la, p[1] + (a[1] - p[1]) * d / la)
        h1 = (p[0] + (b[0] - p[0]) * d / lb, p[1] + (b[1] - p[1]) * d / lb)
        if mode == 'CHAMFER':
            out.extend((h0, h1))
            continue
        for k in range(segments + 1):
            t = k / segments
            u = 1 - t
            out.append((u * u * h0[0] + 2 * u * t * p[0] + t * t * h1[0],
                        u * u * h0[1] + 2 * u * t * p[1] + t * t * h1[1]))
    return out


def smooth_open(points, iterations=2):
    """Moving-average smoothing of a freehand path (ends fixed)."""
    pts = list(points)
    for _ in range(max(0, int(iterations))):
        if len(pts) < 3:
            break
        pts = [pts[0]] + [((pts[i - 1][0] + 2 * pts[i][0] + pts[i + 1][0]) / 4.0,
                           (pts[i - 1][1] + 2 * pts[i][1] + pts[i + 1][1]) / 4.0)
                          for i in range(1, len(pts) - 1)] + [pts[-1]]
    return pts


def clean_clicks(points, dup_px=4.0, closed=True):
    """Drop near-duplicate consecutive points (PRESS + DOUBLE_CLICK on one mouse
    down) and a last point that sits on the first, so no zero-length edge."""
    out = []
    for p in points:
        if not out or math.dist(p, out[-1]) > dup_px:
            out.append(p)
    if closed:
        while len(out) > 3 and math.dist(out[0], out[-1]) <= dup_px:
            out.pop()
    return out


def custom_loops(norm_loops, center, radius, angle):
    c, s = math.cos(angle), math.sin(angle)
    scale = radius * 2.0   # normalized loops span [-0.5, 0.5]
    out = []
    for lp in norm_loops:
        out.append([(center[0] + (x * c - y * s) * scale, center[1] + (x * s + y * c) * scale)
                    for x, y in lp])
    return out


def snap45(anchor, p):
    dx, dy = p[0] - anchor[0], p[1] - anchor[1]
    r = math.hypot(dx, dy)
    if r < 1e-6:
        return p
    ang = round(math.atan2(dy, dx) / (math.pi / 4)) * (math.pi / 4)
    return (anchor[0] + math.cos(ang) * r, anchor[1] + math.sin(ang) * r)


# Open line -> half-plane polygon inside a padded screen box (from v0.5.9).


def _ray_box_exit(point, direction, box):
    x, y = point
    dx, dy = direction
    xmin, ymin, xmax, ymax = box
    best = None
    for border, orig, d in ((xmin, x, dx), (xmax, x, dx), (ymin, y, dy), (ymax, y, dy)):
        if abs(d) > 1e-9:
            t = (border - orig) / d
            if t > 1e-9:
                px, py = x + t * dx, y + t * dy
                if xmin - 0.01 <= px <= xmax + 0.01 and ymin - 0.01 <= py <= ymax + 0.01:
                    if best is None or t < best[0]:
                        best = (t, (max(xmin, min(xmax, px)), max(ymin, min(ymax, py))))
    if best is None:
        raise cg.CutError('Line endpoints coincide; place two distinct points.')
    return best[1]


def _perimeter_param(p, box):
    xmin, ymin, xmax, ymax = box
    x, y = p
    w, h = xmax - xmin, ymax - ymin
    e = 0.03
    if abs(y - ymin) < e:
        return x - xmin
    if abs(x - xmax) < e:
        return w + y - ymin
    if abs(y - ymax) < e:
        return w + h + xmax - x
    if abs(x - xmin) < e:
        return 2 * w + h + ymax - y
    raise cg.CutError('Line endpoint is not on the view boundary.')


def _border_ccw(a, b, box):
    xmin, ymin, xmax, ymax = box
    w, h = xmax - xmin, ymax - ymin
    per = 2 * (w + h)
    lo, hi = _perimeter_param(a, box), _perimeter_param(b, box)
    if hi <= lo + 1e-6:
        hi += per
    corners = [(w, (xmax, ymin)), (w + h, (xmax, ymax)), (2 * w + h, (xmin, ymax)), (per, (xmin, ymin))]
    route = [c for t, c in ((t + k * per, p) for k in (0, 1) for t, p in corners) if lo + 1e-5 < t < hi - 1e-5]
    return route + [b]


def side_polygon(points, box):
    if len(points) < 2:
        raise cg.CutError('Draw at least two points.')
    p0, p1 = points[0], points[1]
    q1, q0 = points[-2], points[-1]
    a = _ray_box_exit(p0, (p0[0] - p1[0], p0[1] - p1[1]), box)
    b = _ray_box_exit(q0, (q0[0] - q1[0], q0[1] - q1[1]), box)
    if math.dist(a, b) < 2:
        raise cg.CutError('Line ends meet at the same boundary point.')
    return cg.dedupe_loop([a] + list(points) + [b] + _border_ccw(b, a, box)[:-1], 0.05)


# -----------------------------------------------------------------------------
# Targets
# -----------------------------------------------------------------------------


def pick_mesh_under(context, projector, xy):
    origin, direction = projector.ray(xy)
    dg = context.evaluated_depsgraph_get()
    hit, _loc, _n, _i, ob, _m = context.scene.ray_cast(dg, origin, direction)
    if hit and ob is not None and ob.type == 'MESH':
        original = ob.original
        # The mask preview is a selectable-disabled overlay, not a target mesh.
        # It may still be returned by a scene ray-cast after a mask stroke.
        source_name = original.get('mch_preview_source')
        if source_name:
            return bpy.data.objects.get(source_name)
        return original
    return None


def gather_targets(context, projector, xy, mode):
    cut = context.scene.mch_cut
    active = context.view_layer.objects.active
    if mode != 'MASK' and cut.targets == 'SELECTED':
        targets = [o for o in context.selected_objects if o.type == 'MESH' and o.visible_get()]
        if targets:
            return targets
    if active is not None and active.type == 'MESH' and active.visible_get() and \
            (active.select_get() or not context.selected_objects):
        return [active]
    picked = pick_mesh_under(context, projector, xy)
    if picked is not None:
        for o in context.selected_objects:
            o.select_set(False)
        picked.select_set(True)
        context.view_layer.objects.active = picked
        return [picked]
    return []


def surface_hit(context, targets, projector, xy):
    origin, direction = projector.ray(xy)
    best = None
    for ob in targets:
        inv = ob.matrix_world.inverted_safe()
        ok, loc, _n, _f = ob.ray_cast(inv @ origin, (inv.to_3x3() @ direction).normalized())
        if ok:
            world = ob.matrix_world @ loc
            d = (world - origin).length
            if best is None or d < best[0]:
                best = (d, world)
    return None if best is None else best[1]


def _loops_centroid(loops):
    pts = loops[0]
    return (sum(p[0] for p in pts) / len(pts), sum(p[1] for p in pts) / len(pts))


def _planes(context, targets, projector, loops):
    cut = context.scene.mch_cut
    hit = None
    if cut.depth_mode == 'SURFACE':
        hit = surface_hit(context, targets, projector, _loops_centroid(loops))
        if hit is None:
            for p in loops[0]:
                hit = surface_hit(context, targets, projector, p)
                if hit is not None:
                    break
    return cg.depth_planes(projector, cg.object_world_bounds(targets), cut.depth_mode, hit, cut.depth)


def _object_scale(ob):
    s = ob.matrix_world.to_scale()
    return max((abs(s.x) + abs(s.y) + abs(s.z)) / 3.0, 1e-9)


def _make_piece(target, mesh, suffix='_Split'):
    piece = target.copy()
    piece.data = mesh
    mesh.name = target.data.name + suffix
    piece.name = target.name + suffix
    for coll in target.users_collection:
        coll.objects.link(piece)
    cg.remove_cutter_attribute(mesh)
    return piece


# -----------------------------------------------------------------------------
# Operations (usable headless with any projector)
# -----------------------------------------------------------------------------


def offset_loop(loop, d):
    """Offset a closed 2D loop by ``d`` px to the right of its direction.

    With the usual orientation (outlines CCW, holes CW) positive ``d`` grows
    the filled region and negative ``d`` shrinks it.  Miter joins, with a
    two-point bevel join at very sharp corners.
    """
    n = len(loop)
    out = []
    for i in range(n):
        p0, p1, p2 = loop[i - 1], loop[i], loop[(i + 1) % n]
        e1 = (p1[0] - p0[0], p1[1] - p0[1])
        e2 = (p2[0] - p1[0], p2[1] - p1[1])
        l1, l2 = math.hypot(*e1), math.hypot(*e2)
        if l1 < 1e-9 or l2 < 1e-9:
            continue
        n1 = (e1[1] / l1, -e1[0] / l1)
        n2 = (e2[1] / l2, -e2[0] / l2)
        m = (n1[0] + n2[0], n1[1] + n2[1])
        ml = math.hypot(*m)
        cos_half = ml / 2.0
        if ml < 1e-9 or cos_half < 0.35:      # very sharp corner: bevel join
            out.append((p1[0] + n1[0] * d, p1[1] + n1[1] * d))
            out.append((p1[0] + n2[0] * d, p1[1] + n2[1] * d))
            continue
        k = d / cos_half
        out.append((p1[0] + m[0] / ml * k, p1[1] + m[1] / ml * k))
    return out


def pixels_per_unit(projector, targets):
    """Screen pixels per model unit at the targets' centre depth (exact in ortho)."""
    pts = cg.object_world_bounds(targets)
    centre = sum(pts, Vector()) / len(pts)
    v = projector.view_dir.orthogonal().normalized()
    a, b = projector.to_screen(centre), projector.to_screen(centre + v)
    if a is None or b is None:
        raise cg.CutError('Targets are outside the view.')
    return max(math.dist(a, b), 1e-9)


def _gap_groups(groups, d):
    loops = [offset_loop(lp, d) for outer, holes in groups for lp in [outer] + list(holes)]
    try:
        return cg.prepare_loops(loops)
    except cg.CutError:
        raise cg.CutError('Gap Width is too large for this outline (offset outline overlaps itself); '
                          'use a smaller Gap Width or a simpler shape.')


def _finish_side(cut, me, side, scale):
    mode = getattr(cut, f'side_{side}_finish')
    if mode == 'NONE':
        return 0
    return cg.finish_new_edges(me, mode, getattr(cut, f'side_{side}_width') / scale,
                               getattr(cut, f'side_{side}_segments'), 0.5)


def _side_report(cut, counts):
    parts = []
    for side, label in (('a', 'A'), ('b', 'B')):
        mode = getattr(cut, f'side_{side}_finish')
        if mode != 'NONE':
            parts.append(f'{label} {mode.lower()}: {counts.get(side, 0)} edges')
    return (' | ' + ', '.join(parts)) if parts else ''


def perform_closed(context, mode, targets, loops, projector, invert=False):
    """Cut / Split all targets with closed screen loops. Returns a report string."""
    scene = context.scene
    cut = scene.mch_cut
    auto_apply = scene.mch_settings.auto_apply if hasattr(scene, 'mch_settings') else True
    groups = cg.prepare_loops(loops)
    for t in targets:
        cg.check_target(t)
    near, far = _planes(context, targets, projector, [g[0] for g in groups])
    gap = mode == 'SPLIT' and cut.split_mode == 'GAP' and cut.gap_width > 0
    if gap and not auto_apply:
        raise cg.CutError('Gap Split needs Auto Apply ON (live cutters support Normal Split only).')
    cutter_out = None
    if gap:
        half_px = 0.5 * cut.gap_width * pixels_per_unit(projector, targets)
        inner_groups = _gap_groups(groups, -half_px)
        outer_groups = _gap_groups(groups, half_px)
        cutter = cg.link_temp_object(context, cg.build_cutter_mesh(inner_groups, projector, near, far, 'MCH_GapIn'))
        try:
            cutter_out = cg.link_temp_object(
                context, cg.build_cutter_mesh(outer_groups, projector, near, far, 'MCH_GapOut'))
        except Exception:
            cg.remove_object_and_mesh(cutter)
            raise
    else:
        cutter_mesh = cg.build_cutter_mesh(groups, projector, near, far, 'MCH_CutterMesh')
        cutter = cg.link_temp_object(context, cutter_mesh)
    if not auto_apply:
        return _make_live(context, mode, targets, cutter, invert)
    results, pieces, temp = [], [], []
    edge_counts = []
    side_counts = {}
    try:
        for t in targets:
            scale = _object_scale(t)
            try:
                if mode == 'CUT':
                    op = 'INTERSECT' if invert else 'DIFFERENCE'
                    me, _solver = cg.boolean_result(context, t, cutter, op, cut.solver, cut.hole_tolerant)
                    temp.append(me)
                    edge_counts.append(cg.finish_new_edges(
                        me, cut.edge_finish, cut.finish_width / scale,
                        cut.finish_segments, cut.finish_profile))
                    results.append((t, me))
                else:  # SPLIT
                    inner, _s1 = cg.boolean_result(context, t, cutter, 'INTERSECT', cut.solver, cut.hole_tolerant)
                    temp.append(inner)
                    outer, _s2 = cg.boolean_result(context, t, cutter_out or cutter, 'DIFFERENCE',
                                                   cut.solver, cut.hole_tolerant)
                    temp.append(outer)
                    # Side A = remaining original object, Side B = the new "_Split" piece.
                    for me, side in ((outer, 'a'), (inner, 'b')):
                        if cut.split_cap:
                            side_counts[side] = side_counts.get(side, 0) + _finish_side(cut, me, side, scale)
                        else:
                            cg.strip_cutter_faces(me)
                    results.append((t, outer))
                    pieces.append((t, inner))
            except cg.CutError as ex:
                if len(targets) > 1 and 'does not intersect' in str(ex):
                    continue
                raise
        if not results:
            raise cg.CutError('The shape does not intersect any target; nothing was changed.')
        infos = []
        for t, me in results:
            infos.append(cg.commit_mesh(t, me, cut.shared_mesh))
        new_pieces = []
        for t, me in pieces:
            temp.remove(me)
            new_pieces.append(_make_piece(t, me))
        for p in new_pieces:
            p.select_set(True)
        verb = {'CUT': 'Kept inside' if invert else 'Cut',
                'SPLIT': ('Gap split' if gap else 'Split')}[mode]
        suffix = ''
        if mode == 'SPLIT':
            suffix = _side_report(cut, side_counts) if cut.split_cap else ''
        elif cut.edge_finish != 'NONE' and cut.finish_width > 0:
            if not edge_counts:
                suffix = ' | Edge Finish skipped (uncapped or Live cut)'
            elif sum(edge_counts) == 0:
                suffix = ' | WARNING: Edge Finish found 0 new edges; no bevel/chamfer'
            else:
                suffix = f' | {cut.edge_finish}: {sum(edge_counts)} newly cut edges'
        return f'{verb}: {", ".join(t.name for t, _ in results)}{"".join(sorted(set(infos)))}{suffix}'
    finally:
        for me in temp:
            if me.users == 0:
                bpy.data.meshes.remove(me)
        cg.remove_object_and_mesh(cutter)
        cg.remove_object_and_mesh(cutter_out)


def _make_live(context, mode, targets, cutter, invert):
    """Auto Apply OFF: keep the cutter object and live Boolean modifiers."""
    cut = context.scene.mch_cut
    solver = {'AUTO': 'EXACT', 'FAST': 'FLOAT'}.get(cut.solver, cut.solver)
    cutter.name = 'MCH_Cut_Live'
    cutter.data.name = 'MCH_Cut_Live_Mesh'
    cutter['mch_cut_carrier'] = True
    first = targets[0]
    for t in targets:
        mod = t.modifiers.new('MCH_LiveCut', 'BOOLEAN')
        mod.object = cutter
        mod.solver = solver
        mod.operation = 'INTERSECT' if (mode == 'CUT' and invert) else 'DIFFERENCE'
        if t == first:
            cutter['mch_cut_target_name'] = t.name
            cutter['mch_cut_target_mod'] = mod.name
            if hasattr(cutter, 'mch_live'):
                cutter.mch_live.target = t
        t['mch_recent_cut'] = cutter.name
    if mode == 'SPLIT':
        piece = first.copy()
        piece.data = first.data.copy()
        piece.name = first.name + '_Split'
        for coll in first.users_collection:
            coll.objects.link(piece)
        for m in [m for m in piece.modifiers if m.name.startswith('MCH_LiveCut')]:
            piece.modifiers.remove(m)
        pm = piece.modifiers.new('MCH_LiveCut_Piece', 'BOOLEAN')
        pm.object = cutter
        pm.solver = solver
        pm.operation = 'INTERSECT'
        cutter['mch_cut_piece_name'] = piece.name
        cutter['mch_cut_piece_mod'] = pm.name
        if hasattr(cutter, 'mch_live'):
            cutter.mch_live.source = piece
    return ('Live cut created (edit cutter, then Apply Live Cut). ' +
            ('Edge Finish requires Auto Apply ON; no bevel generated.' if cut.edge_finish != 'NONE' else ''))


def perform_line(context, mode, targets, points, projector, side_xy, invert=False):
    """Open line cut / split. ``side_xy`` picks the half removed by Cut."""
    scene = context.scene
    cut = scene.mch_cut
    auto_apply = scene.mch_settings.auto_apply if hasattr(scene, 'mch_settings') else True
    for t in targets:
        cg.check_target(t)
    if len(points) == 2 and cut.fast_line and auto_apply:
        near, far = cg.depth_planes(projector, cg.object_world_bounds(targets))
        vd = projector.view_dir

        def at(xy, plane):
            o, d = projector.ray(xy)
            return cg._plane_hit(o, d, plane, vd)[0]
        a_near, a_far, b_near = at(points[0], near), at(points[0], far), at(points[1], near)
        normal = (a_far - a_near).cross(b_near - a_near)
        if normal.length < 1e-12:
            raise cg.CutError('Line is too short.')
        normal.normalize()
        side = (at(side_xy, near) - a_near).dot(normal) > 0
        results, pieces, temp = [], [], []
        line_bevel_counts = []
        side_counts = {}
        try:
            for t in targets:
                scale = _object_scale(t)
                try:
                    if mode == 'CUT':
                        me = cg.plane_split_mesh(t, a_near, normal, side != invert, cut.line_cap)
                        temp.append(me)
                        if cut.line_cap:
                            line_bevel_counts.append(cg.finish_new_edges(
                                me, cut.edge_finish, cut.finish_width / scale,
                                cut.finish_segments, cut.finish_profile))
                        results.append((t, me))
                    else:
                        cap = cut.split_cap and cut.line_cap
                        # Gap Split: two planes at +-gap/2 around the drawn line (centre kept).
                        half = 0.5 * cut.gap_width if cut.split_mode == 'GAP' else 0.0
                        keep = cg.plane_split_mesh(t, a_near - normal * half, normal, True, cap)
                        temp.append(keep)
                        other = cg.plane_split_mesh(t, a_near + normal * half, normal, False, cap)
                        temp.append(other)
                        if cap:
                            for me, side in ((keep, 'a'), (other, 'b')):
                                n = _finish_side(cut, me, side, scale)
                                side_counts[side] = side_counts.get(side, 0) + n
                        results.append((t, keep))
                        pieces.append((t, other))
                except cg.CutError as ex:
                    if len(targets) > 1 and 'does not cross' in str(ex):
                        continue
                    raise
            if not results:
                raise cg.CutError('The line does not cross any target; nothing was changed.')
            infos = [cg.commit_mesh(t, me, cut.shared_mesh) for t, me in results]
            for t, me in pieces:
                temp.remove(me)
                _make_piece(t, me).select_set(True)
            suffix = ''
            if mode == 'SPLIT':
                suffix = _side_report(cut, side_counts) + (' | gap' if cut.split_mode == 'GAP' else '')
            elif cut.edge_finish != 'NONE' and cut.finish_width > 0:
                if not line_bevel_counts:
                    suffix = ' | Edge Finish skipped (cap disabled)'
                elif sum(line_bevel_counts) == 0:
                    suffix = ' | WARNING: Edge Finish found 0 cap boundary edges'
                else:
                    suffix = f' | {cut.edge_finish}: {sum(line_bevel_counts)} new boundary edges'
            return ('Plane split: ' if mode == 'SPLIT' else 'Plane cut: ') + \
                ', '.join(t.name for t, _ in results) + ''.join(sorted(set(infos))) + suffix
        finally:
            for me in temp:
                if me.users == 0:
                    bpy.data.meshes.remove(me)
    # Polyline: half-plane polygon prism through the Boolean pipeline.
    corners = []
    for co in cg.object_world_bounds(targets):
        p = projector.to_screen(co)
        if p is not None:
            corners.append(p)
    if not corners:
        raise cg.CutError('Targets are outside the view.')
    corners.extend(points)
    corners.append(side_xy)   # the clicked side must lie inside the half-plane box
    xs = [p[0] for p in corners]
    ys = [p[1] for p in corners]
    pad = max(80.0, 0.2 * max(max(xs) - min(xs), max(ys) - min(ys)))
    box = (min(xs) - pad, min(ys) - pad, max(xs) + pad, max(ys) + pad)
    half = side_polygon(points, box)
    if mode == 'CUT':
        clicked_inside = cg.point_in_loop(side_xy, half)
        if not clicked_inside:
            half = side_polygon(list(reversed(points)), box)
        # Removing the clicked half; Alt keeps it instead.
        return perform_closed(context, 'CUT', targets, [half], projector, invert=invert)
    return perform_closed(context, 'SPLIT', targets, [half], projector)


def perform_mask(context, target, loops, projector, erase):
    from . import mask_tools
    groups = cg.prepare_loops(loops)
    flat = [lp for outer, holes in groups for lp in [outer] + holes]
    changed, total = mask_tools.apply_mask_loops(context, target, flat, projector, erase)
    return f'Mask faces {"removed" if erase else "added"}: {changed} (total {total})'


# -----------------------------------------------------------------------------
# Drawing overlay
# -----------------------------------------------------------------------------

_COLORS = {
    'CUT': (1.0, 0.62, 0.10, 1.0),
    'CUT_INV': (0.25, 0.90, 1.0, 1.0),
    'SPLIT': (0.45, 1.0, 0.35, 1.0),
    'MASK': (0.85, 0.45, 1.0, 1.0),
    'MASK_INV': (0.55, 0.55, 0.60, 1.0),
}


def _shader():
    return gpu.shader.from_builtin('UNIFORM_COLOR')


def _draw_lines(sh, pts, color, closed=False, width=2.0):
    if len(pts) < 2:
        return
    seq = list(pts) + ([pts[0]] if closed else [])
    gpu.state.line_width_set(width)
    sh.bind()
    sh.uniform_float('color', color)
    batch_for_shader(sh, 'LINE_STRIP', {'pos': seq}).draw(sh)


def _draw_squares(sh, pts, color, size=4.0):
    if not pts:
        return
    tris = []
    for x, y in pts:
        a, b, c, d = (x - size, y - size), (x + size, y - size), (x + size, y + size), (x - size, y + size)
        tris.extend((a, b, c, a, c, d))
    sh.bind()
    sh.uniform_float('color', color)
    batch_for_shader(sh, 'TRIS', {'pos': tris}).draw(sh)


def _draw_fill(sh, loops, color):
    try:
        tris = tessellate_polygon([[(p[0], p[1], 0.0) for p in lp] for lp in loops if len(lp) >= 3])
    except Exception:
        return
    flat = [p for lp in loops if len(lp) >= 3 for p in lp]
    coords = [flat[i] for tri in tris for i in tri]
    if coords:
        sh.bind()
        sh.uniform_float('color', color)
        batch_for_shader(sh, 'TRIS', {'pos': coords}).draw(sh)


def draw_overlay(op):
    try:
        if bpy.context.region != op.region:
            return
    except ReferenceError:
        return
    sh = _shader()
    gpu.state.blend_set('ALPHA')
    try:
        key = op.mode + ('_INV' if op.inverted() and op.mode != 'SPLIT' else '')
        color = _COLORS.get(key, _COLORS['CUT'])
        fill = (color[0], color[1], color[2], 0.16)
        if op.stage == 'SIDE' and op.side_preview:
            _draw_fill(sh, [op.side_preview], (1.0, 0.25, 0.1, 0.22))
        loops = op.preview_loops()
        for lp in loops:
            _draw_lines(sh, lp, color, closed=op.preview_closed())
        if loops and op.preview_closed() and op.stage != 'SIDE':
            _draw_fill(sh, loops, fill)
        if op.stage in {'POINTS', 'SIDE'}:
            _draw_squares(sh, op.pts, (1, 1, 1, 0.9), 3.5)
            if op.pts:
                _draw_squares(sh, [op.pts[0]], color, 5.5 if op.near_first else 4.0)
            if op.shape == 'CURVE_LASSO' and len(op.pts) >= 3:
                handle_color = (0.3, 0.8, 1.0, 0.9)
                tangents = op._tangents()
                for i in range(len(op.pts)):
                    if math.hypot(*tangents[i]) < 1e-6:
                        _draw_squares(sh, [op.pts[i]], (1.0, 0.35, 0.35, 0.9), 3.0)   # sharp corner
                        continue
                    h_in, h_out = curve_handles(op.pts, tangents, i)
                    _draw_lines(sh, [h_in, op.pts[i], h_out], handle_color, width=1.0)
                    _draw_squares(sh, [h_in, h_out], handle_color, 2.5)
    finally:
        gpu.state.line_width_set(1.0)
        gpu.state.blend_set('NONE')


# -----------------------------------------------------------------------------
# Operators
# -----------------------------------------------------------------------------


def exit_tool(context):
    try:
        bpy.ops.wm.tool_set_by_id(name='builtin.select_box', space_type='VIEW_3D')
    except RuntimeError as ex:
        print('[Mecha Lab] could not leave tool:', ex)


def open_popup(name):
    try:
        bpy.ops.wm.call_panel(name=name, keep_open=False)
    except RuntimeError as ex:
        print('[Mecha Lab] popup failed:', ex)


def _status(context, text):
    try:
        context.workspace.status_text_set(text)
    except (AttributeError, ReferenceError, TypeError):
        pass


def make_projector(region, rv3d):
    return cg.Projector(region, rv3d)


def add_draw_handler(op):
    return bpy.types.SpaceView3D.draw_handler_add(draw_overlay, (op,), 'WINDOW', 'POST_PIXEL')


def remove_draw_handler(handle):
    bpy.types.SpaceView3D.draw_handler_remove(handle, 'WINDOW')


def _now():
    return time.monotonic()


# Blender exposes double-click, but not a portable TRIPLE_CLICK event.
# Count distinct mouse-down events across individual (one-stroke) operators.
# A triple click must stay near the same screen position; clicking successive
# lasso vertices must never accidentally leave the Cut/Split/Mask tool.
_TRIPLE_STATE = {}
_TRIPLE_RADIUS_PX = 12.0
_TRIPLE_MAX_SECONDS = 0.72


def triple_click_to_select(context, event, clock=None):
    """Return True for a third quick LMB at the same viewport position.

    Event's DOUBLE_CLICK replaces PRESS on many Blender builds. Some OS/keymap
    configurations can deliver both events on one mouse down: the 25 ms
    duplicate filter prevents a phantom third click in that case.
    """
    if event.type != 'LEFTMOUSE' or event.value not in {'PRESS', 'DOUBLE_CLICK'}:
        return False
    if getattr(event, 'mouse_x', None) is None:
        return False
    if context.window is None or context.area is None:
        return False
    now = _now() if clock is None else clock
    try:
        key = (context.window.as_pointer(), context.area.as_pointer())
    except ReferenceError:
        return False
    pt = (float(event.mouse_x), float(event.mouse_y))
    state = _TRIPLE_STATE.get(key)
    double_time = max(0.32, min(_TRIPLE_MAX_SECONDS,
                                2.0 * _double_click_seconds(context)))
    if state:
        last_time, last_pt, count, last_type = state
        if (event.value == 'DOUBLE_CLICK' and last_type == 'PRESS' and
                now - last_time <= 0.025 and math.dist(pt, last_pt) <= 2.0):
            return False
        if now - last_time <= double_time and math.dist(pt, last_pt) <= _TRIPLE_RADIUS_PX:
            count += 1
        else:
            count = 1
    else:
        count = 1
    if count >= 3:
        _TRIPLE_STATE.pop(key, None)
        return True
    _TRIPLE_STATE[key] = (now, pt, count, event.value)
    return False


def triple_reset(context):
    """An edit click (moving / toggling a placed point) is not part of a triple."""
    try:
        _TRIPLE_STATE.pop((context.window.as_pointer(), context.area.as_pointer()), None)
    except (AttributeError, ReferenceError):
        pass


class StrokeLogic:
    """State machine of one shape stroke (plain Python so tests can drive it
    with simulated events; the Blender operator below only adds RNA).

    Stages: POINTS (Lasso / Curve Lasso), DRAG (Rect / Circle / Ellipse /
    Free Draw / Custom), SIDE (open line: pick the half to remove).
    Exits:  FINISHED = one applied operation (= one undo step);
            CANCELLED = nothing changed.  Esc and RMB double also leave the
            tool (Blender Select Box); completed cuts are never touched.
    """

    # ---- state helpers ---------------------------------------------------

    def inverted(self):
        return self.alt_latch or self.alt_held

    def preview_closed(self):
        if self.shape in {'LASSO', 'CURVE_LASSO'}:
            return not self._is_open_line()
        if self.shape == 'STROKE' and self.mode == 'MASK':
            return False      # Mask Brush Stroke is an open brush path
        return True

    def _is_open_line(self):
        return self.shape == 'LASSO' and (self.line_open or len(self.pts) == 2 and self.stage == 'SIDE')

    def _popup_name(self):
        return PROFILE_POPUP if self.mode == 'BASE' else SHAPE_POPUP

    def _needs_target(self):
        return self.mode != 'BASE'

    def _tangents(self, pts=None):
        pts = self.pts if pts is None else pts
        n = len(pts)
        sharp = list(self.sharp) + [False] * (n - len(self.sharp))
        over = list(self.overrides) + [None] * (n - len(self.overrides))
        return curve_tangents(pts, sharp, over, self.brush.curve_smoothness, closed=True)

    def _curve(self, pts=None):
        pts = self.pts if pts is None else pts
        n = len(pts)
        sharp = list(self.sharp) + [False] * (n - len(self.sharp))
        over = list(self.overrides) + [None] * (n - len(self.overrides))
        return curve_lasso_spline(pts, sharp, over, self.brush.curve_resolution,
                                  self.brush.curve_smoothness, closed=True)

    def _outline(self, loop):
        b = self.brush
        return round_corners(loop, b.outline_radius, b.outline_corner, b.outline_segments)

    def preview_loops(self):
        m = self.mouse
        if self.shape in {'LASSO', 'CURVE_LASSO'}:
            pts = list(self.pts)
            if self.stage == 'POINTS' and m is not None and self.drag_index is None \
                    and self.drag_handle is None and not self.free_drag:
                pts = pts + [self._snapped(m, self.shift_held)]
            if self.shape == 'CURVE_LASSO' and len(pts) >= 3:
                return [self._curve(pts)]
            if self.shape == 'LASSO' and len(pts) >= 3 and not self._is_open_line():
                return [self._outline(pts)]
            return [pts] if len(pts) >= 2 else []
        if self.shape == 'STROKE':
            return [self.pts] if len(self.pts) >= 2 else []
        if m is None or self.anchor is None:
            return []
        return self._drag_loops(m, self.ctrl_held, self.shift_held)

    def _drag_loops(self, m, ctrl, shift):
        b = self.brush
        if self.shape == 'RECT':
            return [self._outline(rect_loop(self.anchor, m, shift, ctrl))]
        if self.shape == 'CIRCLE':
            return [circle_loop(self.anchor, m, b.circle_segments)]
        if self.shape == 'ELLIPSE':
            return [ellipse_loop(self.anchor, m, b.circle_segments, shift, ctrl)]
        if self.shape == 'CUSTOM':
            r = math.dist(self.anchor, m)
            angle = b.custom_rotation
            if r < 4.0:
                r = b.custom_size
            elif b.custom_drag_rotate:
                angle += math.atan2(m[1] - self.anchor[1], m[0] - self.anchor[0])
            return custom_loops(self.custom, self.anchor, r, angle)
        return []

    def _snapped(self, p, shift):
        if shift and self.pts:
            return snap45(self.pts[-1], p)
        return p

    def _region_xy(self, event):
        r = self.region
        x, y = event.mouse_x - r.x, event.mouse_y - r.y
        inside = 0 <= x < r.width and 0 <= y < r.height
        return (float(x), float(y)), inside

    # ---- lifecycle -----------------------------------------------------------

    def invoke(self, context, event):
        # The third quick LMB at the same spot (after a double-click confirm)
        # arrives as a fresh stroke: leave the tool instead of starting one.
        if triple_click_to_select(context, event):
            exit_tool(context)
            return {'CANCELLED'}
        region = context.region
        if region is None or region.type != 'WINDOW':
            region = next((r for r in context.area.regions if r.type == 'WINDOW'), None)
        rv3d = context.region_data if context.region_data else context.space_data.region_3d
        if region is None or rv3d is None:
            return {'PASS_THROUGH'}
        self.region = region
        self.rv3d = rv3d
        self.projector = make_projector(region, rv3d)
        scene = context.scene
        self.brush = scene.mch_brush
        self.shape = self.brush.shape
        xy, inside = self._region_xy(event)
        if not inside:
            return {'PASS_THROUGH'}
        if self.mode in {'MASK', 'BASE'} and self.shape == 'LASSO' and self.brush.line_open:
            self.brush.line_open = False
        if self._needs_target():
            targets = gather_targets(context, self.projector, xy, self.mode)
            if not targets:
                self.report({'WARNING'}, 'Click on a mesh or select one first')
                return {'PASS_THROUGH'}
            self.target_names = [t.name for t in targets]
        else:
            self.target_names = []
        self.custom = None
        if self.shape == 'CUSTOM':
            from . import cut_presets
            try:
                self.custom = cut_presets.load_loops(scene.mch_png_preset)
            except (cg.CutError, ValueError, OSError) as ex:
                self.report({'WARNING'}, str(ex))
                return {'CANCELLED'}
        self.native_tool = ts.native_tool_id(context)
        self.pts, self.redo = [], []
        self.sharp, self.overrides = [], []
        self.alt_latch = bool(event.alt)
        self.alt_held = bool(event.alt)
        self.shift_held = bool(event.shift)
        self.ctrl_held = bool(event.ctrl)
        self.line_open = bool(self.brush.line_open)
        self.mouse = xy
        self.anchor = None
        self.drag_index = None
        self.drag_handle = None
        self.press_xy = None
        self.free_drag = False
        self.near_first = False
        self.side_preview = None
        self.rmb_time = None
        self.timer = None
        if self.shape in {'LASSO', 'CURVE_LASSO'}:
            self.stage = 'POINTS'
            self._add_point(xy)
            self.free_drag = self.shape == 'LASSO'
        else:
            self.stage = 'DRAG'
            self.anchor = xy
            if self.shape == 'STROKE':
                self.pts = [xy]
        self.handle = add_draw_handler(self)
        context.window_manager.modal_handler_add(self)
        self._hint(context)
        self.region.tag_redraw()
        return {'RUNNING_MODAL'}

    def _hint(self, context):
        tail = ' | RMB: ' + ('profiles' if self.mode == 'BASE' else 'shapes') + ', RMB×2 / Esc: exit tool'
        if self.stage == 'SIDE':
            text = 'Click the side to REMOVE (Alt+click: keep it)' + tail
        elif self.stage == 'POINTS':
            text = ('LMB point (drag = draw) | double-click anywhere: close & apply | Enter | '
                    'Backspace/Ctrl+Z: undo point | Shift 45° | Alt invert | F open line')
            if self.shape == 'CURVE_LASSO':
                text = ('LMB control point | click a point: sharp/smooth | drag point or handle | '
                        'double-click anywhere: close & apply | Backspace/Ctrl+Z: undo point')
            text += tail
        elif self.shape == 'STROKE':
            text = 'Hold LMB and draw, release to apply' + tail
        else:
            text = 'Drag, release to apply | Shift: square/circle | Ctrl: from center | Alt: invert' + tail
        _status(context, f'MECHA {self.mode}: ' + text)

    def _cleanup(self, context):
        if getattr(self, 'handle', None) is not None:
            remove_draw_handler(self.handle)
            self.handle = None
        if getattr(self, 'timer', None) is not None:
            try:
                context.window_manager.event_timer_remove(self.timer)
            except (ReferenceError, ValueError):
                pass
            self.timer = None
        _status(context, None)
        try:
            self.region.tag_redraw()
        except ReferenceError:
            pass

    def _cancel(self, context):
        self._cleanup(context)
        return {'CANCELLED'}

    def _leave_tool(self, context):
        """Esc / RMB double / triple click: drop the unfinished stroke, back to Select."""
        self._cleanup(context)
        exit_tool(context)
        return {'CANCELLED'}

    def cancel(self, context):
        self._cleanup(context)

    # ---- editing -----------------------------------------------------------

    def _add_point(self, xy):
        p = self._snapped(xy, self.shift_held)
        if self.pts and math.dist(p, self.pts[-1]) <= DUP_PX:
            return False
        self.pts.append(p)
        self.sharp.append(False)
        self.overrides.append(None)
        self.redo.clear()
        return True

    def _pop_point(self):
        if not self.pts:
            return False
        self.redo.append((self.pts.pop(), self.sharp.pop(), self.overrides.pop()))
        return True

    def _redo_point(self):
        if self.redo and self.stage == 'POINTS':
            p, sh, ov = self.redo.pop()
            self.pts.append(p)
            self.sharp.append(sh)
            self.overrides.append(ov)

    def _hit_point(self, xy):
        for i, p in enumerate(self.pts):
            if math.dist(p, xy) <= HIT_PX:
                return i
        return None

    def _hit_handle(self, xy):
        """(point index, side) of a Curve Lasso handle under the cursor."""
        if self.shape != 'CURVE_LASSO' or len(self.pts) < 3:
            return None
        tangents = self._tangents()
        for i in range(len(self.pts)):
            if math.hypot(*tangents[i]) < 1e-6:
                continue
            h_in, h_out = curve_handles(self.pts, tangents, i)
            if math.dist(h_out, xy) <= HIT_PX:
                return (i, 1)
            if math.dist(h_in, xy) <= HIT_PX:
                return (i, -1)
        return None

    def _clean_points(self):
        keep = clean_clicks(self.pts, DUP_PX, closed=not self._is_open_line())
        if len(keep) != len(self.pts):
            idx, j = [], 0
            for i, p in enumerate(self.pts):
                if j < len(keep) and p == keep[j]:
                    idx.append(i)
                    j += 1
            self.sharp = [self.sharp[i] for i in idx]
            self.overrides = [self.overrides[i] for i in idx]
            self.pts = keep

    def _current_loops(self, event_ctrl=False, event_shift=False):
        if self.shape in {'LASSO', 'CURVE_LASSO'}:
            if self.shape == 'CURVE_LASSO':
                return [self._curve()]
            return [self._outline(list(self.pts))]
        if self.shape == 'STROKE':
            pts = smooth_open(self.pts, self.brush.stroke_smooth)
            pts = cg.simplify_open(pts, self.brush.stroke_simplify)
            return [cg.trim_closing_overlap(pts)]
        return self._drag_loops(self.mouse, event_ctrl, event_shift)

    # ---- execution ---------------------------------------------------------

    def _targets(self):
        return [bpy.data.objects[n] for n in self.target_names if n in bpy.data.objects]

    def _execute_closed(self, context):
        targets = self._targets()
        if self.mode == 'MASK' and self.shape == 'STROKE':
            from . import mask_tools
            points = smooth_open(self.pts, self.brush.stroke_smooth)
            points = cg.simplify_open(points, self.brush.stroke_simplify)
            changed, total = mask_tools.apply_mask_stroke(
                context, targets[0], points, self.projector,
                self.brush.mask_brush_radius, self.inverted())
            msg = f'Mask stroke: {changed} faces changed ({total} masked total; entire faces, not exact outline)'
        else:
            loops = self._current_loops(self.ctrl_held, self.shift_held)
            if self.mode == 'MASK':
                msg = perform_mask(context, targets[0], loops, self.projector, self.inverted())
            elif self.mode == 'BASE':
                from . import base_mesh
                msg = base_mesh.perform_base(context, loops, self.projector)
            else:
                msg = perform_closed(context, self.mode, targets, loops, self.projector, self.inverted())
        if self.shape == 'CUSTOM' and self.anchor is not None and self.mouse is not None:
            r = math.dist(self.anchor, self.mouse)
            if r >= 4.0:
                self.brush.custom_size = r
        return msg

    def _run(self, context, fn, keep_on_shape_error=False):
        try:
            msg = fn(context)
        except cg.CutError as ex:
            self.report({'WARNING'}, str(ex))
            if keep_on_shape_error and ('crosses itself' in str(ex) or 'too small' in str(ex)):
                return {'RUNNING_MODAL'}
            return self._cancel(context)
        except Exception as ex:  # unexpected: report, keep the scene intact
            traceback.print_exc()
            self.report({'ERROR'}, f'Mecha {self.mode} failed: {ex}')
            return self._cancel(context)
        self.report({'INFO'}, msg)
        self._cleanup(context)
        return {'FINISHED'}

    def _confirm(self, context):
        if self.shape in {'LASSO', 'CURVE_LASSO'}:
            self._clean_points()
            if self.shape == 'LASSO' and len(self.pts) >= 2 and (self.line_open or len(self.pts) == 2):
                if self.mode in {'MASK', 'BASE'}:
                    self.report({'WARNING'}, 'This tool needs a closed outline (3+ points)')
                    return {'RUNNING_MODAL'}
                if self.mode == 'SPLIT':
                    return self._run(context, lambda c: perform_line(
                        c, 'SPLIT', self._targets(), self.pts, self.projector, self.pts[0]))
                self.stage = 'SIDE'
                self._update_side_preview()
                self._hint(context)
                return {'RUNNING_MODAL'}
            if len(self.pts) < 3:
                self.report({'WARNING'}, 'Place at least 3 points (Lasso: 2 points = line cut)')
                return {'RUNNING_MODAL'}
        return self._run(context, self._execute_closed, keep_on_shape_error=True)

    def _update_side_preview(self):
        self.side_preview = None
        try:
            corners = [self.projector.to_screen(c) for c in cg.object_world_bounds(self._targets())]
            corners = [c for c in corners if c is not None] + list(self.pts)
            if self.mouse:
                corners.append(self.mouse)
            xs = [p[0] for p in corners]
            ys = [p[1] for p in corners]
            pad = max(80.0, 0.2 * max(max(xs) - min(xs), max(ys) - min(ys)))
            box = (min(xs) - pad, min(ys) - pad, max(xs) + pad, max(ys) + pad)
            half = side_polygon(self.pts, box)
            if self.mouse and not cg.point_in_loop(self.mouse, half):
                half = side_polygon(list(reversed(self.pts)), box)
            self.side_preview = half
        except (cg.CutError, ValueError, ZeroDivisionError):
            pass

    # ---- modal ---------------------------------------------------------------

    def modal(self, context, event):
        try:
            return self._modal(context, event)
        except ReferenceError:
            # Undo from a menu / area closed while a stroke was pending: the
            # stored scene, brush or region no longer exists. Drop the stroke.
            try:
                self._cleanup(context)
            except ReferenceError:
                pass
            return {'CANCELLED'}
        except Exception as ex:
            traceback.print_exc()
            self.report({'ERROR'}, f'Mecha stroke aborted: {ex}')
            return self._cancel(context)

    def _modal(self, context, event):
        if self._needs_target() and not self._targets():
            return self._cancel(context)
        if self.native_tool and ts.native_tool_id(context) != self.native_tool:
            return self._cancel(context)          # tool switched from toolbar/list
        if context.scene.mch_brush.shape != self.shape:
            self.report({'INFO'}, 'Shape changed: unfinished stroke discarded')
            return self._cancel(context)

        et, ev = event.type, event.value
        if et in {'LEFT_ALT', 'RIGHT_ALT'}:
            self.alt_held = ev == 'PRESS'
        if et in {'LEFT_SHIFT', 'RIGHT_SHIFT'}:
            self.shift_held = ev == 'PRESS'
        if et in {'LEFT_CTRL', 'RIGHT_CTRL', 'OSKEY'}:
            self.ctrl_held = ev == 'PRESS'

        if et == 'TIMER':
            if self.rmb_time is not None and event_timer_matches(self, event):
                if _now() - self.rmb_time >= _double_click_seconds(context):
                    self.rmb_time = None
                    self._remove_timer(context)
                    open_popup(self._popup_name())
                return {'RUNNING_MODAL'}
            return {'PASS_THROUGH'}

        xy, inside = self._region_xy(event)
        if et in NAV_EVENTS or et.startswith('NDOF') or (et.startswith('NUMPAD_') and et != 'NUMPAD_ENTER'):
            return {'PASS_THROUGH'}

        if et == 'MOUSEMOVE' or et == 'INBETWEEN_MOUSEMOVE':
            if inside or self.stage == 'DRAG' or self.drag_index is not None or self.free_drag:
                self.mouse = xy
                self._on_move(xy)
                self.region.tag_redraw()
            return {'RUNNING_MODAL'} if inside else {'PASS_THROUGH'}

        if not inside:
            if et == 'LEFTMOUSE' and ev == 'RELEASE' and (self.stage == 'DRAG' or self.drag_index is not None
                                                           or self.free_drag):
                pass   # finish a drag that ended over another region
            else:
                return {'PASS_THROUGH'}   # palette, sidebar, menus keep working

        if et == 'ESC' and ev == 'PRESS':
            return self._leave_tool(context)
        if et == 'SPACE' and ev == 'PRESS':
            self._cleanup(context)
            open_popup(TOOL_POPUP)
            return {'CANCELLED'}
        if et == 'RIGHTMOUSE' and ev in {'PRESS', 'DOUBLE_CLICK'}:
            now = _now()
            if ev == 'DOUBLE_CLICK' or (self.rmb_time is not None and
                                         now - self.rmb_time < _double_click_seconds(context)):
                return self._leave_tool(context)
            self.rmb_time = now
            if self.timer is None:
                self.timer = context.window_manager.event_timer_add(0.04, window=context.window)
            return {'RUNNING_MODAL'}
        if et == 'RIGHTMOUSE':
            return {'RUNNING_MODAL'}

        if et == 'Z' and ev == 'PRESS' and (event.ctrl or event.oskey):
            if event.shift:
                self._redo_point()
            elif self.stage == 'SIDE':
                self.stage = 'POINTS'
                self.side_preview = None
            elif not self._pop_point() or not self.pts:
                return self._cancel(context)
            self._hint(context)
            self.region.tag_redraw()
            return {'RUNNING_MODAL'}
        if et == 'Y' and ev == 'PRESS' and event.ctrl:
            self._redo_point()
            self.region.tag_redraw()
            return {'RUNNING_MODAL'}
        if et == 'BACK_SPACE' and ev == 'PRESS':
            if self.stage == 'SIDE':
                self.stage = 'POINTS'
                self.side_preview = None
            elif not self._pop_point() or not self.pts:
                return self._cancel(context)
            self._hint(context)
            self.region.tag_redraw()
            return {'RUNNING_MODAL'}
        if et == 'F' and ev == 'PRESS' and self.shape == 'LASSO' and self.mode not in {'MASK', 'BASE'}:
            self.line_open = not self.line_open
            self.brush.line_open = self.line_open
            self.region.tag_redraw()
            return {'RUNNING_MODAL'}
        if et in {'RET', 'NUMPAD_ENTER'} and ev == 'PRESS':
            if self.stage == 'SIDE':
                return self._apply_side(context, self.mouse or self.pts[0], event.alt)
            if self.stage == 'POINTS':
                return self._confirm(context)
            return {'RUNNING_MODAL'}

        if et == 'LEFTMOUSE':
            if ev in {'PRESS', 'DOUBLE_CLICK'} and event.alt:
                self.alt_latch = True
            return self._on_lmb(context, ev, xy, event)
        if et in {'LEFT_ALT', 'RIGHT_ALT', 'LEFT_SHIFT', 'RIGHT_SHIFT', 'LEFT_CTRL', 'RIGHT_CTRL'}:
            self.region.tag_redraw()
            return {'RUNNING_MODAL'}
        # Swallow other keys while a stroke is pending so a stray hotkey cannot
        # delete or transform the target halfway through.
        return {'RUNNING_MODAL'}

    def _on_move(self, xy):
        if self.stage == 'DRAG' and self.shape == 'STROKE':
            if not self.pts or math.dist(self.pts[-1], xy) >= self.brush.stroke_spacing:
                self.pts.append(xy)
        elif self.stage == 'POINTS':
            if self.drag_index is not None:
                if math.dist(xy, self.press_xy) > 3.0:
                    self.pts[self.drag_index] = xy
            elif self.drag_handle is not None:
                i, side = self.drag_handle
                p = self.pts[i]
                self.overrides[i] = (3.0 * (xy[0] - p[0]) * side, 3.0 * (xy[1] - p[1]) * side)
                self.sharp[i] = False
            elif self.free_drag and self.shape == 'LASSO':
                # Holding LMB in Lasso draws continuously (freehand segment).
                if math.dist(self.pts[-1], xy) >= max(self.brush.stroke_spacing * 2.0, DUP_PX + 1):
                    self.pts.append(xy)
                    self.sharp.append(False)
                    self.overrides.append(None)
                    self.redo.clear()
            self.near_first = len(self.pts) >= 3 and math.dist(self.pts[0], xy) <= HIT_PX
        elif self.stage == 'SIDE':
            self._update_side_preview()

    def _apply_side(self, context, xy, alt):
        invert = alt or self.inverted()
        return self._run(context, lambda c: perform_line(
            c, 'CUT', self._targets(), self.pts, self.projector, xy, invert))

    def _on_lmb(self, context, ev, xy, event):
        is_down = ev in {'PRESS', 'DOUBLE_CLICK'}
        if self.stage == 'POINTS' and is_down and ev == 'PRESS':
            edit = self._hit_handle(xy) is not None
            hit = self._hit_point(xy)
            if hit is not None and hit != len(self.pts) - 1 and not (hit == 0 and len(self.pts) >= 3):
                edit = True
            if edit:
                triple_reset(context)
            elif triple_click_to_select(context, event):
                return self._leave_tool(context)
        elif is_down and triple_click_to_select(context, event):
            return self._leave_tool(context)

        if self.stage == 'SIDE':
            if is_down:
                return self._apply_side(context, xy, event.alt)
            return {'RUNNING_MODAL'}
        if self.stage == 'DRAG':
            if ev == 'RELEASE':
                if self.shape in {'RECT', 'CIRCLE', 'ELLIPSE'} and \
                        math.dist(self.anchor, xy) < 4.0:
                    return self._cancel(context)    # a click, not a drag
                self.mouse = xy
                if self.shape == 'STROKE':
                    if xy != self.pts[-1] and math.dist(self.pts[-1], xy) > 0.5:
                        self.pts.append(xy)
                    if len(self.pts) < (1 if self.mode == 'MASK' else 3):
                        return self._cancel(context)
                return self._run(context, self._execute_closed)
            return {'RUNNING_MODAL'}
        # POINTS
        if ev == 'DOUBLE_CLICK':
            # Double-click anywhere: close from the last point to the first and
            # apply. Never adds a point (no duplicate / zero-length edge).
            self.free_drag = False
            return self._confirm(context)
        if ev == 'PRESS':
            handle = self._hit_handle(xy)
            if handle is not None:
                self.drag_handle = handle
                return {'RUNNING_MODAL'}
            hit = self._hit_point(xy)
            if hit == 0 and len(self.pts) >= 3 and not self.line_open:
                return self._confirm(context)
            if hit is not None and (hit != len(self.pts) - 1 or self.shape == 'CURVE_LASSO'):
                self.drag_index = hit
                self.press_xy = xy
                return {'RUNNING_MODAL'}
            self.shift_held = bool(event.shift)
            self._add_point(xy)
            self.free_drag = self.shape == 'LASSO'
            self.region.tag_redraw()
            return {'RUNNING_MODAL'}
        if ev == 'RELEASE':
            if self.drag_index is not None:
                moved = math.dist(xy, self.press_xy) > 3.0
                if not moved and self.shape == 'CURVE_LASSO':
                    i = self.drag_index
                    # click on a control point: smooth <-> sharp corner
                    if self.overrides[i] is not None:
                        self.overrides[i] = None
                    else:
                        self.sharp[i] = not self.sharp[i]
                self.drag_index = None
            self.drag_handle = None
            self.free_drag = False
            self.region.tag_redraw()
        return {'RUNNING_MODAL'}

    def _remove_timer(self, context):
        if self.timer is not None:
            context.window_manager.event_timer_remove(self.timer)
            self.timer = None


class MCH_OT_cut_stroke(StrokeLogic, bpy.types.Operator):
    bl_idname = 'mch.cut_stroke'
    bl_label = 'Mecha Shape Stroke'
    bl_description = 'Draw one shape with the shared shape palette and Cut / Split / Mask / Base Mesh with it'
    bl_options = {'REGISTER', 'UNDO'}

    mode: EnumProperty(name='Mode', items=[
        ('CUT', 'Cut', 'Remove the inside (Alt: keep inside)'),
        ('SPLIT', 'Split', 'Split into two parts'),
        ('MASK', 'Mask', 'Add face mask (Alt: erase)'),
        ('BASE', 'Base Mesh', 'Create a new solid from the drawn outline')], default='CUT')

    @classmethod
    def poll(cls, context):
        return (context.area is not None and context.area.type == 'VIEW_3D'
                and context.mode == 'OBJECT')


def _double_click_seconds(context):
    try:
        return max(0.15, context.preferences.inputs.mouse_double_click_time / 1000.0)
    except AttributeError:
        return 0.35


def event_timer_matches(op, event):
    # Event timers are not exposed on the event; any TIMER event while our timer
    # exists is good enough because we only compare elapsed wall-clock time.
    return op.timer is not None


class GateLogic:
    """RMB in an idle Mecha tool: single = popup (shapes or Base Mesh profiles),
    double = leave the tool."""

    def invoke(self, context, event):
        self.t0 = _now()
        self.timer = context.window_manager.event_timer_add(0.04, window=context.window)
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def _stop(self, context):
        if self.timer is not None:
            context.window_manager.event_timer_remove(self.timer)
            self.timer = None

    def modal(self, context, event):
        if event.type == 'RIGHTMOUSE' and event.value in {'PRESS', 'DOUBLE_CLICK'}:
            self._stop(context)
            exit_tool(context)
            return {'FINISHED'}
        if event.type == 'TIMER' and _now() - self.t0 >= _double_click_seconds(context):
            self._stop(context)
            open_popup(PROFILE_POPUP if getattr(self, 'popup', 'SHAPE') == 'PROFILE' else SHAPE_POPUP)
            return {'FINISHED'}
        if event.type == 'ESC':
            self._stop(context)
            exit_tool(context)
            return {'CANCELLED'}
        return {'PASS_THROUGH'}

    def cancel(self, context):
        self._stop(context)


class MCH_OT_rmb_gate(GateLogic, bpy.types.Operator):
    """RMB in an idle Mecha tool: single = popup, double = leave the tool."""
    bl_idname = 'mch.rmb_gate'
    bl_label = 'Mecha RMB (Popup / Exit)'
    bl_options = {'INTERNAL'}
    popup: EnumProperty(items=[('SHAPE', 'Shapes', ''), ('PROFILE', 'Base Mesh Profiles', '')],
                        default='SHAPE')

    @classmethod
    def poll(cls, context):
        return context.area is not None and context.area.type == 'VIEW_3D'


class MCH_OT_exit_tool(bpy.types.Operator):
    """Esc in an idle Mecha tool: back to Blender's Select Box tool."""
    bl_idname = 'mch.exit_tool'
    bl_label = 'Leave Mecha Tool'
    bl_options = {'INTERNAL'}

    @classmethod
    def poll(cls, context):
        return context.area is not None and context.area.type == 'VIEW_3D'

    def execute(self, context):
        exit_tool(context)
        return {'FINISHED'}


CLASSES = (MCH_OT_cut_stroke, MCH_OT_rmb_gate, MCH_OT_exit_tool)
